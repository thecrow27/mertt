<?php 


error_reporting(0);

include "kayit.php";



$wp["1"] = $lakap;
$wp["2"] = $lakap.$soyadad."123";
$wp["3"] = $lakap.$soyadad."1905";
$wp["4"] = $lakap.$soyadad."1907";
$wp["5"] = $lakap.$soyadad."1903";
$wp["6"] = $lakap.$soyadad."1938";
$wp["7"] = $lakap.$soyadad."1919";
$wp["8"] = $lakap.$soyadad."1881";
$wp["9"] = $lakap.$soyadad."2018";
$wp["10"] = $lakap.$soyadad."2019";
$wp["11"] = $lakap.$soyadad.$lakap;
$wp["12"] = $lakap.$soyadad.$anne;
$wp["13"] = $lakap.$soyadad.$baba;
$wp["14"] = $lakap.$soyadad.$kardes;
$wp["15"] = $lakap.$soyadad.$sevgili;
$wp["16"] = $lakap.$soyadad.$sevgilisoyad;
$wp["17"] = $lakap.$soyadad.$dogumtarihi;
$wp["18"] = $lakap.$soyadad.$dogumyili;
$wp["19"] = $lakap.$soyadad.$cikmayili;
$wp["20"] = $lakap.$soyadad.$cikmatarihi;
$wp["21"] = $lakap.$soyadad.$sehir;
$wp["22"] = $lakap.$soyadad.$takim;
$wp["23"] = $lakap.$soyadad.$takimtarihi;
$wp["24"] = $lakap.$soyadad.$takimkisa;
$wp["25"] = $lakap.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $lakap.$lakap;
$wp["27"] = $lakap.$lakap."123";
$wp["28"] = $lakap.$lakap."1905";
$wp["29"] = $lakap.$lakap."1907";
$wp["30"] = $lakap.$lakap."1903";
$wp["31"] = $lakap.$lakap."1938";
$wp["32"] = $lakap.$lakap."1919";
$wp["33"] = $lakap.$lakap."1881";
$wp["34"] = $lakap.$lakap."2018";
$wp["35"] = $lakap.$lakap."2019";
$wp["36"] = $lakap.$lakap.$lakap;
$wp["37"] = $lakap.$lakap.$anne;
$wp["38"] = $lakap.$lakap.$baba;
$wp["39"] = $lakap.$lakap.$kardes;
$wp["40"] = $lakap.$lakap.$sevgili;
$wp["41"] = $lakap.$lakap.$sevgilisoyad;
$wp["42"] = $lakap.$lakap.$dogumtarihi;
$wp["43"] = $lakap.$lakap.$dogumyili;
$wp["44"] = $lakap.$lakap.$cikmayili;
$wp["45"] = $lakap.$lakap.$cikmatarihi;
$wp["46"] = $lakap.$lakap.$sehir;
$wp["47"] = $lakap.$lakap.$takim;
$wp["48"] = $lakap.$lakap.$takimtarihi;
$wp["49"] = $lakap.$lakap.$takimkisa;
$wp["50"] = $lakap.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $lakap.$anne;
$wp["52"] = $lakap.$anne."123";
$wp["53"] = $lakap.$anne."1905";
$wp["54"] = $lakap.$anne."1907";
$wp["55"] = $lakap.$anne."1903";
$wp["56"] = $lakap.$anne."1938";
$wp["57"] = $lakap.$anne."1919";
$wp["58"] = $lakap.$anne."1881";
$wp["59"] = $lakap.$anne."2018";
$wp["60"] = $lakap.$anne."2019";
$wp["61"] = $lakap.$anne.$lakap;
$wp["62"] = $lakap.$anne.$anne;
$wp["63"] = $lakap.$anne.$baba;
$wp["64"] = $lakap.$anne.$kardes;
$wp["65"] = $lakap.$anne.$sevgili;
$wp["66"] = $lakap.$anne.$sevgilisoyad;
$wp["67"] = $lakap.$anne.$dogumtarihi;
$wp["68"] = $lakap.$anne.$dogumyili;
$wp["69"] = $lakap.$anne.$cikmayili;
$wp["70"] = $lakap.$anne.$cikmatarihi;
$wp["71"] = $lakap.$anne.$sehir;
$wp["72"] = $lakap.$anne.$takim;
$wp["73"] = $lakap.$anne.$takimtarihi;
$wp["74"] = $lakap.$anne.$takimkisa;
$wp["75"] = $lakap.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $lakap.$baba;
$wp["77"] = $lakap.$baba."123";
$wp["78"] = $lakap.$baba."1905";
$wp["79"] = $lakap.$baba."1907";
$wp["80"] = $lakap.$baba."1903";
$wp["81"] = $lakap.$baba."1938";
$wp["82"] = $lakap.$baba."1919";
$wp["83"] = $lakap.$baba."1881";
$wp["84"] = $lakap.$baba."2018";
$wp["85"] = $lakap.$baba."2019";
$wp["86"] = $lakap.$baba.$lakap;
$wp["87"] = $lakap.$baba.$anne;
$wp["88"] = $lakap.$baba.$baba;
$wp["89"] = $lakap.$baba.$kardes;
$wp["90"] = $lakap.$baba.$sevgili;
$wp["91"] = $lakap.$baba.$sevgilisoyad;
$wp["92"] = $lakap.$baba.$dogumtarihi;
$wp["93"] = $lakap.$baba.$dogumyili;
$wp["94"] = $lakap.$baba.$cikmayili;
$wp["95"] = $lakap.$baba.$cikmatarihi;
$wp["96"] = $lakap.$baba.$sehir;
$wp["97"] = $lakap.$baba.$takim;
$wp["98"] = $lakap.$baba.$takimtarihi;
$wp["99"] = $lakap.$baba.$takimkisa;
$wp["100"] = $lakap.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $lakap.$kardes;
$wp["102"] = $lakap.$kardes."123";
$wp["103"] = $lakap.$kardes."1905";
$wp["104"] = $lakap.$kardes."1907";
$wp["105"] = $lakap.$kardes."1903";
$wp["106"] = $lakap.$kardes."1938";
$wp["107"] = $lakap.$kardes."1919";
$wp["108"] = $lakap.$kardes."1881";
$wp["109"] = $lakap.$kardes."2018";
$wp["110"] = $lakap.$kardes."2019";
$wp["111"] = $lakap.$kardes.$lakap;
$wp["112"] = $lakap.$kardes.$anne;
$wp["113"] = $lakap.$kardes.$baba;
$wp["114"] = $lakap.$kardes.$kardes;
$wp["115"] = $lakap.$kardes.$sevgili;
$wp["116"] = $lakap.$kardes.$sevgilisoyad;
$wp["117"] = $lakap.$kardes.$dogumtarihi;
$wp["118"] = $lakap.$kardes.$dogumyili;
$wp["119"] = $lakap.$kardes.$cikmayili;
$wp["120"] = $lakap.$kardes.$cikmatarihi;
$wp["121"] = $lakap.$kardes.$sehir;
$wp["122"] = $lakap.$kardes.$takim;
$wp["123"] = $lakap.$kardes.$takimtarihi;
$wp["124"] = $lakap.$kardes.$takimkisa;
$wp["125"] = $lakap.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $lakap.$sevgili;
$wp["127"] = $lakap.$sevgili."123";
$wp["128"] = $lakap.$sevgili."1905";
$wp["129"] = $lakap.$sevgili."1907";
$wp["130"] = $lakap.$sevgili."1903";
$wp["131"] = $lakap.$sevgili."1938";
$wp["132"] = $lakap.$sevgili."1919";
$wp["133"] = $lakap.$sevgili."1881";
$wp["134"] = $lakap.$sevgili."2018";
$wp["135"] = $lakap.$sevgili."2019";
$wp["136"] = $lakap.$sevgili.$lakap;
$wp["137"] = $lakap.$sevgili.$anne;
$wp["138"] = $lakap.$sevgili.$baba;
$wp["139"] = $lakap.$sevgili.$kardes;
$wp["140"] = $lakap.$sevgili.$sevgili;
$wp["141"] = $lakap.$sevgili.$sevgilisoyad;
$wp["142"] = $lakap.$sevgili.$dogumtarihi;
$wp["143"] = $lakap.$sevgili.$dogumyili;
$wp["144"] = $lakap.$sevgili.$cikmayili;
$wp["145"] = $lakap.$sevgili.$cikmatarihi;
$wp["146"] = $lakap.$sevgili.$sehir;
$wp["147"] = $lakap.$sevgili.$takim;
$wp["148"] = $lakap.$sevgili.$takimtarihi;
$wp["149"] = $lakap.$sevgili.$takimkisa;
$wp["150"] = $lakap.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $lakap.$sevgilisoyad;
$wp["152"] = $lakap.$sevgilisoyad."123";
$wp["153"] = $lakap.$sevgilisoyad."1905";
$wp["154"] = $lakap.$sevgilisoyad."1907";
$wp["155"] = $lakap.$sevgilisoyad."1903";
$wp["156"] = $lakap.$sevgilisoyad."1938";
$wp["157"] = $lakap.$sevgilisoyad."1919";
$wp["158"] = $lakap.$sevgilisoyad."1881";
$wp["159"] = $lakap.$sevgilisoyad."2018";
$wp["160"] = $lakap.$sevgilisoyad."2019";
$wp["161"] = $lakap.$sevgilisoyad.$lakap;
$wp["162"] = $lakap.$sevgilisoyad.$anne;
$wp["163"] = $lakap.$sevgilisoyad.$baba;
$wp["164"] = $lakap.$sevgilisoyad.$kardes;
$wp["165"] = $lakap.$sevgilisoyad.$sevgili;
$wp["166"] = $lakap.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $lakap.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $lakap.$sevgilisoyad.$dogumyili;
$wp["169"] = $lakap.$sevgilisoyad.$cikmayili;
$wp["170"] = $lakap.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $lakap.$sevgilisoyad.$sehir;
$wp["172"] = $lakap.$sevgilisoyad.$takim;
$wp["173"] = $lakap.$sevgilisoyad.$takimtarihi;
$wp["174"] = $lakap.$sevgilisoyad.$takimkisa;
$wp["175"] = $lakap.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $lakap.$dogumtarihi;
$wp["177"] = $lakap.$dogumtarihi."123";
$wp["178"] = $lakap.$dogumtarihi."1905";
$wp["179"] = $lakap.$dogumtarihi."1907";
$wp["180"] = $lakap.$dogumtarihi."1903";
$wp["181"] = $lakap.$dogumtarihi."1938";
$wp["200"] = $lakap.$dogumtarihi."1919";
$wp["182"] = $lakap.$dogumtarihi."1881";
$wp["183"] = $lakap.$dogumtarihi."2018";
$wp["184"] = $lakap.$dogumtarihi."2019";
$wp["185"] = $lakap.$dogumtarihi.$lakap;
$wp["186"] = $lakap.$dogumtarihi.$anne;
$wp["187"] = $lakap.$dogumtarihi.$baba;
$wp["188"] = $lakap.$dogumtarihi.$kardes;
$wp["189"] = $lakap.$dogumtarihi.$sevgili;
$wp["190"] = $lakap.$dogumtarihi.$dogumtarihi;
$wp["191"] = $lakap.$dogumtarihi.$dogumtarihi;
$wp["192"] = $lakap.$dogumtarihi.$dogumyili;
$wp["193"] = $lakap.$dogumtarihi.$cikmayili;
$wp["194"] = $lakap.$dogumtarihi.$cikmatarihi;
$wp["195"] = $lakap.$dogumtarihi.$sehir;
$wp["196"] = $lakap.$dogumtarihi.$takim;
$wp["197"] = $lakap.$dogumtarihi.$takimtarihi;
$wp["198"] = $lakap.$dogumtarihi.$takimkisa;
$wp["199"] = $lakap.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $lakap.$dogumyili;
$wp["202"] = $lakap.$dogumyili."123";
$wp["203"] = $lakap.$dogumyili."1905";
$wp["204"] = $lakap.$dogumyili."1907";
$wp["205"] = $lakap.$dogumyili."1903";
$wp["206"] = $lakap.$dogumyili."1938";
$wp["207"] = $lakap.$dogumyili."1919";
$wp["208"] = $lakap.$dogumyili."1881";
$wp["209"] = $lakap.$dogumyili."2018";
$wp["210"] = $lakap.$dogumyili."2019";
$wp["211"] = $lakap.$dogumyili.$lakap;
$wp["212"] = $lakap.$dogumyili.$anne;
$wp["213"] = $lakap.$dogumyili.$baba;
$wp["214"] = $lakap.$dogumyili.$kardes;
$wp["215"] = $lakap.$dogumyili.$sevgili;
$wp["216"] = $lakap.$dogumyili.$dogumyili;
$wp["217"] = $lakap.$dogumyili.$dogumyili;
$wp["218"] = $lakap.$dogumyili.$dogumyili;
$wp["219"] = $lakap.$dogumyili.$cikmayili;
$wp["220"] = $lakap.$dogumyili.$cikmatarihi;
$wp["221"] = $lakap.$dogumyili.$sehir;
$wp["222"] = $lakap.$dogumyili.$takim;
$wp["223"] = $lakap.$dogumyili.$takimtarihi;
$wp["224"] = $lakap.$dogumyili.$takimkisa;
$wp["225"] = $lakap.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $lakap.$cikmayili;
$wp["227"] = $lakap.$cikmayili."123";
$wp["228"] = $lakap.$cikmayili."1905";
$wp["229"] = $lakap.$cikmayili."1907";
$wp["230"] = $lakap.$cikmayili."1903";
$wp["231"] = $lakap.$cikmayili."1938";
$wp["232"] = $lakap.$cikmayili."1919";
$wp["233"] = $lakap.$cikmayili."1881";
$wp["234"] = $lakap.$cikmayili."2018";
$wp["235"] = $lakap.$cikmayili."2019";
$wp["236"] = $lakap.$cikmayili.$lakap;
$wp["237"] = $lakap.$cikmayili.$anne;
$wp["238"] = $lakap.$cikmayili.$baba;
$wp["239"] = $lakap.$cikmayili.$kardes;
$wp["240"] = $lakap.$cikmayili.$sevgili;
$wp["241"] = $lakap.$cikmayili.$cikmayili;
$wp["242"] = $lakap.$cikmayili.$dogumyili;
$wp["243"] = $lakap.$cikmayili.$cikmayili;
$wp["244"] = $lakap.$cikmayili.$cikmayili;
$wp["245"] = $lakap.$cikmayili.$cikmatarihi;
$wp["246"] = $lakap.$cikmayili.$sehir;
$wp["247"] = $lakap.$cikmayili.$takim;
$wp["248"] = $lakap.$cikmayili.$takimtarihi;
$wp["249"] = $lakap.$cikmayili.$takimkisa;
$wp["250"] = $lakap.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $lakap.$cikmatarihi;
$wp["252"] = $lakap.$cikmatarihi."123";
$wp["253"] = $lakap.$cikmatarihi."1905";
$wp["254"] = $lakap.$cikmatarihi."1907";
$wp["255"] = $lakap.$cikmatarihi."1903";
$wp["256"] = $lakap.$cikmatarihi."1938";
$wp["257"] = $lakap.$cikmatarihi."1919";
$wp["258"] = $lakap.$cikmatarihi."1881";
$wp["259"] = $lakap.$cikmatarihi."2018";
$wp["260"] = $lakap.$cikmatarihi."2019";
$wp["261"] = $lakap.$cikmatarihi.$lakap;
$wp["262"] = $lakap.$cikmatarihi.$anne;
$wp["263"] = $lakap.$cikmatarihi.$baba;
$wp["264"] = $lakap.$cikmatarihi.$kardes;
$wp["265"] = $lakap.$cikmatarihi.$sevgili;
$wp["267"] = $lakap.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $lakap.$cikmatarihi.$dogumtarihi;
$wp["269"] = $lakap.$cikmatarihi.$dogumyili;
$wp["270"] = $lakap.$cikmatarihi.$cikmayili;
$wp["271"] = $lakap.$cikmatarihi.$cikmatarihi;
$wp["272"] = $lakap.$cikmatarihi.$sehir;
$wp["273"] = $lakap.$cikmatarihi.$takim;
$wp["274"] = $lakap.$cikmatarihi.$takimtarihi;
$wp["275"] = $lakap.$cikmatarihi.$takimkisa;
$wp["266"] = $lakap.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $lakap.$sehir;
$wp["277"] = $lakap.$sehir."123";
$wp["278"] = $lakap.$sehir."1905";
$wp["279"] = $lakap.$sehir."1907";
$wp["280"] = $lakap.$sehir."1903";
$wp["281"] = $lakap.$sehir."1938";
$wp["282"] = $lakap.$sehir."1919";
$wp["283"] = $lakap.$sehir."1881";
$wp["284"] = $lakap.$sehir."2018";
$wp["285"] = $lakap.$sehir."2019";
$wp["286"] = $lakap.$sehir.$lakap;
$wp["287"] = $lakap.$sehir.$anne;
$wp["288"] = $lakap.$sehir.$baba;
$wp["289"] = $lakap.$sehir.$kardes;
$wp["290"] = $lakap.$sehir.$sevgili;
$wp["291"] = $lakap.$sehir.$sevgilisoyad;
$wp["292"] = $lakap.$sehir.$dogumtarihi;
$wp["293"] = $lakap.$sehir.$dogumyili;
$wp["294"] = $lakap.$sehir.$cikmayili;
$wp["295"] = $lakap.$sehir.$cikmatarihi;
$wp["296"] = $lakap.$sehir.$sehir;
$wp["297"] = $lakap.$sehir.$takim;
$wp["298"] = $lakap.$sehir.$takimtarihi;
$wp["299"] = $lakap.$sehir.$takimkisa;
$wp["300"] = $lakap.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $lakap.$takim;
$wp["302"] = $lakap.$takim."123";
$wp["303"] = $lakap.$takim."1905";
$wp["304"] = $lakap.$takim."1907";
$wp["305"] = $lakap.$takim."1903";
$wp["306"] = $lakap.$takim."1938";
$wp["307"] = $lakap.$takim."1919";
$wp["308"] = $lakap.$takim."1881";
$wp["309"] = $lakap.$takim."2018";
$wp["310"] = $lakap.$takim."2019";
$wp["311"] = $lakap.$takim.$lakap;
$wp["312"] = $lakap.$takim.$anne;
$wp["313"] = $lakap.$takim.$baba;
$wp["314"] = $lakap.$takim.$kardes;
$wp["315"] = $lakap.$takim.$sevgili;
$wp["316"] = $lakap.$takim.$sevgilisoyad;
$wp["317"] = $lakap.$takim.$dogumtarihi;
$wp["318"] = $lakap.$takim.$dogumyili;
$wp["319"] = $lakap.$takim.$cikmayili;
$wp["320"] = $lakap.$takim.$cikmatarihi;
$wp["321"] = $lakap.$takim.$sehir;
$wp["322"] = $lakap.$takim.$takim;
$wp["323"] = $lakap.$takim.$takimtarihi;
$wp["324"] = $lakap.$takim.$takimkisa;
$wp["325"] = $lakap.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $lakap.$takimtarihi;
$wp["327"] = $lakap.$takimtarihi."123";
$wp["328"] = $lakap.$takimtarihi."1905";
$wp["329"] = $lakap.$takimtarihi."1907";
$wp["330"] = $lakap.$takimtarihi."1903";
$wp["331"] = $lakap.$takimtarihi."1938";
$wp["332"] = $lakap.$takimtarihi."1919";
$wp["333"] = $lakap.$takimtarihi."1881";
$wp["334"] = $lakap.$takimtarihi."2018";
$wp["335"] = $lakap.$takimtarihi."2019";
$wp["336"] = $lakap.$takimtarihi.$lakap;
$wp["337"] = $lakap.$takimtarihi.$anne;
$wp["338"] = $lakap.$takimtarihi.$baba;
$wp["339"] = $lakap.$takimtarihi.$kardes;
$wp["340"] = $lakap.$takimtarihi.$sevgili;
$wp["341"] = $lakap.$takimtarihi.$sevgilisoyad;
$wp["342"] = $lakap.$takimtarihi.$dogumtarihi;
$wp["343"] = $lakap.$takimtarihi.$dogumyili;
$wp["344"] = $lakap.$takimtarihi.$cikmayili;
$wp["345"] = $lakap.$takimtarihi.$cikmatarihi;
$wp["346"] = $lakap.$takimtarihi.$sehir;
$wp["347"] = $lakap.$takimtarihi.$takim;
$wp["348"] = $lakap.$takimtarihi.$takimtarihi;
$wp["349"] = $lakap.$takimtarihi.$takimkisa;
$wp["350"] = $lakap.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $lakap.$takimkisa;
$wp["352"] = $lakap.$takimkisa."123";
$wp["353"] = $lakap.$takimkisa."1905";
$wp["354"] = $lakap.$takimkisa."1907";
$wp["355"] = $lakap.$takimkisa."1903";
$wp["356"] = $lakap.$takimkisa."1938";
$wp["357"] = $lakap.$takimkisa."1919";
$wp["358"] = $lakap.$takimkisa."1881";
$wp["359"] = $lakap.$takimkisa."2018";
$wp["360"] = $lakap.$takimkisa."2019";
$wp["361"] = $lakap.$takimkisa.$lakap;
$wp["362"] = $lakap.$takimkisa.$anne;
$wp["363"] = $lakap.$takimkisa.$baba;
$wp["364"] = $lakap.$takimkisa.$kardes;
$wp["365"] = $lakap.$takimkisa.$sevgili;
$wp["366"] = $lakap.$takimkisa.$sevgilisoyad;
$wp["367"] = $lakap.$takimkisa.$dogumtarihi;
$wp["368"] = $lakap.$takimkisa.$dogumyili;
$wp["369"] = $lakap.$takimkisa.$cikmayili;
$wp["370"] = $lakap.$takimkisa.$cikmatarihi;
$wp["371"] = $lakap.$takimkisa.$sehir;
$wp["372"] = $lakap.$takimkisa.$takim;
$wp["373"] = $lakap.$takimkisa.$takimtarihi;
$wp["374"] = $lakap.$takimkisa.$takimkisa;
$wp["375"] = $lakap.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $lakap.$plaka;
$wp["377"] = $lakap.$plaka."123";
$wp["378"] = $lakap.$plaka."1905";
$wp["379"] = $lakap.$plaka."1907";
$wp["380"] = $lakap.$plaka."1903";
$wp["381"] = $lakap.$plaka."1938";
$wp["382"] = $lakap.$plaka."1919";
$wp["383"] = $lakap.$plaka."1881";
$wp["384"] = $lakap.$plaka."2018";
$wp["385"] = $lakap.$plaka."2019";
$wp["386"] = $lakap.$plaka.$lakap;
$wp["387"] = $lakap.$plaka.$anne;
$wp["388"] = $lakap.$plaka.$baba;
$wp["389"] = $lakap.$plaka.$kardes;
$wp["390"] = $lakap.$plaka.$sevgili;
$wp["391"] = $lakap.$plaka.$sevgilisoyad;
$wp["392"] = $lakap.$plaka.$dogumtarihi;
$wp["393"] = $lakap.$plaka.$dogumyili;
$wp["394"] = $lakap.$plaka.$cikmayili;
$wp["395"] = $lakap.$plaka.$cikmatarihi;
$wp["396"] = $lakap.$plaka.$sehir;
$wp["397"] = $lakap.$plaka.$takim;
$wp["398"] = $lakap.$plaka.$takimtarihi;
$wp["399"] = $lakap.$plaka.$takimkisa;
$wp["400"] = $lakap.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $lakap.$eskisifre;
$wp["402"] = $lakap.$eskisifre."123";
$wp["403"] = $lakap.$eskisifre."1905";
$wp["404"] = $lakap.$eskisifre."1907";
$wp["405"] = $lakap.$eskisifre."1903";
$wp["406"] = $lakap.$eskisifre."1938";
$wp["407"] = $lakap.$eskisifre."1919";
$wp["408"] = $lakap.$eskisifre."1881";
$wp["409"] = $lakap.$eskisifre."2018";
$wp["410"] = $lakap.$eskisifre."2019";
$wp["411"] = $lakap.$eskisifre.$lakap;
$wp["412"] = $lakap.$eskisifre.$anne;
$wp["413"] = $lakap.$eskisifre.$baba;
$wp["414"] = $lakap.$eskisifre.$kardes;
$wp["415"] = $lakap.$eskisifre.$sevgili;
$wp["416"] = $lakap.$eskisifre.$sevgilisoyad;
$wp["417"] = $lakap.$eskisifre.$dogumtarihi;
$wp["418"] = $lakap.$eskisifre.$dogumyili;
$wp["419"] = $lakap.$eskisifre.$cikmayili;
$wp["420"] = $lakap.$eskisifre.$cikmatarihi;
$wp["421"] = $lakap.$eskisifre.$sehir;
$wp["422"] = $lakap.$eskisifre.$takim;
$wp["423"] = $lakap.$eskisifre.$takimtarihi;
$wp["424"] = $lakap.$eskisifre.$takimkisa;
$wp["425"] = $lakap.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $lakap.$tel;
$wp["427"] = $lakap.$tel."123";
$wp["428"] = $lakap.$tel."1905";
$wp["429"] = $lakap.$tel."1907";
$wp["430"] = $lakap.$tel."1903";
$wp["431"] = $lakap.$tel."1938";
$wp["432"] = $lakap.$tel."1919";
$wp["433"] = $lakap.$tel."1881";
$wp["434"] = $lakap.$tel."2018";
$wp["435"] = $lakap.$tel."2019";
$wp["436"] = $lakap.$tel.$lakap;
$wp["437"] = $lakap.$tel.$anne;
$wp["438"] = $lakap.$tel.$baba;
$wp["439"] = $lakap.$tel.$kardes;
$wp["440"] = $lakap.$tel.$sevgili;
$wp["441"] = $lakap.$tel.$sevgilisoyad;
$wp["442"] = $lakap.$tel.$dogumtarihi;
$wp["443"] = $lakap.$tel.$dogumyili;
$wp["444"] = $lakap.$tel.$cikmayili;
$wp["445"] = $lakap.$tel.$cikmatarihi;
$wp["446"] = $lakap.$tel.$sehir;
$wp["447"] = $lakap.$tel.$takim;
$wp["448"] = $lakap.$tel.$takimtarihi;
$wp["449"] = $lakap.$tel.$takimkisa;
$wp["450"] = $lakap.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $lakap.$annetel;
$wp["452"] = $lakap.$annetel."123";
$wp["453"] = $lakap.$annetel."1905";
$wp["454"] = $lakap.$annetel."1907";
$wp["455"] = $lakap.$annetel."1903";
$wp["456"] = $lakap.$annetel."1938";
$wp["457"] = $lakap.$annetel."1919";
$wp["458"] = $lakap.$annetel."1881";
$wp["459"] = $lakap.$annetel."2018";
$wp["460"] = $lakap.$annetel."2019";
$wp["461"] = $lakap.$annetel.$lakap;
$wp["462"] = $lakap.$annetel.$anne;
$wp["463"] = $lakap.$annetel.$baba;
$wp["464"] = $lakap.$annetel.$kardes;
$wp["465"] = $lakap.$annetel.$sevgili;
$wp["466"] = $lakap.$annetel.$sevgilisoyad;
$wp["467"] = $lakap.$annetel.$dogumtarihi;
$wp["468"] = $lakap.$annetel.$dogumyili;
$wp["469"] = $lakap.$annetel.$cikmayili;
$wp["470"] = $lakap.$annetel.$cikmatarihi;
$wp["471"] = $lakap.$annetel.$sehir;
$wp["472"] = $lakap.$annetel.$takim;
$wp["473"] = $lakap.$annetel.$takimtarihi;
$wp["474"] = $lakap.$annetel.$takimkisa;
$wp["475"] = $lakap.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $lakap.$babatel;
$wp["477"] = $lakap.$babatel."123";
$wp["478"] = $lakap.$babatel."1905";
$wp["479"] = $lakap.$babatel."1907";
$wp["480"] = $lakap.$babatel."1903";
$wp["481"] = $lakap.$babatel."1938";
$wp["482"] = $lakap.$babatel."1919";
$wp["483"] = $lakap.$babatel."1881";
$wp["484"] = $lakap.$babatel."2018";
$wp["485"] = $lakap.$babatel."2019";
$wp["486"] = $lakap.$babatel.$lakap;
$wp["487"] = $lakap.$babatel.$anne;
$wp["488"] = $lakap.$babatel.$baba;
$wp["489"] = $lakap.$babatel.$kardes;
$wp["490"] = $lakap.$babatel.$sevgili;
$wp["491"] = $lakap.$babatel.$sevgilisoyad;
$wp["492"] = $lakap.$babatel.$dogumtarihi;
$wp["493"] = $lakap.$babatel.$dogumyili;
$wp["494"] = $lakap.$babatel.$cikmayili;
$wp["495"] = $lakap.$babatel.$cikmatarihi;
$wp["496"] = $lakap.$babatel.$sehir;
$wp["497"] = $lakap.$babatel.$takim;
$wp["498"] = $lakap.$babatel.$takimtarihi;
$wp["499"] = $lakap.$babatel.$takimkisa;
$wp["500"] = $lakap.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $lakap.$kardestel;
$wp["502"] = $lakap.$kardestel."123";
$wp["503"] = $lakap.$kardestel."1905";
$wp["504"] = $lakap.$kardestel."1907";
$wp["505"] = $lakap.$kardestel."1903";
$wp["506"] = $lakap.$kardestel."1938";
$wp["507"] = $lakap.$kardestel."1919";
$wp["508"] = $lakap.$kardestel."1881";
$wp["509"] = $lakap.$kardestel."2018";
$wp["510"] = $lakap.$kardestel."2019";
$wp["511"] = $lakap.$kardestel.$lakap;
$wp["512"] = $lakap.$kardestel.$anne;
$wp["513"] = $lakap.$kardestel.$baba;
$wp["514"] = $lakap.$kardestel.$kardes;
$wp["515"] = $lakap.$kardestel.$sevgili;
$wp["516"] = $lakap.$kardestel.$sevgilisoyad;
$wp["517"] = $lakap.$kardestel.$dogumtarihi;
$wp["518"] = $lakap.$kardestel.$dogumyili;
$wp["519"] = $lakap.$kardestel.$cikmayili;
$wp["520"] = $lakap.$kardestel.$cikmatarihi;
$wp["521"] = $lakap.$kardestel.$sehir;
$wp["522"] = $lakap.$kardestel.$takim;
$wp["523"] = $lakap.$kardestel.$takimtarihi;
$wp["524"] = $lakap.$kardestel.$takimkisa;
$wp["525"] = $lakap.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $lakap.$sevgilitel;
$wp["527"] = $lakap.$sevgilitel."123";
$wp["528"] = $lakap.$sevgilitel."1905";
$wp["529"] = $lakap.$sevgilitel."1907";
$wp["530"] = $lakap.$sevgilitel."1903";
$wp["531"] = $lakap.$sevgilitel."1938";
$wp["532"] = $lakap.$sevgilitel."1919";
$wp["533"] = $lakap.$sevgilitel."1881";
$wp["534"] = $lakap.$sevgilitel."2018";
$wp["535"] = $lakap.$sevgilitel."2019";
$wp["536"] = $lakap.$sevgilitel.$lakap;
$wp["537"] = $lakap.$sevgilitel.$anne;
$wp["538"] = $lakap.$sevgilitel.$baba;
$wp["539"] = $lakap.$sevgilitel.$kardes;
$wp["540"] = $lakap.$sevgilitel.$sevgili;
$wp["541"] = $lakap.$sevgilitel.$sevgilisoyad;
$wp["542"] = $lakap.$sevgilitel.$dogumtarihi;
$wp["543"] = $lakap.$sevgilitel.$dogumyili;
$wp["544"] = $lakap.$sevgilitel.$cikmayili;
$wp["545"] = $lakap.$sevgilitel.$cikmatarihi;
$wp["546"] = $lakap.$sevgilitel.$sehir;
$wp["547"] = $lakap.$sevgilitel.$takim;
$wp["548"] = $lakap.$sevgilitel.$takimtarihi;
$wp["549"] = $lakap.$sevgilitel.$takimkisa;
$wp["550"] = $lakap.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $lakap.$tckimlikno;
$wp["552"] = $lakap.$tckimlikno."13";
$wp["553"] = $lakap.$tckimlikno."1905";
$wp["554"] = $lakap.$tckimlikno."1907";
$wp["555"] = $lakap.$tckimlikno."1903";
$wp["556"] = $lakap.$tckimlikno."1938";
$wp["557"] = $lakap.$tckimlikno."1919";
$wp["558"] = $lakap.$tckimlikno."1881";
$wp["559"] = $lakap.$tckimlikno."2018";
$wp["560"] = $lakap.$tckimlikno."2019";
$wp["561"] = $lakap.$tckimlikno.$lakap;
$wp["562"] = $lakap.$tckimlikno.$anne;
$wp["563"] = $lakap.$tckimlikno.$baba;
$wp["564"] = $lakap.$tckimlikno.$kardes;
$wp["565"] = $lakap.$tckimlikno.$sevgili;
$wp["566"] = $lakap.$tckimlikno.$sevgilisoyad;
$wp["567"] = $lakap.$tckimlikno.$dogumtarihi;
$wp["568"] = $lakap.$tckimlikno.$dogumyili;
$wp["569"] = $lakap.$tckimlikno.$cikmayili;
$wp["570"] = $lakap.$tckimlikno.$cikmatarihi;
$wp["571"] = $lakap.$tckimlikno.$sehir;
$wp["572"] = $lakap.$tckimlikno.$takim;
$wp["573"] = $lakap.$tckimlikno.$takimtarihi;
$wp["574"] = $lakap.$tckimlikno.$takimkisa;
$wp["575"] = $lakap.$tckimlikno.$plaka;



for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);


 ?>