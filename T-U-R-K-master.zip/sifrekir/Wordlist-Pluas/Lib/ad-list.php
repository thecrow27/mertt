<?php
error_reporting(0);

include "kayit.php";

/////////////////////////////////////////////////
$wp["1"] = $ad;
$wp["2"] = $ad.$soyadad."123";
$wp["3"] = $ad.$soyadad."1905";
$wp["4"] = $ad.$soyadad."1907";
$wp["5"] = $ad.$soyadad."1903";
$wp["6"] = $ad.$soyadad."1938";
$wp["7"] = $ad.$soyadad."1919";
$wp["8"] = $ad.$soyadad."1881";
$wp["9"] = $ad.$soyadad."2018";
$wp["10"] = $ad.$soyadad."2019";
$wp["11"] = $ad.$soyadad.$lakap;
$wp["12"] = $ad.$soyadad.$anne;
$wp["13"] = $ad.$soyadad.$baba;
$wp["14"] = $ad.$soyadad.$kardes;
$wp["15"] = $ad.$soyadad.$sevgili;
$wp["16"] = $ad.$soyadad.$sevgilisoyad;
$wp["17"] = $ad.$soyadad.$dogumtarihi;
$wp["18"] = $ad.$soyadad.$dogumyili;
$wp["19"] = $ad.$soyadad.$cikmayili;
$wp["20"] = $ad.$soyadad.$cikmatarihi;
$wp["21"] = $ad.$soyadad.$sehir;
$wp["22"] = $ad.$soyadad.$takim;
$wp["23"] = $ad.$soyadad.$takimtarihi;
$wp["24"] = $ad.$soyadad.$takimkisa;
$wp["25"] = $ad.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $ad.$lakap;
$wp["27"] = $ad.$lakap."123";
$wp["28"] = $ad.$lakap."1905";
$wp["29"] = $ad.$lakap."1907";
$wp["30"] = $ad.$lakap."1903";
$wp["31"] = $ad.$lakap."1938";
$wp["32"] = $ad.$lakap."1919";
$wp["33"] = $ad.$lakap."1881";
$wp["34"] = $ad.$lakap."2018";
$wp["35"] = $ad.$lakap."2019";
$wp["36"] = $ad.$lakap.$lakap;
$wp["37"] = $ad.$lakap.$anne;
$wp["38"] = $ad.$lakap.$baba;
$wp["39"] = $ad.$lakap.$kardes;
$wp["40"] = $ad.$lakap.$sevgili;
$wp["41"] = $ad.$lakap.$sevgilisoyad;
$wp["42"] = $ad.$lakap.$dogumtarihi;
$wp["43"] = $ad.$lakap.$dogumyili;
$wp["44"] = $ad.$lakap.$cikmayili;
$wp["45"] = $ad.$lakap.$cikmatarihi;
$wp["46"] = $ad.$lakap.$sehir;
$wp["47"] = $ad.$lakap.$takim;
$wp["48"] = $ad.$lakap.$takimtarihi;
$wp["49"] = $ad.$lakap.$takimkisa;
$wp["50"] = $ad.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $ad.$anne;
$wp["52"] = $ad.$anne."123";
$wp["53"] = $ad.$anne."1905";
$wp["54"] = $ad.$anne."1907";
$wp["55"] = $ad.$anne."1903";
$wp["56"] = $ad.$anne."1938";
$wp["57"] = $ad.$anne."1919";
$wp["58"] = $ad.$anne."1881";
$wp["59"] = $ad.$anne."2018";
$wp["60"] = $ad.$anne."2019";
$wp["61"] = $ad.$anne.$lakap;
$wp["62"] = $ad.$anne.$anne;
$wp["63"] = $ad.$anne.$baba;
$wp["64"] = $ad.$anne.$kardes;
$wp["65"] = $ad.$anne.$sevgili;
$wp["66"] = $ad.$anne.$sevgilisoyad;
$wp["67"] = $ad.$anne.$dogumtarihi;
$wp["68"] = $ad.$anne.$dogumyili;
$wp["69"] = $ad.$anne.$cikmayili;
$wp["70"] = $ad.$anne.$cikmatarihi;
$wp["71"] = $ad.$anne.$sehir;
$wp["72"] = $ad.$anne.$takim;
$wp["73"] = $ad.$anne.$takimtarihi;
$wp["74"] = $ad.$anne.$takimkisa;
$wp["75"] = $ad.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $ad.$baba;
$wp["77"] = $ad.$baba."123";
$wp["78"] = $ad.$baba."1905";
$wp["79"] = $ad.$baba."1907";
$wp["80"] = $ad.$baba."1903";
$wp["81"] = $ad.$baba."1938";
$wp["82"] = $ad.$baba."1919";
$wp["83"] = $ad.$baba."1881";
$wp["84"] = $ad.$baba."2018";
$wp["85"] = $ad.$baba."2019";
$wp["86"] = $ad.$baba.$lakap;
$wp["87"] = $ad.$baba.$anne;
$wp["88"] = $ad.$baba.$baba;
$wp["89"] = $ad.$baba.$kardes;
$wp["90"] = $ad.$baba.$sevgili;
$wp["91"] = $ad.$baba.$sevgilisoyad;
$wp["92"] = $ad.$baba.$dogumtarihi;
$wp["93"] = $ad.$baba.$dogumyili;
$wp["94"] = $ad.$baba.$cikmayili;
$wp["95"] = $ad.$baba.$cikmatarihi;
$wp["96"] = $ad.$baba.$sehir;
$wp["97"] = $ad.$baba.$takim;
$wp["98"] = $ad.$baba.$takimtarihi;
$wp["99"] = $ad.$baba.$takimkisa;
$wp["100"] = $ad.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $ad.$kardes;
$wp["102"] = $ad.$kardes."123";
$wp["103"] = $ad.$kardes."1905";
$wp["104"] = $ad.$kardes."1907";
$wp["105"] = $ad.$kardes."1903";
$wp["106"] = $ad.$kardes."1938";
$wp["107"] = $ad.$kardes."1919";
$wp["108"] = $ad.$kardes."1881";
$wp["109"] = $ad.$kardes."2018";
$wp["110"] = $ad.$kardes."2019";
$wp["111"] = $ad.$kardes.$lakap;
$wp["112"] = $ad.$kardes.$anne;
$wp["113"] = $ad.$kardes.$baba;
$wp["114"] = $ad.$kardes.$kardes;
$wp["115"] = $ad.$kardes.$sevgili;
$wp["116"] = $ad.$kardes.$sevgilisoyad;
$wp["117"] = $ad.$kardes.$dogumtarihi;
$wp["118"] = $ad.$kardes.$dogumyili;
$wp["119"] = $ad.$kardes.$cikmayili;
$wp["120"] = $ad.$kardes.$cikmatarihi;
$wp["121"] = $ad.$kardes.$sehir;
$wp["122"] = $ad.$kardes.$takim;
$wp["123"] = $ad.$kardes.$takimtarihi;
$wp["124"] = $ad.$kardes.$takimkisa;
$wp["125"] = $ad.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $ad.$sevgili;
$wp["127"] = $ad.$sevgili."123";
$wp["128"] = $ad.$sevgili."1905";
$wp["129"] = $ad.$sevgili."1907";
$wp["130"] = $ad.$sevgili."1903";
$wp["131"] = $ad.$sevgili."1938";
$wp["132"] = $ad.$sevgili."1919";
$wp["133"] = $ad.$sevgili."1881";
$wp["134"] = $ad.$sevgili."2018";
$wp["135"] = $ad.$sevgili."2019";
$wp["136"] = $ad.$sevgili.$lakap;
$wp["137"] = $ad.$sevgili.$anne;
$wp["138"] = $ad.$sevgili.$baba;
$wp["139"] = $ad.$sevgili.$kardes;
$wp["140"] = $ad.$sevgili.$sevgili;
$wp["141"] = $ad.$sevgili.$sevgilisoyad;
$wp["142"] = $ad.$sevgili.$dogumtarihi;
$wp["143"] = $ad.$sevgili.$dogumyili;
$wp["144"] = $ad.$sevgili.$cikmayili;
$wp["145"] = $ad.$sevgili.$cikmatarihi;
$wp["146"] = $ad.$sevgili.$sehir;
$wp["147"] = $ad.$sevgili.$takim;
$wp["148"] = $ad.$sevgili.$takimtarihi;
$wp["149"] = $ad.$sevgili.$takimkisa;
$wp["150"] = $ad.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $ad.$sevgilisoyad;
$wp["152"] = $ad.$sevgilisoyad."123";
$wp["153"] = $ad.$sevgilisoyad."1905";
$wp["154"] = $ad.$sevgilisoyad."1907";
$wp["155"] = $ad.$sevgilisoyad."1903";
$wp["156"] = $ad.$sevgilisoyad."1938";
$wp["157"] = $ad.$sevgilisoyad."1919";
$wp["158"] = $ad.$sevgilisoyad."1881";
$wp["159"] = $ad.$sevgilisoyad."2018";
$wp["160"] = $ad.$sevgilisoyad."2019";
$wp["161"] = $ad.$sevgilisoyad.$lakap;
$wp["162"] = $ad.$sevgilisoyad.$anne;
$wp["163"] = $ad.$sevgilisoyad.$baba;
$wp["164"] = $ad.$sevgilisoyad.$kardes;
$wp["165"] = $ad.$sevgilisoyad.$sevgili;
$wp["166"] = $ad.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $ad.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $ad.$sevgilisoyad.$dogumyili;
$wp["169"] = $ad.$sevgilisoyad.$cikmayili;
$wp["170"] = $ad.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $ad.$sevgilisoyad.$sehir;
$wp["172"] = $ad.$sevgilisoyad.$takim;
$wp["173"] = $ad.$sevgilisoyad.$takimtarihi;
$wp["174"] = $ad.$sevgilisoyad.$takimkisa;
$wp["175"] = $ad.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $ad.$dogumtarihi;
$wp["177"] = $ad.$dogumtarihi."123";
$wp["178"] = $ad.$dogumtarihi."1905";
$wp["179"] = $ad.$dogumtarihi."1907";
$wp["180"] = $ad.$dogumtarihi."1903";
$wp["181"] = $ad.$dogumtarihi."1938";
$wp["200"] = $ad.$dogumtarihi."1919";
$wp["182"] = $ad.$dogumtarihi."1881";
$wp["183"] = $ad.$dogumtarihi."2018";
$wp["184"] = $ad.$dogumtarihi."2019";
$wp["185"] = $ad.$dogumtarihi.$lakap;
$wp["186"] = $ad.$dogumtarihi.$anne;
$wp["187"] = $ad.$dogumtarihi.$baba;
$wp["188"] = $ad.$dogumtarihi.$kardes;
$wp["189"] = $ad.$dogumtarihi.$sevgili;
$wp["190"] = $ad.$dogumtarihi.$dogumtarihi;
$wp["191"] = $ad.$dogumtarihi.$dogumtarihi;
$wp["192"] = $ad.$dogumtarihi.$dogumyili;
$wp["193"] = $ad.$dogumtarihi.$cikmayili;
$wp["194"] = $ad.$dogumtarihi.$cikmatarihi;
$wp["195"] = $ad.$dogumtarihi.$sehir;
$wp["196"] = $ad.$dogumtarihi.$takim;
$wp["197"] = $ad.$dogumtarihi.$takimtarihi;
$wp["198"] = $ad.$dogumtarihi.$takimkisa;
$wp["199"] = $ad.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $ad.$dogumyili;
$wp["202"] = $ad.$dogumyili."123";
$wp["203"] = $ad.$dogumyili."1905";
$wp["204"] = $ad.$dogumyili."1907";
$wp["205"] = $ad.$dogumyili."1903";
$wp["206"] = $ad.$dogumyili."1938";
$wp["207"] = $ad.$dogumyili."1919";
$wp["208"] = $ad.$dogumyili."1881";
$wp["209"] = $ad.$dogumyili."2018";
$wp["210"] = $ad.$dogumyili."2019";
$wp["211"] = $ad.$dogumyili.$lakap;
$wp["212"] = $ad.$dogumyili.$anne;
$wp["213"] = $ad.$dogumyili.$baba;
$wp["214"] = $ad.$dogumyili.$kardes;
$wp["215"] = $ad.$dogumyili.$sevgili;
$wp["216"] = $ad.$dogumyili.$dogumyili;
$wp["217"] = $ad.$dogumyili.$dogumyili;
$wp["218"] = $ad.$dogumyili.$dogumyili;
$wp["219"] = $ad.$dogumyili.$cikmayili;
$wp["220"] = $ad.$dogumyili.$cikmatarihi;
$wp["221"] = $ad.$dogumyili.$sehir;
$wp["222"] = $ad.$dogumyili.$takim;
$wp["223"] = $ad.$dogumyili.$takimtarihi;
$wp["224"] = $ad.$dogumyili.$takimkisa;
$wp["225"] = $ad.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $ad.$cikmayili;
$wp["227"] = $ad.$cikmayili."123";
$wp["228"] = $ad.$cikmayili."1905";
$wp["229"] = $ad.$cikmayili."1907";
$wp["230"] = $ad.$cikmayili."1903";
$wp["231"] = $ad.$cikmayili."1938";
$wp["232"] = $ad.$cikmayili."1919";
$wp["233"] = $ad.$cikmayili."1881";
$wp["234"] = $ad.$cikmayili."2018";
$wp["235"] = $ad.$cikmayili."2019";
$wp["236"] = $ad.$cikmayili.$lakap;
$wp["237"] = $ad.$cikmayili.$anne;
$wp["238"] = $ad.$cikmayili.$baba;
$wp["239"] = $ad.$cikmayili.$kardes;
$wp["240"] = $ad.$cikmayili.$sevgili;
$wp["241"] = $ad.$cikmayili.$cikmayili;
$wp["242"] = $ad.$cikmayili.$dogumyili;
$wp["243"] = $ad.$cikmayili.$cikmayili;
$wp["244"] = $ad.$cikmayili.$cikmayili;
$wp["245"] = $ad.$cikmayili.$cikmatarihi;
$wp["246"] = $ad.$cikmayili.$sehir;
$wp["247"] = $ad.$cikmayili.$takim;
$wp["248"] = $ad.$cikmayili.$takimtarihi;
$wp["249"] = $ad.$cikmayili.$takimkisa;
$wp["250"] = $ad.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $ad.$cikmatarihi;
$wp["252"] = $ad.$cikmatarihi."123";
$wp["253"] = $ad.$cikmatarihi."1905";
$wp["254"] = $ad.$cikmatarihi."1907";
$wp["255"] = $ad.$cikmatarihi."1903";
$wp["256"] = $ad.$cikmatarihi."1938";
$wp["257"] = $ad.$cikmatarihi."1919";
$wp["258"] = $ad.$cikmatarihi."1881";
$wp["259"] = $ad.$cikmatarihi."2018";
$wp["260"] = $ad.$cikmatarihi."2019";
$wp["261"] = $ad.$cikmatarihi.$lakap;
$wp["262"] = $ad.$cikmatarihi.$anne;
$wp["263"] = $ad.$cikmatarihi.$baba;
$wp["264"] = $ad.$cikmatarihi.$kardes;
$wp["265"] = $ad.$cikmatarihi.$sevgili;
$wp["267"] = $ad.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $ad.$cikmatarihi.$dogumtarihi;
$wp["269"] = $ad.$cikmatarihi.$dogumyili;
$wp["270"] = $ad.$cikmatarihi.$cikmayili;
$wp["271"] = $ad.$cikmatarihi.$cikmatarihi;
$wp["272"] = $ad.$cikmatarihi.$sehir;
$wp["273"] = $ad.$cikmatarihi.$takim;
$wp["274"] = $ad.$cikmatarihi.$takimtarihi;
$wp["275"] = $ad.$cikmatarihi.$takimkisa;
$wp["266"] = $ad.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $ad.$sehir;
$wp["277"] = $ad.$sehir."123";
$wp["278"] = $ad.$sehir."1905";
$wp["279"] = $ad.$sehir."1907";
$wp["280"] = $ad.$sehir."1903";
$wp["281"] = $ad.$sehir."1938";
$wp["282"] = $ad.$sehir."1919";
$wp["283"] = $ad.$sehir."1881";
$wp["284"] = $ad.$sehir."2018";
$wp["285"] = $ad.$sehir."2019";
$wp["286"] = $ad.$sehir.$lakap;
$wp["287"] = $ad.$sehir.$anne;
$wp["288"] = $ad.$sehir.$baba;
$wp["289"] = $ad.$sehir.$kardes;
$wp["290"] = $ad.$sehir.$sevgili;
$wp["291"] = $ad.$sehir.$sevgilisoyad;
$wp["292"] = $ad.$sehir.$dogumtarihi;
$wp["293"] = $ad.$sehir.$dogumyili;
$wp["294"] = $ad.$sehir.$cikmayili;
$wp["295"] = $ad.$sehir.$cikmatarihi;
$wp["296"] = $ad.$sehir.$sehir;
$wp["297"] = $ad.$sehir.$takim;
$wp["298"] = $ad.$sehir.$takimtarihi;
$wp["299"] = $ad.$sehir.$takimkisa;
$wp["300"] = $ad.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $ad.$takim;
$wp["302"] = $ad.$takim."123";
$wp["303"] = $ad.$takim."1905";
$wp["304"] = $ad.$takim."1907";
$wp["305"] = $ad.$takim."1903";
$wp["306"] = $ad.$takim."1938";
$wp["307"] = $ad.$takim."1919";
$wp["308"] = $ad.$takim."1881";
$wp["309"] = $ad.$takim."2018";
$wp["310"] = $ad.$takim."2019";
$wp["311"] = $ad.$takim.$lakap;
$wp["312"] = $ad.$takim.$anne;
$wp["313"] = $ad.$takim.$baba;
$wp["314"] = $ad.$takim.$kardes;
$wp["315"] = $ad.$takim.$sevgili;
$wp["316"] = $ad.$takim.$sevgilisoyad;
$wp["317"] = $ad.$takim.$dogumtarihi;
$wp["318"] = $ad.$takim.$dogumyili;
$wp["319"] = $ad.$takim.$cikmayili;
$wp["320"] = $ad.$takim.$cikmatarihi;
$wp["321"] = $ad.$takim.$sehir;
$wp["322"] = $ad.$takim.$takim;
$wp["323"] = $ad.$takim.$takimtarihi;
$wp["324"] = $ad.$takim.$takimkisa;
$wp["325"] = $ad.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $ad.$takimtarihi;
$wp["327"] = $ad.$takimtarihi."123";
$wp["328"] = $ad.$takimtarihi."1905";
$wp["329"] = $ad.$takimtarihi."1907";
$wp["330"] = $ad.$takimtarihi."1903";
$wp["331"] = $ad.$takimtarihi."1938";
$wp["332"] = $ad.$takimtarihi."1919";
$wp["333"] = $ad.$takimtarihi."1881";
$wp["334"] = $ad.$takimtarihi."2018";
$wp["335"] = $ad.$takimtarihi."2019";
$wp["336"] = $ad.$takimtarihi.$lakap;
$wp["337"] = $ad.$takimtarihi.$anne;
$wp["338"] = $ad.$takimtarihi.$baba;
$wp["339"] = $ad.$takimtarihi.$kardes;
$wp["340"] = $ad.$takimtarihi.$sevgili;
$wp["341"] = $ad.$takimtarihi.$sevgilisoyad;
$wp["342"] = $ad.$takimtarihi.$dogumtarihi;
$wp["343"] = $ad.$takimtarihi.$dogumyili;
$wp["344"] = $ad.$takimtarihi.$cikmayili;
$wp["345"] = $ad.$takimtarihi.$cikmatarihi;
$wp["346"] = $ad.$takimtarihi.$sehir;
$wp["347"] = $ad.$takimtarihi.$takim;
$wp["348"] = $ad.$takimtarihi.$takimtarihi;
$wp["349"] = $ad.$takimtarihi.$takimkisa;
$wp["350"] = $ad.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $ad.$takimkisa;
$wp["352"] = $ad.$takimkisa."123";
$wp["353"] = $ad.$takimkisa."1905";
$wp["354"] = $ad.$takimkisa."1907";
$wp["355"] = $ad.$takimkisa."1903";
$wp["356"] = $ad.$takimkisa."1938";
$wp["357"] = $ad.$takimkisa."1919";
$wp["358"] = $ad.$takimkisa."1881";
$wp["359"] = $ad.$takimkisa."2018";
$wp["360"] = $ad.$takimkisa."2019";
$wp["361"] = $ad.$takimkisa.$lakap;
$wp["362"] = $ad.$takimkisa.$anne;
$wp["363"] = $ad.$takimkisa.$baba;
$wp["364"] = $ad.$takimkisa.$kardes;
$wp["365"] = $ad.$takimkisa.$sevgili;
$wp["366"] = $ad.$takimkisa.$sevgilisoyad;
$wp["367"] = $ad.$takimkisa.$dogumtarihi;
$wp["368"] = $ad.$takimkisa.$dogumyili;
$wp["369"] = $ad.$takimkisa.$cikmayili;
$wp["370"] = $ad.$takimkisa.$cikmatarihi;
$wp["371"] = $ad.$takimkisa.$sehir;
$wp["372"] = $ad.$takimkisa.$takim;
$wp["373"] = $ad.$takimkisa.$takimtarihi;
$wp["374"] = $ad.$takimkisa.$takimkisa;
$wp["375"] = $ad.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $ad.$plaka;
$wp["377"] = $ad.$plaka."123";
$wp["378"] = $ad.$plaka."1905";
$wp["379"] = $ad.$plaka."1907";
$wp["380"] = $ad.$plaka."1903";
$wp["381"] = $ad.$plaka."1938";
$wp["382"] = $ad.$plaka."1919";
$wp["383"] = $ad.$plaka."1881";
$wp["384"] = $ad.$plaka."2018";
$wp["385"] = $ad.$plaka."2019";
$wp["386"] = $ad.$plaka.$lakap;
$wp["387"] = $ad.$plaka.$anne;
$wp["388"] = $ad.$plaka.$baba;
$wp["389"] = $ad.$plaka.$kardes;
$wp["390"] = $ad.$plaka.$sevgili;
$wp["391"] = $ad.$plaka.$sevgilisoyad;
$wp["392"] = $ad.$plaka.$dogumtarihi;
$wp["393"] = $ad.$plaka.$dogumyili;
$wp["394"] = $ad.$plaka.$cikmayili;
$wp["395"] = $ad.$plaka.$cikmatarihi;
$wp["396"] = $ad.$plaka.$sehir;
$wp["397"] = $ad.$plaka.$takim;
$wp["398"] = $ad.$plaka.$takimtarihi;
$wp["399"] = $ad.$plaka.$takimkisa;
$wp["400"] = $ad.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $ad.$eskisifre;
$wp["402"] = $ad.$eskisifre."123";
$wp["403"] = $ad.$eskisifre."1905";
$wp["404"] = $ad.$eskisifre."1907";
$wp["405"] = $ad.$eskisifre."1903";
$wp["406"] = $ad.$eskisifre."1938";
$wp["407"] = $ad.$eskisifre."1919";
$wp["408"] = $ad.$eskisifre."1881";
$wp["409"] = $ad.$eskisifre."2018";
$wp["410"] = $ad.$eskisifre."2019";
$wp["411"] = $ad.$eskisifre.$lakap;
$wp["412"] = $ad.$eskisifre.$anne;
$wp["413"] = $ad.$eskisifre.$baba;
$wp["414"] = $ad.$eskisifre.$kardes;
$wp["415"] = $ad.$eskisifre.$sevgili;
$wp["416"] = $ad.$eskisifre.$sevgilisoyad;
$wp["417"] = $ad.$eskisifre.$dogumtarihi;
$wp["418"] = $ad.$eskisifre.$dogumyili;
$wp["419"] = $ad.$eskisifre.$cikmayili;
$wp["420"] = $ad.$eskisifre.$cikmatarihi;
$wp["421"] = $ad.$eskisifre.$sehir;
$wp["422"] = $ad.$eskisifre.$takim;
$wp["423"] = $ad.$eskisifre.$takimtarihi;
$wp["424"] = $ad.$eskisifre.$takimkisa;
$wp["425"] = $ad.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $ad.$tel;
$wp["427"] = $ad.$tel."123";
$wp["428"] = $ad.$tel."1905";
$wp["429"] = $ad.$tel."1907";
$wp["430"] = $ad.$tel."1903";
$wp["431"] = $ad.$tel."1938";
$wp["432"] = $ad.$tel."1919";
$wp["433"] = $ad.$tel."1881";
$wp["434"] = $ad.$tel."2018";
$wp["435"] = $ad.$tel."2019";
$wp["436"] = $ad.$tel.$lakap;
$wp["437"] = $ad.$tel.$anne;
$wp["438"] = $ad.$tel.$baba;
$wp["439"] = $ad.$tel.$kardes;
$wp["440"] = $ad.$tel.$sevgili;
$wp["441"] = $ad.$tel.$sevgilisoyad;
$wp["442"] = $ad.$tel.$dogumtarihi;
$wp["443"] = $ad.$tel.$dogumyili;
$wp["444"] = $ad.$tel.$cikmayili;
$wp["445"] = $ad.$tel.$cikmatarihi;
$wp["446"] = $ad.$tel.$sehir;
$wp["447"] = $ad.$tel.$takim;
$wp["448"] = $ad.$tel.$takimtarihi;
$wp["449"] = $ad.$tel.$takimkisa;
$wp["450"] = $ad.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $ad.$annetel;
$wp["452"] = $ad.$annetel."123";
$wp["453"] = $ad.$annetel."1905";
$wp["454"] = $ad.$annetel."1907";
$wp["455"] = $ad.$annetel."1903";
$wp["456"] = $ad.$annetel."1938";
$wp["457"] = $ad.$annetel."1919";
$wp["458"] = $ad.$annetel."1881";
$wp["459"] = $ad.$annetel."2018";
$wp["460"] = $ad.$annetel."2019";
$wp["461"] = $ad.$annetel.$lakap;
$wp["462"] = $ad.$annetel.$anne;
$wp["463"] = $ad.$annetel.$baba;
$wp["464"] = $ad.$annetel.$kardes;
$wp["465"] = $ad.$annetel.$sevgili;
$wp["466"] = $ad.$annetel.$sevgilisoyad;
$wp["467"] = $ad.$annetel.$dogumtarihi;
$wp["468"] = $ad.$annetel.$dogumyili;
$wp["469"] = $ad.$annetel.$cikmayili;
$wp["470"] = $ad.$annetel.$cikmatarihi;
$wp["471"] = $ad.$annetel.$sehir;
$wp["472"] = $ad.$annetel.$takim;
$wp["473"] = $ad.$annetel.$takimtarihi;
$wp["474"] = $ad.$annetel.$takimkisa;
$wp["475"] = $ad.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $ad.$babatel;
$wp["477"] = $ad.$babatel."123";
$wp["478"] = $ad.$babatel."1905";
$wp["479"] = $ad.$babatel."1907";
$wp["480"] = $ad.$babatel."1903";
$wp["481"] = $ad.$babatel."1938";
$wp["482"] = $ad.$babatel."1919";
$wp["483"] = $ad.$babatel."1881";
$wp["484"] = $ad.$babatel."2018";
$wp["485"] = $ad.$babatel."2019";
$wp["486"] = $ad.$babatel.$lakap;
$wp["487"] = $ad.$babatel.$anne;
$wp["488"] = $ad.$babatel.$baba;
$wp["489"] = $ad.$babatel.$kardes;
$wp["490"] = $ad.$babatel.$sevgili;
$wp["491"] = $ad.$babatel.$sevgilisoyad;
$wp["492"] = $ad.$babatel.$dogumtarihi;
$wp["493"] = $ad.$babatel.$dogumyili;
$wp["494"] = $ad.$babatel.$cikmayili;
$wp["495"] = $ad.$babatel.$cikmatarihi;
$wp["496"] = $ad.$babatel.$sehir;
$wp["497"] = $ad.$babatel.$takim;
$wp["498"] = $ad.$babatel.$takimtarihi;
$wp["499"] = $ad.$babatel.$takimkisa;
$wp["500"] = $ad.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $ad.$kardestel;
$wp["502"] = $ad.$kardestel."123";
$wp["503"] = $ad.$kardestel."1905";
$wp["504"] = $ad.$kardestel."1907";
$wp["505"] = $ad.$kardestel."1903";
$wp["506"] = $ad.$kardestel."1938";
$wp["507"] = $ad.$kardestel."1919";
$wp["508"] = $ad.$kardestel."1881";
$wp["509"] = $ad.$kardestel."2018";
$wp["510"] = $ad.$kardestel."2019";
$wp["511"] = $ad.$kardestel.$lakap;
$wp["512"] = $ad.$kardestel.$anne;
$wp["513"] = $ad.$kardestel.$baba;
$wp["514"] = $ad.$kardestel.$kardes;
$wp["515"] = $ad.$kardestel.$sevgili;
$wp["516"] = $ad.$kardestel.$sevgilisoyad;
$wp["517"] = $ad.$kardestel.$dogumtarihi;
$wp["518"] = $ad.$kardestel.$dogumyili;
$wp["519"] = $ad.$kardestel.$cikmayili;
$wp["520"] = $ad.$kardestel.$cikmatarihi;
$wp["521"] = $ad.$kardestel.$sehir;
$wp["522"] = $ad.$kardestel.$takim;
$wp["523"] = $ad.$kardestel.$takimtarihi;
$wp["524"] = $ad.$kardestel.$takimkisa;
$wp["525"] = $ad.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $ad.$sevgilitel;
$wp["527"] = $ad.$sevgilitel."123";
$wp["528"] = $ad.$sevgilitel."1905";
$wp["529"] = $ad.$sevgilitel."1907";
$wp["530"] = $ad.$sevgilitel."1903";
$wp["531"] = $ad.$sevgilitel."1938";
$wp["532"] = $ad.$sevgilitel."1919";
$wp["533"] = $ad.$sevgilitel."1881";
$wp["534"] = $ad.$sevgilitel."2018";
$wp["535"] = $ad.$sevgilitel."2019";
$wp["536"] = $ad.$sevgilitel.$lakap;
$wp["537"] = $ad.$sevgilitel.$anne;
$wp["538"] = $ad.$sevgilitel.$baba;
$wp["539"] = $ad.$sevgilitel.$kardes;
$wp["540"] = $ad.$sevgilitel.$sevgili;
$wp["541"] = $ad.$sevgilitel.$sevgilisoyad;
$wp["542"] = $ad.$sevgilitel.$dogumtarihi;
$wp["543"] = $ad.$sevgilitel.$dogumyili;
$wp["544"] = $ad.$sevgilitel.$cikmayili;
$wp["545"] = $ad.$sevgilitel.$cikmatarihi;
$wp["546"] = $ad.$sevgilitel.$sehir;
$wp["547"] = $ad.$sevgilitel.$takim;
$wp["548"] = $ad.$sevgilitel.$takimtarihi;
$wp["549"] = $ad.$sevgilitel.$takimkisa;
$wp["550"] = $ad.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $ad.$tckimlikno;
$wp["552"] = $ad.$tckimlikno."13";
$wp["553"] = $ad.$tckimlikno."1905";
$wp["554"] = $ad.$tckimlikno."1907";
$wp["555"] = $ad.$tckimlikno."1903";
$wp["556"] = $ad.$tckimlikno."1938";
$wp["557"] = $ad.$tckimlikno."1919";
$wp["558"] = $ad.$tckimlikno."1881";
$wp["559"] = $ad.$tckimlikno."2018";
$wp["560"] = $ad.$tckimlikno."2019";
$wp["561"] = $ad.$tckimlikno.$lakap;
$wp["562"] = $ad.$tckimlikno.$anne;
$wp["563"] = $ad.$tckimlikno.$baba;
$wp["564"] = $ad.$tckimlikno.$kardes;
$wp["565"] = $ad.$tckimlikno.$sevgili;
$wp["566"] = $ad.$tckimlikno.$sevgilisoyad;
$wp["567"] = $ad.$tckimlikno.$dogumtarihi;
$wp["568"] = $ad.$tckimlikno.$dogumyili;
$wp["569"] = $ad.$tckimlikno.$cikmayili;
$wp["570"] = $ad.$tckimlikno.$cikmatarihi;
$wp["571"] = $ad.$tckimlikno.$sehir;
$wp["572"] = $ad.$tckimlikno.$takim;
$wp["573"] = $ad.$tckimlikno.$takimtarihi;
$wp["574"] = $ad.$tckimlikno.$takimkisa;
$wp["575"] = $ad.$tckimlikno.$plaka;

/////////////////////////////////////////









for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);






 ?>