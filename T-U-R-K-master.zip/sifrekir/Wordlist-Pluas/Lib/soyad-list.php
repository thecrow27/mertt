<?php 	

error_reporting(0);

include "kayit.php";

$wp["1"] = $soyadad;
$wp["2"] = $soyadad.$ad."123";
$wp["3"] = $soyadad.$ad."1905";
$wp["4"] = $soyadad.$ad."1907";
$wp["5"] = $soyadad.$ad."1903";
$wp["6"] = $soyadad.$ad."1938";
$wp["7"] = $soyadad.$ad."1919";
$wp["8"] = $soyadad.$ad."1881";
$wp["9"] = $soyadad.$ad."2018";
$wp["10"] = $soyadad.$ad."2019";
$wp["11"] = $soyadad.$ad.$lakap;
$wp["12"] = $soyadad.$ad.$anne;
$wp["13"] = $soyadad.$ad.$baba;
$wp["14"] = $soyadad.$ad.$kardes;
$wp["15"] = $soyadad.$ad.$sevgili;
$wp["16"] = $soyadad.$ad.$sevgilisoyad;
$wp["17"] = $soyadad.$ad.$dogumtarihi;
$wp["18"] = $soyadad.$ad.$dogumyili;
$wp["19"] = $soyadad.$ad.$cikmayili;
$wp["20"] = $soyadad.$ad.$cikmatarihi;
$wp["21"] = $soyadad.$ad.$sehir;
$wp["22"] = $soyadad.$ad.$takim;
$wp["23"] = $soyadad.$ad.$takimtarihi;
$wp["24"] = $soyadad.$ad.$takimkisa;
$wp["25"] = $soyadad.$ad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $soyadad.$lakap;
$wp["27"] = $soyadad.$lakap."123";
$wp["28"] = $soyadad.$lakap."1905";
$wp["29"] = $soyadad.$lakap."1907";
$wp["30"] = $soyadad.$lakap."1903";
$wp["31"] = $soyadad.$lakap."1938";
$wp["32"] = $soyadad.$lakap."1919";
$wp["33"] = $soyadad.$lakap."1881";
$wp["34"] = $soyadad.$lakap."2018";
$wp["35"] = $soyadad.$lakap."2019";
$wp["36"] = $soyadad.$lakap.$lakap;
$wp["37"] = $soyadad.$lakap.$anne;
$wp["38"] = $soyadad.$lakap.$baba;
$wp["39"] = $soyadad.$lakap.$kardes;
$wp["40"] = $soyadad.$lakap.$sevgili;
$wp["41"] = $soyadad.$lakap.$sevgilisoyad;
$wp["42"] = $soyadad.$lakap.$dogumtarihi;
$wp["43"] = $soyadad.$lakap.$dogumyili;
$wp["44"] = $soyadad.$lakap.$cikmayili;
$wp["45"] = $soyadad.$lakap.$cikmatarihi;
$wp["46"] = $soyadad.$lakap.$sehir;
$wp["47"] = $soyadad.$lakap.$takim;
$wp["48"] = $soyadad.$lakap.$takimtarihi;
$wp["49"] = $soyadad.$lakap.$takimkisa;
$wp["50"] = $soyadad.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $soyadad.$anne;
$wp["52"] = $soyadad.$anne."123";
$wp["53"] = $soyadad.$anne."1905";
$wp["54"] = $soyadad.$anne."1907";
$wp["55"] = $soyadad.$anne."1903";
$wp["56"] = $soyadad.$anne."1938";
$wp["57"] = $soyadad.$anne."1919";
$wp["58"] = $soyadad.$anne."1881";
$wp["59"] = $soyadad.$anne."2018";
$wp["60"] = $soyadad.$anne."2019";
$wp["61"] = $soyadad.$anne.$lakap;
$wp["62"] = $soyadad.$anne.$anne;
$wp["63"] = $soyadad.$anne.$baba;
$wp["64"] = $soyadad.$anne.$kardes;
$wp["65"] = $soyadad.$anne.$sevgili;
$wp["66"] = $soyadad.$anne.$sevgilisoyad;
$wp["67"] = $soyadad.$anne.$dogumtarihi;
$wp["68"] = $soyadad.$anne.$dogumyili;
$wp["69"] = $soyadad.$anne.$cikmayili;
$wp["70"] = $soyadad.$anne.$cikmatarihi;
$wp["71"] = $soyadad.$anne.$sehir;
$wp["72"] = $soyadad.$anne.$takim;
$wp["73"] = $soyadad.$anne.$takimtarihi;
$wp["74"] = $soyadad.$anne.$takimkisa;
$wp["75"] = $soyadad.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $soyadad.$baba;
$wp["77"] = $soyadad.$baba."123";
$wp["78"] = $soyadad.$baba."1905";
$wp["79"] = $soyadad.$baba."1907";
$wp["80"] = $soyadad.$baba."1903";
$wp["81"] = $soyadad.$baba."1938";
$wp["82"] = $soyadad.$baba."1919";
$wp["83"] = $soyadad.$baba."1881";
$wp["84"] = $soyadad.$baba."2018";
$wp["85"] = $soyadad.$baba."2019";
$wp["86"] = $soyadad.$baba.$lakap;
$wp["87"] = $soyadad.$baba.$anne;
$wp["88"] = $soyadad.$baba.$baba;
$wp["89"] = $soyadad.$baba.$kardes;
$wp["90"] = $soyadad.$baba.$sevgili;
$wp["91"] = $soyadad.$baba.$sevgilisoyad;
$wp["92"] = $soyadad.$baba.$dogumtarihi;
$wp["93"] = $soyadad.$baba.$dogumyili;
$wp["94"] = $soyadad.$baba.$cikmayili;
$wp["95"] = $soyadad.$baba.$cikmatarihi;
$wp["96"] = $soyadad.$baba.$sehir;
$wp["97"] = $soyadad.$baba.$takim;
$wp["98"] = $soyadad.$baba.$takimtarihi;
$wp["99"] = $soyadad.$baba.$takimkisa;
$wp["100"] = $soyadad.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $soyadad.$kardes;
$wp["102"] = $soyadad.$kardes."123";
$wp["103"] = $soyadad.$kardes."1905";
$wp["104"] = $soyadad.$kardes."1907";
$wp["105"] = $soyadad.$kardes."1903";
$wp["106"] = $soyadad.$kardes."1938";
$wp["107"] = $soyadad.$kardes."1919";
$wp["108"] = $soyadad.$kardes."1881";
$wp["109"] = $soyadad.$kardes."2018";
$wp["110"] = $soyadad.$kardes."2019";
$wp["111"] = $soyadad.$kardes.$lakap;
$wp["112"] = $soyadad.$kardes.$anne;
$wp["113"] = $soyadad.$kardes.$baba;
$wp["114"] = $soyadad.$kardes.$kardes;
$wp["115"] = $soyadad.$kardes.$sevgili;
$wp["116"] = $soyadad.$kardes.$sevgilisoyad;
$wp["117"] = $soyadad.$kardes.$dogumtarihi;
$wp["118"] = $soyadad.$kardes.$dogumyili;
$wp["119"] = $soyadad.$kardes.$cikmayili;
$wp["120"] = $soyadad.$kardes.$cikmatarihi;
$wp["121"] = $soyadad.$kardes.$sehir;
$wp["122"] = $soyadad.$kardes.$takim;
$wp["123"] = $soyadad.$kardes.$takimtarihi;
$wp["124"] = $soyadad.$kardes.$takimkisa;
$wp["125"] = $soyadad.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $soyadad.$sevgili;
$wp["127"] = $soyadad.$sevgili."123";
$wp["128"] = $soyadad.$sevgili."1905";
$wp["129"] = $soyadad.$sevgili."1907";
$wp["130"] = $soyadad.$sevgili."1903";
$wp["131"] = $soyadad.$sevgili."1938";
$wp["132"] = $soyadad.$sevgili."1919";
$wp["133"] = $soyadad.$sevgili."1881";
$wp["134"] = $soyadad.$sevgili."2018";
$wp["135"] = $soyadad.$sevgili."2019";
$wp["136"] = $soyadad.$sevgili.$lakap;
$wp["137"] = $soyadad.$sevgili.$anne;
$wp["138"] = $soyadad.$sevgili.$baba;
$wp["139"] = $soyadad.$sevgili.$kardes;
$wp["140"] = $soyadad.$sevgili.$sevgili;
$wp["141"] = $soyadad.$sevgili.$sevgilisoyad;
$wp["142"] = $soyadad.$sevgili.$dogumtarihi;
$wp["143"] = $soyadad.$sevgili.$dogumyili;
$wp["144"] = $soyadad.$sevgili.$cikmayili;
$wp["145"] = $soyadad.$sevgili.$cikmatarihi;
$wp["146"] = $soyadad.$sevgili.$sehir;
$wp["147"] = $soyadad.$sevgili.$takim;
$wp["148"] = $soyadad.$sevgili.$takimtarihi;
$wp["149"] = $soyadad.$sevgili.$takimkisa;
$wp["150"] = $soyadad.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $soyadad.$sevgilisoyad;
$wp["152"] = $soyadad.$sevgilisoyad."123";
$wp["153"] = $soyadad.$sevgilisoyad."1905";
$wp["154"] = $soyadad.$sevgilisoyad."1907";
$wp["155"] = $soyadad.$sevgilisoyad."1903";
$wp["156"] = $soyadad.$sevgilisoyad."1938";
$wp["157"] = $soyadad.$sevgilisoyad."1919";
$wp["158"] = $soyadad.$sevgilisoyad."1881";
$wp["159"] = $soyadad.$sevgilisoyad."2018";
$wp["160"] = $soyadad.$sevgilisoyad."2019";
$wp["161"] = $soyadad.$sevgilisoyad.$lakap;
$wp["162"] = $soyadad.$sevgilisoyad.$anne;
$wp["163"] = $soyadad.$sevgilisoyad.$baba;
$wp["164"] = $soyadad.$sevgilisoyad.$kardes;
$wp["165"] = $soyadad.$sevgilisoyad.$sevgili;
$wp["166"] = $soyadad.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $soyadad.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $soyadad.$sevgilisoyad.$dogumyili;
$wp["169"] = $soyadad.$sevgilisoyad.$cikmayili;
$wp["170"] = $soyadad.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $soyadad.$sevgilisoyad.$sehir;
$wp["172"] = $soyadad.$sevgilisoyad.$takim;
$wp["173"] = $soyadad.$sevgilisoyad.$takimtarihi;
$wp["174"] = $soyadad.$sevgilisoyad.$takimkisa;
$wp["175"] = $soyadad.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $soyadad.$dogumtarihi;
$wp["177"] = $soyadad.$dogumtarihi."123";
$wp["178"] = $soyadad.$dogumtarihi."1905";
$wp["179"] = $soyadad.$dogumtarihi."1907";
$wp["180"] = $soyadad.$dogumtarihi."1903";
$wp["181"] = $soyadad.$dogumtarihi."1938";
$wp["200"] = $soyadad.$dogumtarihi."1919";
$wp["182"] = $soyadad.$dogumtarihi."1881";
$wp["183"] = $soyadad.$dogumtarihi."2018";
$wp["184"] = $soyadad.$dogumtarihi."2019";
$wp["185"] = $soyadad.$dogumtarihi.$lakap;
$wp["186"] = $soyadad.$dogumtarihi.$anne;
$wp["187"] = $soyadad.$dogumtarihi.$baba;
$wp["188"] = $soyadad.$dogumtarihi.$kardes;
$wp["189"] = $soyadad.$dogumtarihi.$sevgili;
$wp["190"] = $soyadad.$dogumtarihi.$dogumtarihi;
$wp["191"] = $soyadad.$dogumtarihi.$dogumtarihi;
$wp["192"] = $soyadad.$dogumtarihi.$dogumyili;
$wp["193"] = $soyadad.$dogumtarihi.$cikmayili;
$wp["194"] = $soyadad.$dogumtarihi.$cikmatarihi;
$wp["195"] = $soyadad.$dogumtarihi.$sehir;
$wp["196"] = $soyadad.$dogumtarihi.$takim;
$wp["197"] = $soyadad.$dogumtarihi.$takimtarihi;
$wp["198"] = $soyadad.$dogumtarihi.$takimkisa;
$wp["199"] = $soyadad.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $soyadad.$dogumyili;
$wp["202"] = $soyadad.$dogumyili."123";
$wp["203"] = $soyadad.$dogumyili."1905";
$wp["204"] = $soyadad.$dogumyili."1907";
$wp["205"] = $soyadad.$dogumyili."1903";
$wp["206"] = $soyadad.$dogumyili."1938";
$wp["207"] = $soyadad.$dogumyili."1919";
$wp["208"] = $soyadad.$dogumyili."1881";
$wp["209"] = $soyadad.$dogumyili."2018";
$wp["210"] = $soyadad.$dogumyili."2019";
$wp["211"] = $soyadad.$dogumyili.$lakap;
$wp["212"] = $soyadad.$dogumyili.$anne;
$wp["213"] = $soyadad.$dogumyili.$baba;
$wp["214"] = $soyadad.$dogumyili.$kardes;
$wp["215"] = $soyadad.$dogumyili.$sevgili;
$wp["216"] = $soyadad.$dogumyili.$dogumyili;
$wp["217"] = $soyadad.$dogumyili.$dogumyili;
$wp["218"] = $soyadad.$dogumyili.$dogumyili;
$wp["219"] = $soyadad.$dogumyili.$cikmayili;
$wp["220"] = $soyadad.$dogumyili.$cikmatarihi;
$wp["221"] = $soyadad.$dogumyili.$sehir;
$wp["222"] = $soyadad.$dogumyili.$takim;
$wp["223"] = $soyadad.$dogumyili.$takimtarihi;
$wp["224"] = $soyadad.$dogumyili.$takimkisa;
$wp["225"] = $soyadad.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $soyadad.$cikmayili;
$wp["227"] = $soyadad.$cikmayili."123";
$wp["228"] = $soyadad.$cikmayili."1905";
$wp["229"] = $soyadad.$cikmayili."1907";
$wp["230"] = $soyadad.$cikmayili."1903";
$wp["231"] = $soyadad.$cikmayili."1938";
$wp["232"] = $soyadad.$cikmayili."1919";
$wp["233"] = $soyadad.$cikmayili."1881";
$wp["234"] = $soyadad.$cikmayili."2018";
$wp["235"] = $soyadad.$cikmayili."2019";
$wp["236"] = $soyadad.$cikmayili.$lakap;
$wp["237"] = $soyadad.$cikmayili.$anne;
$wp["238"] = $soyadad.$cikmayili.$baba;
$wp["239"] = $soyadad.$cikmayili.$kardes;
$wp["240"] = $soyadad.$cikmayili.$sevgili;
$wp["241"] = $soyadad.$cikmayili.$cikmayili;
$wp["242"] = $soyadad.$cikmayili.$dogumyili;
$wp["243"] = $soyadad.$cikmayili.$cikmayili;
$wp["244"] = $soyadad.$cikmayili.$cikmayili;
$wp["245"] = $soyadad.$cikmayili.$cikmatarihi;
$wp["246"] = $soyadad.$cikmayili.$sehir;
$wp["247"] = $soyadad.$cikmayili.$takim;
$wp["248"] = $soyadad.$cikmayili.$takimtarihi;
$wp["249"] = $soyadad.$cikmayili.$takimkisa;
$wp["250"] = $soyadad.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $soyadad.$cikmatarihi;
$wp["252"] = $soyadad.$cikmatarihi."123";
$wp["253"] = $soyadad.$cikmatarihi."1905";
$wp["254"] = $soyadad.$cikmatarihi."1907";
$wp["255"] = $soyadad.$cikmatarihi."1903";
$wp["256"] = $soyadad.$cikmatarihi."1938";
$wp["257"] = $soyadad.$cikmatarihi."1919";
$wp["258"] = $soyadad.$cikmatarihi."1881";
$wp["259"] = $soyadad.$cikmatarihi."2018";
$wp["260"] = $soyadad.$cikmatarihi."2019";
$wp["261"] = $soyadad.$cikmatarihi.$lakap;
$wp["262"] = $soyadad.$cikmatarihi.$anne;
$wp["263"] = $soyadad.$cikmatarihi.$baba;
$wp["264"] = $soyadad.$cikmatarihi.$kardes;
$wp["265"] = $soyadad.$cikmatarihi.$sevgili;
$wp["267"] = $soyadad.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $soyadad.$cikmatarihi.$dogumtarihi;
$wp["269"] = $soyadad.$cikmatarihi.$dogumyili;
$wp["270"] = $soyadad.$cikmatarihi.$cikmayili;
$wp["271"] = $soyadad.$cikmatarihi.$cikmatarihi;
$wp["272"] = $soyadad.$cikmatarihi.$sehir;
$wp["273"] = $soyadad.$cikmatarihi.$takim;
$wp["274"] = $soyadad.$cikmatarihi.$takimtarihi;
$wp["275"] = $soyadad.$cikmatarihi.$takimkisa;
$wp["266"] = $soyadad.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $soyadad.$sehir;
$wp["277"] = $soyadad.$sehir."123";
$wp["278"] = $soyadad.$sehir."1905";
$wp["279"] = $soyadad.$sehir."1907";
$wp["280"] = $soyadad.$sehir."1903";
$wp["281"] = $soyadad.$sehir."1938";
$wp["282"] = $soyadad.$sehir."1919";
$wp["283"] = $soyadad.$sehir."1881";
$wp["284"] = $soyadad.$sehir."2018";
$wp["285"] = $soyadad.$sehir."2019";
$wp["286"] = $soyadad.$sehir.$lakap;
$wp["287"] = $soyadad.$sehir.$anne;
$wp["288"] = $soyadad.$sehir.$baba;
$wp["289"] = $soyadad.$sehir.$kardes;
$wp["290"] = $soyadad.$sehir.$sevgili;
$wp["291"] = $soyadad.$sehir.$sevgilisoyad;
$wp["292"] = $soyadad.$sehir.$dogumtarihi;
$wp["293"] = $soyadad.$sehir.$dogumyili;
$wp["294"] = $soyadad.$sehir.$cikmayili;
$wp["295"] = $soyadad.$sehir.$cikmatarihi;
$wp["296"] = $soyadad.$sehir.$sehir;
$wp["297"] = $soyadad.$sehir.$takim;
$wp["298"] = $soyadad.$sehir.$takimtarihi;
$wp["299"] = $soyadad.$sehir.$takimkisa;
$wp["300"] = $soyadad.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $soyadad.$takim;
$wp["302"] = $soyadad.$takim."123";
$wp["303"] = $soyadad.$takim."1905";
$wp["304"] = $soyadad.$takim."1907";
$wp["305"] = $soyadad.$takim."1903";
$wp["306"] = $soyadad.$takim."1938";
$wp["307"] = $soyadad.$takim."1919";
$wp["308"] = $soyadad.$takim."1881";
$wp["309"] = $soyadad.$takim."2018";
$wp["310"] = $soyadad.$takim."2019";
$wp["311"] = $soyadad.$takim.$lakap;
$wp["312"] = $soyadad.$takim.$anne;
$wp["313"] = $soyadad.$takim.$baba;
$wp["314"] = $soyadad.$takim.$kardes;
$wp["315"] = $soyadad.$takim.$sevgili;
$wp["316"] = $soyadad.$takim.$sevgilisoyad;
$wp["317"] = $soyadad.$takim.$dogumtarihi;
$wp["318"] = $soyadad.$takim.$dogumyili;
$wp["319"] = $soyadad.$takim.$cikmayili;
$wp["320"] = $soyadad.$takim.$cikmatarihi;
$wp["321"] = $soyadad.$takim.$sehir;
$wp["322"] = $soyadad.$takim.$takim;
$wp["323"] = $soyadad.$takim.$takimtarihi;
$wp["324"] = $soyadad.$takim.$takimkisa;
$wp["325"] = $soyadad.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $soyadad.$takimtarihi;
$wp["327"] = $soyadad.$takimtarihi."123";
$wp["328"] = $soyadad.$takimtarihi."1905";
$wp["329"] = $soyadad.$takimtarihi."1907";
$wp["330"] = $soyadad.$takimtarihi."1903";
$wp["331"] = $soyadad.$takimtarihi."1938";
$wp["332"] = $soyadad.$takimtarihi."1919";
$wp["333"] = $soyadad.$takimtarihi."1881";
$wp["334"] = $soyadad.$takimtarihi."2018";
$wp["335"] = $soyadad.$takimtarihi."2019";
$wp["336"] = $soyadad.$takimtarihi.$lakap;
$wp["337"] = $soyadad.$takimtarihi.$anne;
$wp["338"] = $soyadad.$takimtarihi.$baba;
$wp["339"] = $soyadad.$takimtarihi.$kardes;
$wp["340"] = $soyadad.$takimtarihi.$sevgili;
$wp["341"] = $soyadad.$takimtarihi.$sevgilisoyad;
$wp["342"] = $soyadad.$takimtarihi.$dogumtarihi;
$wp["343"] = $soyadad.$takimtarihi.$dogumyili;
$wp["344"] = $soyadad.$takimtarihi.$cikmayili;
$wp["345"] = $soyadad.$takimtarihi.$cikmatarihi;
$wp["346"] = $soyadad.$takimtarihi.$sehir;
$wp["347"] = $soyadad.$takimtarihi.$takim;
$wp["348"] = $soyadad.$takimtarihi.$takimtarihi;
$wp["349"] = $soyadad.$takimtarihi.$takimkisa;
$wp["350"] = $soyadad.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $soyadad.$takimkisa;
$wp["352"] = $soyadad.$takimkisa."123";
$wp["353"] = $soyadad.$takimkisa."1905";
$wp["354"] = $soyadad.$takimkisa."1907";
$wp["355"] = $soyadad.$takimkisa."1903";
$wp["356"] = $soyadad.$takimkisa."1938";
$wp["357"] = $soyadad.$takimkisa."1919";
$wp["358"] = $soyadad.$takimkisa."1881";
$wp["359"] = $soyadad.$takimkisa."2018";
$wp["360"] = $soyadad.$takimkisa."2019";
$wp["361"] = $soyadad.$takimkisa.$lakap;
$wp["362"] = $soyadad.$takimkisa.$anne;
$wp["363"] = $soyadad.$takimkisa.$baba;
$wp["364"] = $soyadad.$takimkisa.$kardes;
$wp["365"] = $soyadad.$takimkisa.$sevgili;
$wp["366"] = $soyadad.$takimkisa.$sevgilisoyad;
$wp["367"] = $soyadad.$takimkisa.$dogumtarihi;
$wp["368"] = $soyadad.$takimkisa.$dogumyili;
$wp["369"] = $soyadad.$takimkisa.$cikmayili;
$wp["370"] = $soyadad.$takimkisa.$cikmatarihi;
$wp["371"] = $soyadad.$takimkisa.$sehir;
$wp["372"] = $soyadad.$takimkisa.$takim;
$wp["373"] = $soyadad.$takimkisa.$takimtarihi;
$wp["374"] = $soyadad.$takimkisa.$takimkisa;
$wp["375"] = $soyadad.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $soyadad.$plaka;
$wp["377"] = $soyadad.$plaka."123";
$wp["378"] = $soyadad.$plaka."1905";
$wp["379"] = $soyadad.$plaka."1907";
$wp["380"] = $soyadad.$plaka."1903";
$wp["381"] = $soyadad.$plaka."1938";
$wp["382"] = $soyadad.$plaka."1919";
$wp["383"] = $soyadad.$plaka."1881";
$wp["384"] = $soyadad.$plaka."2018";
$wp["385"] = $soyadad.$plaka."2019";
$wp["386"] = $soyadad.$plaka.$lakap;
$wp["387"] = $soyadad.$plaka.$anne;
$wp["388"] = $soyadad.$plaka.$baba;
$wp["389"] = $soyadad.$plaka.$kardes;
$wp["390"] = $soyadad.$plaka.$sevgili;
$wp["391"] = $soyadad.$plaka.$sevgilisoyad;
$wp["392"] = $soyadad.$plaka.$dogumtarihi;
$wp["393"] = $soyadad.$plaka.$dogumyili;
$wp["394"] = $soyadad.$plaka.$cikmayili;
$wp["395"] = $soyadad.$plaka.$cikmatarihi;
$wp["396"] = $soyadad.$plaka.$sehir;
$wp["397"] = $soyadad.$plaka.$takim;
$wp["398"] = $soyadad.$plaka.$takimtarihi;
$wp["399"] = $soyadad.$plaka.$takimkisa;
$wp["400"] = $soyadad.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $soyadad.$eskisifre;
$wp["402"] = $soyadad.$eskisifre."123";
$wp["403"] = $soyadad.$eskisifre."1905";
$wp["404"] = $soyadad.$eskisifre."1907";
$wp["405"] = $soyadad.$eskisifre."1903";
$wp["406"] = $soyadad.$eskisifre."1938";
$wp["407"] = $soyadad.$eskisifre."1919";
$wp["408"] = $soyadad.$eskisifre."1881";
$wp["409"] = $soyadad.$eskisifre."2018";
$wp["410"] = $soyadad.$eskisifre."2019";
$wp["411"] = $soyadad.$eskisifre.$lakap;
$wp["412"] = $soyadad.$eskisifre.$anne;
$wp["413"] = $soyadad.$eskisifre.$baba;
$wp["414"] = $soyadad.$eskisifre.$kardes;
$wp["415"] = $soyadad.$eskisifre.$sevgili;
$wp["416"] = $soyadad.$eskisifre.$sevgilisoyad;
$wp["417"] = $soyadad.$eskisifre.$dogumtarihi;
$wp["418"] = $soyadad.$eskisifre.$dogumyili;
$wp["419"] = $soyadad.$eskisifre.$cikmayili;
$wp["420"] = $soyadad.$eskisifre.$cikmatarihi;
$wp["421"] = $soyadad.$eskisifre.$sehir;
$wp["422"] = $soyadad.$eskisifre.$takim;
$wp["423"] = $soyadad.$eskisifre.$takimtarihi;
$wp["424"] = $soyadad.$eskisifre.$takimkisa;
$wp["425"] = $soyadad.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $soyadad.$tel;
$wp["427"] = $soyadad.$tel."123";
$wp["428"] = $soyadad.$tel."1905";
$wp["429"] = $soyadad.$tel."1907";
$wp["430"] = $soyadad.$tel."1903";
$wp["431"] = $soyadad.$tel."1938";
$wp["432"] = $soyadad.$tel."1919";
$wp["433"] = $soyadad.$tel."1881";
$wp["434"] = $soyadad.$tel."2018";
$wp["435"] = $soyadad.$tel."2019";
$wp["436"] = $soyadad.$tel.$lakap;
$wp["437"] = $soyadad.$tel.$anne;
$wp["438"] = $soyadad.$tel.$baba;
$wp["439"] = $soyadad.$tel.$kardes;
$wp["440"] = $soyadad.$tel.$sevgili;
$wp["441"] = $soyadad.$tel.$sevgilisoyad;
$wp["442"] = $soyadad.$tel.$dogumtarihi;
$wp["443"] = $soyadad.$tel.$dogumyili;
$wp["444"] = $soyadad.$tel.$cikmayili;
$wp["445"] = $soyadad.$tel.$cikmatarihi;
$wp["446"] = $soyadad.$tel.$sehir;
$wp["447"] = $soyadad.$tel.$takim;
$wp["448"] = $soyadad.$tel.$takimtarihi;
$wp["449"] = $soyadad.$tel.$takimkisa;
$wp["450"] = $soyadad.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $soyadad.$annetel;
$wp["452"] = $soyadad.$annetel."123";
$wp["453"] = $soyadad.$annetel."1905";
$wp["454"] = $soyadad.$annetel."1907";
$wp["455"] = $soyadad.$annetel."1903";
$wp["456"] = $soyadad.$annetel."1938";
$wp["457"] = $soyadad.$annetel."1919";
$wp["458"] = $soyadad.$annetel."1881";
$wp["459"] = $soyadad.$annetel."2018";
$wp["460"] = $soyadad.$annetel."2019";
$wp["461"] = $soyadad.$annetel.$lakap;
$wp["462"] = $soyadad.$annetel.$anne;
$wp["463"] = $soyadad.$annetel.$baba;
$wp["464"] = $soyadad.$annetel.$kardes;
$wp["465"] = $soyadad.$annetel.$sevgili;
$wp["466"] = $soyadad.$annetel.$sevgilisoyad;
$wp["467"] = $soyadad.$annetel.$dogumtarihi;
$wp["468"] = $soyadad.$annetel.$dogumyili;
$wp["469"] = $soyadad.$annetel.$cikmayili;
$wp["470"] = $soyadad.$annetel.$cikmatarihi;
$wp["471"] = $soyadad.$annetel.$sehir;
$wp["472"] = $soyadad.$annetel.$takim;
$wp["473"] = $soyadad.$annetel.$takimtarihi;
$wp["474"] = $soyadad.$annetel.$takimkisa;
$wp["475"] = $soyadad.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $soyadad.$babatel;
$wp["477"] = $soyadad.$babatel."123";
$wp["478"] = $soyadad.$babatel."1905";
$wp["479"] = $soyadad.$babatel."1907";
$wp["480"] = $soyadad.$babatel."1903";
$wp["481"] = $soyadad.$babatel."1938";
$wp["482"] = $soyadad.$babatel."1919";
$wp["483"] = $soyadad.$babatel."1881";
$wp["484"] = $soyadad.$babatel."2018";
$wp["485"] = $soyadad.$babatel."2019";
$wp["486"] = $soyadad.$babatel.$lakap;
$wp["487"] = $soyadad.$babatel.$anne;
$wp["488"] = $soyadad.$babatel.$baba;
$wp["489"] = $soyadad.$babatel.$kardes;
$wp["490"] = $soyadad.$babatel.$sevgili;
$wp["491"] = $soyadad.$babatel.$sevgilisoyad;
$wp["492"] = $soyadad.$babatel.$dogumtarihi;
$wp["493"] = $soyadad.$babatel.$dogumyili;
$wp["494"] = $soyadad.$babatel.$cikmayili;
$wp["495"] = $soyadad.$babatel.$cikmatarihi;
$wp["496"] = $soyadad.$babatel.$sehir;
$wp["497"] = $soyadad.$babatel.$takim;
$wp["498"] = $soyadad.$babatel.$takimtarihi;
$wp["499"] = $soyadad.$babatel.$takimkisa;
$wp["500"] = $soyadad.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $soyadad.$kardestel;
$wp["502"] = $soyadad.$kardestel."123";
$wp["503"] = $soyadad.$kardestel."1905";
$wp["504"] = $soyadad.$kardestel."1907";
$wp["505"] = $soyadad.$kardestel."1903";
$wp["506"] = $soyadad.$kardestel."1938";
$wp["507"] = $soyadad.$kardestel."1919";
$wp["508"] = $soyadad.$kardestel."1881";
$wp["509"] = $soyadad.$kardestel."2018";
$wp["510"] = $soyadad.$kardestel."2019";
$wp["511"] = $soyadad.$kardestel.$lakap;
$wp["512"] = $soyadad.$kardestel.$anne;
$wp["513"] = $soyadad.$kardestel.$baba;
$wp["514"] = $soyadad.$kardestel.$kardes;
$wp["515"] = $soyadad.$kardestel.$sevgili;
$wp["516"] = $soyadad.$kardestel.$sevgilisoyad;
$wp["517"] = $soyadad.$kardestel.$dogumtarihi;
$wp["518"] = $soyadad.$kardestel.$dogumyili;
$wp["519"] = $soyadad.$kardestel.$cikmayili;
$wp["520"] = $soyadad.$kardestel.$cikmatarihi;
$wp["521"] = $soyadad.$kardestel.$sehir;
$wp["522"] = $soyadad.$kardestel.$takim;
$wp["523"] = $soyadad.$kardestel.$takimtarihi;
$wp["524"] = $soyadad.$kardestel.$takimkisa;
$wp["525"] = $soyadad.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $soyadad.$sevgilitel;
$wp["527"] = $soyadad.$sevgilitel."123";
$wp["528"] = $soyadad.$sevgilitel."1905";
$wp["529"] = $soyadad.$sevgilitel."1907";
$wp["530"] = $soyadad.$sevgilitel."1903";
$wp["531"] = $soyadad.$sevgilitel."1938";
$wp["532"] = $soyadad.$sevgilitel."1919";
$wp["533"] = $soyadad.$sevgilitel."1881";
$wp["534"] = $soyadad.$sevgilitel."2018";
$wp["535"] = $soyadad.$sevgilitel."2019";
$wp["536"] = $soyadad.$sevgilitel.$lakap;
$wp["537"] = $soyadad.$sevgilitel.$anne;
$wp["538"] = $soyadad.$sevgilitel.$baba;
$wp["539"] = $soyadad.$sevgilitel.$kardes;
$wp["540"] = $soyadad.$sevgilitel.$sevgili;
$wp["541"] = $soyadad.$sevgilitel.$sevgilisoyad;
$wp["542"] = $soyadad.$sevgilitel.$dogumtarihi;
$wp["543"] = $soyadad.$sevgilitel.$dogumyili;
$wp["544"] = $soyadad.$sevgilitel.$cikmayili;
$wp["545"] = $soyadad.$sevgilitel.$cikmatarihi;
$wp["546"] = $soyadad.$sevgilitel.$sehir;
$wp["547"] = $soyadad.$sevgilitel.$takim;
$wp["548"] = $soyadad.$sevgilitel.$takimtarihi;
$wp["549"] = $soyadad.$sevgilitel.$takimkisa;
$wp["550"] = $soyadad.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $soyadad.$tckimlikno;
$wp["552"] = $soyadad.$tckimlikno."13";
$wp["553"] = $soyadad.$tckimlikno."1905";
$wp["554"] = $soyadad.$tckimlikno."1907";
$wp["555"] = $soyadad.$tckimlikno."1903";
$wp["556"] = $soyadad.$tckimlikno."1938";
$wp["557"] = $soyadad.$tckimlikno."1919";
$wp["558"] = $soyadad.$tckimlikno."1881";
$wp["559"] = $soyadad.$tckimlikno."2018";
$wp["560"] = $soyadad.$tckimlikno."2019";
$wp["561"] = $soyadad.$tckimlikno.$lakap;
$wp["562"] = $soyadad.$tckimlikno.$anne;
$wp["563"] = $soyadad.$tckimlikno.$baba;
$wp["564"] = $soyadad.$tckimlikno.$kardes;
$wp["565"] = $soyadad.$tckimlikno.$sevgili;
$wp["566"] = $soyadad.$tckimlikno.$sevgilisoyad;
$wp["567"] = $soyadad.$tckimlikno.$dogumtarihi;
$wp["568"] = $soyadad.$tckimlikno.$dogumyili;
$wp["569"] = $soyadad.$tckimlikno.$cikmayili;
$wp["570"] = $soyadad.$tckimlikno.$cikmatarihi;
$wp["571"] = $soyadad.$tckimlikno.$sehir;
$wp["572"] = $soyadad.$tckimlikno.$takim;
$wp["573"] = $soyadad.$tckimlikno.$takimtarihi;
$wp["574"] = $soyadad.$tckimlikno.$takimkisa;
$wp["575"] = $soyadad.$tckimlikno.$plaka;

/////////////////////////////////////////



for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);



 ?>