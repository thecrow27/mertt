<?php 

error_reporting(0);

include "kayit.php";



$wp["1"] = $baba;
$wp["2"] = $baba.$soyadad."123";
$wp["3"] = $baba.$soyadad."1905";
$wp["4"] = $baba.$soyadad."1907";
$wp["5"] = $baba.$soyadad."1903";
$wp["6"] = $baba.$soyadad."1938";
$wp["7"] = $baba.$soyadad."1919";
$wp["8"] = $baba.$soyadad."1881";
$wp["9"] = $baba.$soyadad."2018";
$wp["10"] = $baba.$soyadad."2019";
$wp["11"] = $baba.$soyadad.$lakap;
$wp["12"] = $baba.$soyadad.$anne;
$wp["13"] = $baba.$soyadad.$baba;
$wp["14"] = $baba.$soyadad.$kardes;
$wp["15"] = $baba.$soyadad.$sevgili;
$wp["16"] = $baba.$soyadad.$sevgilisoyad;
$wp["17"] = $baba.$soyadad.$dogumtarihi;
$wp["18"] = $baba.$soyadad.$dogumyili;
$wp["19"] = $baba.$soyadad.$cikmayili;
$wp["20"] = $baba.$soyadad.$cikmatarihi;
$wp["21"] = $baba.$soyadad.$sehir;
$wp["22"] = $baba.$soyadad.$takim;
$wp["23"] = $baba.$soyadad.$takimtarihi;
$wp["24"] = $baba.$soyadad.$takimkisa;
$wp["25"] = $baba.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $baba.$lakap;
$wp["27"] = $baba.$lakap."123";
$wp["28"] = $baba.$lakap."1905";
$wp["29"] = $baba.$lakap."1907";
$wp["30"] = $baba.$lakap."1903";
$wp["31"] = $baba.$lakap."1938";
$wp["32"] = $baba.$lakap."1919";
$wp["33"] = $baba.$lakap."1881";
$wp["34"] = $baba.$lakap."2018";
$wp["35"] = $baba.$lakap."2019";
$wp["36"] = $baba.$lakap.$lakap;
$wp["37"] = $baba.$lakap.$anne;
$wp["38"] = $baba.$lakap.$baba;
$wp["39"] = $baba.$lakap.$kardes;
$wp["40"] = $baba.$lakap.$sevgili;
$wp["41"] = $baba.$lakap.$sevgilisoyad;
$wp["42"] = $baba.$lakap.$dogumtarihi;
$wp["43"] = $baba.$lakap.$dogumyili;
$wp["44"] = $baba.$lakap.$cikmayili;
$wp["45"] = $baba.$lakap.$cikmatarihi;
$wp["46"] = $baba.$lakap.$sehir;
$wp["47"] = $baba.$lakap.$takim;
$wp["48"] = $baba.$lakap.$takimtarihi;
$wp["49"] = $baba.$lakap.$takimkisa;
$wp["50"] = $baba.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $baba.$anne;
$wp["52"] = $baba.$anne."123";
$wp["53"] = $baba.$anne."1905";
$wp["54"] = $baba.$anne."1907";
$wp["55"] = $baba.$anne."1903";
$wp["56"] = $baba.$anne."1938";
$wp["57"] = $baba.$anne."1919";
$wp["58"] = $baba.$anne."1881";
$wp["59"] = $baba.$anne."2018";
$wp["60"] = $baba.$anne."2019";
$wp["61"] = $baba.$anne.$lakap;
$wp["62"] = $baba.$anne.$anne;
$wp["63"] = $baba.$anne.$baba;
$wp["64"] = $baba.$anne.$kardes;
$wp["65"] = $baba.$anne.$sevgili;
$wp["66"] = $baba.$anne.$sevgilisoyad;
$wp["67"] = $baba.$anne.$dogumtarihi;
$wp["68"] = $baba.$anne.$dogumyili;
$wp["69"] = $baba.$anne.$cikmayili;
$wp["70"] = $baba.$anne.$cikmatarihi;
$wp["71"] = $baba.$anne.$sehir;
$wp["72"] = $baba.$anne.$takim;
$wp["73"] = $baba.$anne.$takimtarihi;
$wp["74"] = $baba.$anne.$takimkisa;
$wp["75"] = $baba.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $baba.$baba;
$wp["77"] = $baba.$baba."123";
$wp["78"] = $baba.$baba."1905";
$wp["79"] = $baba.$baba."1907";
$wp["80"] = $baba.$baba."1903";
$wp["81"] = $baba.$baba."1938";
$wp["82"] = $baba.$baba."1919";
$wp["83"] = $baba.$baba."1881";
$wp["84"] = $baba.$baba."2018";
$wp["85"] = $baba.$baba."2019";
$wp["86"] = $baba.$baba.$lakap;
$wp["87"] = $baba.$baba.$anne;
$wp["88"] = $baba.$baba.$baba;
$wp["89"] = $baba.$baba.$kardes;
$wp["90"] = $baba.$baba.$sevgili;
$wp["91"] = $baba.$baba.$sevgilisoyad;
$wp["92"] = $baba.$baba.$dogumtarihi;
$wp["93"] = $baba.$baba.$dogumyili;
$wp["94"] = $baba.$baba.$cikmayili;
$wp["95"] = $baba.$baba.$cikmatarihi;
$wp["96"] = $baba.$baba.$sehir;
$wp["97"] = $baba.$baba.$takim;
$wp["98"] = $baba.$baba.$takimtarihi;
$wp["99"] = $baba.$baba.$takimkisa;
$wp["100"] = $baba.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $baba.$kardes;
$wp["102"] = $baba.$kardes."123";
$wp["103"] = $baba.$kardes."1905";
$wp["104"] = $baba.$kardes."1907";
$wp["105"] = $baba.$kardes."1903";
$wp["106"] = $baba.$kardes."1938";
$wp["107"] = $baba.$kardes."1919";
$wp["108"] = $baba.$kardes."1881";
$wp["109"] = $baba.$kardes."2018";
$wp["110"] = $baba.$kardes."2019";
$wp["111"] = $baba.$kardes.$lakap;
$wp["112"] = $baba.$kardes.$anne;
$wp["113"] = $baba.$kardes.$baba;
$wp["114"] = $baba.$kardes.$kardes;
$wp["115"] = $baba.$kardes.$sevgili;
$wp["116"] = $baba.$kardes.$sevgilisoyad;
$wp["117"] = $baba.$kardes.$dogumtarihi;
$wp["118"] = $baba.$kardes.$dogumyili;
$wp["119"] = $baba.$kardes.$cikmayili;
$wp["120"] = $baba.$kardes.$cikmatarihi;
$wp["121"] = $baba.$kardes.$sehir;
$wp["122"] = $baba.$kardes.$takim;
$wp["123"] = $baba.$kardes.$takimtarihi;
$wp["124"] = $baba.$kardes.$takimkisa;
$wp["125"] = $baba.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $baba.$sevgili;
$wp["127"] = $baba.$sevgili."123";
$wp["128"] = $baba.$sevgili."1905";
$wp["129"] = $baba.$sevgili."1907";
$wp["130"] = $baba.$sevgili."1903";
$wp["131"] = $baba.$sevgili."1938";
$wp["132"] = $baba.$sevgili."1919";
$wp["133"] = $baba.$sevgili."1881";
$wp["134"] = $baba.$sevgili."2018";
$wp["135"] = $baba.$sevgili."2019";
$wp["136"] = $baba.$sevgili.$lakap;
$wp["137"] = $baba.$sevgili.$anne;
$wp["138"] = $baba.$sevgili.$baba;
$wp["139"] = $baba.$sevgili.$kardes;
$wp["140"] = $baba.$sevgili.$sevgili;
$wp["141"] = $baba.$sevgili.$sevgilisoyad;
$wp["142"] = $baba.$sevgili.$dogumtarihi;
$wp["143"] = $baba.$sevgili.$dogumyili;
$wp["144"] = $baba.$sevgili.$cikmayili;
$wp["145"] = $baba.$sevgili.$cikmatarihi;
$wp["146"] = $baba.$sevgili.$sehir;
$wp["147"] = $baba.$sevgili.$takim;
$wp["148"] = $baba.$sevgili.$takimtarihi;
$wp["149"] = $baba.$sevgili.$takimkisa;
$wp["150"] = $baba.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $baba.$sevgilisoyad;
$wp["152"] = $baba.$sevgilisoyad."123";
$wp["153"] = $baba.$sevgilisoyad."1905";
$wp["154"] = $baba.$sevgilisoyad."1907";
$wp["155"] = $baba.$sevgilisoyad."1903";
$wp["156"] = $baba.$sevgilisoyad."1938";
$wp["157"] = $baba.$sevgilisoyad."1919";
$wp["158"] = $baba.$sevgilisoyad."1881";
$wp["159"] = $baba.$sevgilisoyad."2018";
$wp["160"] = $baba.$sevgilisoyad."2019";
$wp["161"] = $baba.$sevgilisoyad.$lakap;
$wp["162"] = $baba.$sevgilisoyad.$anne;
$wp["163"] = $baba.$sevgilisoyad.$baba;
$wp["164"] = $baba.$sevgilisoyad.$kardes;
$wp["165"] = $baba.$sevgilisoyad.$sevgili;
$wp["166"] = $baba.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $baba.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $baba.$sevgilisoyad.$dogumyili;
$wp["169"] = $baba.$sevgilisoyad.$cikmayili;
$wp["170"] = $baba.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $baba.$sevgilisoyad.$sehir;
$wp["172"] = $baba.$sevgilisoyad.$takim;
$wp["173"] = $baba.$sevgilisoyad.$takimtarihi;
$wp["174"] = $baba.$sevgilisoyad.$takimkisa;
$wp["175"] = $baba.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $baba.$dogumtarihi;
$wp["177"] = $baba.$dogumtarihi."123";
$wp["178"] = $baba.$dogumtarihi."1905";
$wp["179"] = $baba.$dogumtarihi."1907";
$wp["180"] = $baba.$dogumtarihi."1903";
$wp["181"] = $baba.$dogumtarihi."1938";
$wp["200"] = $baba.$dogumtarihi."1919";
$wp["182"] = $baba.$dogumtarihi."1881";
$wp["183"] = $baba.$dogumtarihi."2018";
$wp["184"] = $baba.$dogumtarihi."2019";
$wp["185"] = $baba.$dogumtarihi.$lakap;
$wp["186"] = $baba.$dogumtarihi.$anne;
$wp["187"] = $baba.$dogumtarihi.$baba;
$wp["188"] = $baba.$dogumtarihi.$kardes;
$wp["189"] = $baba.$dogumtarihi.$sevgili;
$wp["190"] = $baba.$dogumtarihi.$dogumtarihi;
$wp["191"] = $baba.$dogumtarihi.$dogumtarihi;
$wp["192"] = $baba.$dogumtarihi.$dogumyili;
$wp["193"] = $baba.$dogumtarihi.$cikmayili;
$wp["194"] = $baba.$dogumtarihi.$cikmatarihi;
$wp["195"] = $baba.$dogumtarihi.$sehir;
$wp["196"] = $baba.$dogumtarihi.$takim;
$wp["197"] = $baba.$dogumtarihi.$takimtarihi;
$wp["198"] = $baba.$dogumtarihi.$takimkisa;
$wp["199"] = $baba.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $baba.$dogumyili;
$wp["202"] = $baba.$dogumyili."123";
$wp["203"] = $baba.$dogumyili."1905";
$wp["204"] = $baba.$dogumyili."1907";
$wp["205"] = $baba.$dogumyili."1903";
$wp["206"] = $baba.$dogumyili."1938";
$wp["207"] = $baba.$dogumyili."1919";
$wp["208"] = $baba.$dogumyili."1881";
$wp["209"] = $baba.$dogumyili."2018";
$wp["210"] = $baba.$dogumyili."2019";
$wp["211"] = $baba.$dogumyili.$lakap;
$wp["212"] = $baba.$dogumyili.$anne;
$wp["213"] = $baba.$dogumyili.$baba;
$wp["214"] = $baba.$dogumyili.$kardes;
$wp["215"] = $baba.$dogumyili.$sevgili;
$wp["216"] = $baba.$dogumyili.$dogumyili;
$wp["217"] = $baba.$dogumyili.$dogumyili;
$wp["218"] = $baba.$dogumyili.$dogumyili;
$wp["219"] = $baba.$dogumyili.$cikmayili;
$wp["220"] = $baba.$dogumyili.$cikmatarihi;
$wp["221"] = $baba.$dogumyili.$sehir;
$wp["222"] = $baba.$dogumyili.$takim;
$wp["223"] = $baba.$dogumyili.$takimtarihi;
$wp["224"] = $baba.$dogumyili.$takimkisa;
$wp["225"] = $baba.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $baba.$cikmayili;
$wp["227"] = $baba.$cikmayili."123";
$wp["228"] = $baba.$cikmayili."1905";
$wp["229"] = $baba.$cikmayili."1907";
$wp["230"] = $baba.$cikmayili."1903";
$wp["231"] = $baba.$cikmayili."1938";
$wp["232"] = $baba.$cikmayili."1919";
$wp["233"] = $baba.$cikmayili."1881";
$wp["234"] = $baba.$cikmayili."2018";
$wp["235"] = $baba.$cikmayili."2019";
$wp["236"] = $baba.$cikmayili.$lakap;
$wp["237"] = $baba.$cikmayili.$anne;
$wp["238"] = $baba.$cikmayili.$baba;
$wp["239"] = $baba.$cikmayili.$kardes;
$wp["240"] = $baba.$cikmayili.$sevgili;
$wp["241"] = $baba.$cikmayili.$cikmayili;
$wp["242"] = $baba.$cikmayili.$dogumyili;
$wp["243"] = $baba.$cikmayili.$cikmayili;
$wp["244"] = $baba.$cikmayili.$cikmayili;
$wp["245"] = $baba.$cikmayili.$cikmatarihi;
$wp["246"] = $baba.$cikmayili.$sehir;
$wp["247"] = $baba.$cikmayili.$takim;
$wp["248"] = $baba.$cikmayili.$takimtarihi;
$wp["249"] = $baba.$cikmayili.$takimkisa;
$wp["250"] = $baba.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $baba.$cikmatarihi;
$wp["252"] = $baba.$cikmatarihi."123";
$wp["253"] = $baba.$cikmatarihi."1905";
$wp["254"] = $baba.$cikmatarihi."1907";
$wp["255"] = $baba.$cikmatarihi."1903";
$wp["256"] = $baba.$cikmatarihi."1938";
$wp["257"] = $baba.$cikmatarihi."1919";
$wp["258"] = $baba.$cikmatarihi."1881";
$wp["259"] = $baba.$cikmatarihi."2018";
$wp["260"] = $baba.$cikmatarihi."2019";
$wp["261"] = $baba.$cikmatarihi.$lakap;
$wp["262"] = $baba.$cikmatarihi.$anne;
$wp["263"] = $baba.$cikmatarihi.$baba;
$wp["264"] = $baba.$cikmatarihi.$kardes;
$wp["265"] = $baba.$cikmatarihi.$sevgili;
$wp["267"] = $baba.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $baba.$cikmatarihi.$dogumtarihi;
$wp["269"] = $baba.$cikmatarihi.$dogumyili;
$wp["270"] = $baba.$cikmatarihi.$cikmayili;
$wp["271"] = $baba.$cikmatarihi.$cikmatarihi;
$wp["272"] = $baba.$cikmatarihi.$sehir;
$wp["273"] = $baba.$cikmatarihi.$takim;
$wp["274"] = $baba.$cikmatarihi.$takimtarihi;
$wp["275"] = $baba.$cikmatarihi.$takimkisa;
$wp["266"] = $baba.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $baba.$sehir;
$wp["277"] = $baba.$sehir."123";
$wp["278"] = $baba.$sehir."1905";
$wp["279"] = $baba.$sehir."1907";
$wp["280"] = $baba.$sehir."1903";
$wp["281"] = $baba.$sehir."1938";
$wp["282"] = $baba.$sehir."1919";
$wp["283"] = $baba.$sehir."1881";
$wp["284"] = $baba.$sehir."2018";
$wp["285"] = $baba.$sehir."2019";
$wp["286"] = $baba.$sehir.$lakap;
$wp["287"] = $baba.$sehir.$anne;
$wp["288"] = $baba.$sehir.$baba;
$wp["289"] = $baba.$sehir.$kardes;
$wp["290"] = $baba.$sehir.$sevgili;
$wp["291"] = $baba.$sehir.$sevgilisoyad;
$wp["292"] = $baba.$sehir.$dogumtarihi;
$wp["293"] = $baba.$sehir.$dogumyili;
$wp["294"] = $baba.$sehir.$cikmayili;
$wp["295"] = $baba.$sehir.$cikmatarihi;
$wp["296"] = $baba.$sehir.$sehir;
$wp["297"] = $baba.$sehir.$takim;
$wp["298"] = $baba.$sehir.$takimtarihi;
$wp["299"] = $baba.$sehir.$takimkisa;
$wp["300"] = $baba.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $baba.$takim;
$wp["302"] = $baba.$takim."123";
$wp["303"] = $baba.$takim."1905";
$wp["304"] = $baba.$takim."1907";
$wp["305"] = $baba.$takim."1903";
$wp["306"] = $baba.$takim."1938";
$wp["307"] = $baba.$takim."1919";
$wp["308"] = $baba.$takim."1881";
$wp["309"] = $baba.$takim."2018";
$wp["310"] = $baba.$takim."2019";
$wp["311"] = $baba.$takim.$lakap;
$wp["312"] = $baba.$takim.$anne;
$wp["313"] = $baba.$takim.$baba;
$wp["314"] = $baba.$takim.$kardes;
$wp["315"] = $baba.$takim.$sevgili;
$wp["316"] = $baba.$takim.$sevgilisoyad;
$wp["317"] = $baba.$takim.$dogumtarihi;
$wp["318"] = $baba.$takim.$dogumyili;
$wp["319"] = $baba.$takim.$cikmayili;
$wp["320"] = $baba.$takim.$cikmatarihi;
$wp["321"] = $baba.$takim.$sehir;
$wp["322"] = $baba.$takim.$takim;
$wp["323"] = $baba.$takim.$takimtarihi;
$wp["324"] = $baba.$takim.$takimkisa;
$wp["325"] = $baba.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $baba.$takimtarihi;
$wp["327"] = $baba.$takimtarihi."123";
$wp["328"] = $baba.$takimtarihi."1905";
$wp["329"] = $baba.$takimtarihi."1907";
$wp["330"] = $baba.$takimtarihi."1903";
$wp["331"] = $baba.$takimtarihi."1938";
$wp["332"] = $baba.$takimtarihi."1919";
$wp["333"] = $baba.$takimtarihi."1881";
$wp["334"] = $baba.$takimtarihi."2018";
$wp["335"] = $baba.$takimtarihi."2019";
$wp["336"] = $baba.$takimtarihi.$lakap;
$wp["337"] = $baba.$takimtarihi.$anne;
$wp["338"] = $baba.$takimtarihi.$baba;
$wp["339"] = $baba.$takimtarihi.$kardes;
$wp["340"] = $baba.$takimtarihi.$sevgili;
$wp["341"] = $baba.$takimtarihi.$sevgilisoyad;
$wp["342"] = $baba.$takimtarihi.$dogumtarihi;
$wp["343"] = $baba.$takimtarihi.$dogumyili;
$wp["344"] = $baba.$takimtarihi.$cikmayili;
$wp["345"] = $baba.$takimtarihi.$cikmatarihi;
$wp["346"] = $baba.$takimtarihi.$sehir;
$wp["347"] = $baba.$takimtarihi.$takim;
$wp["348"] = $baba.$takimtarihi.$takimtarihi;
$wp["349"] = $baba.$takimtarihi.$takimkisa;
$wp["350"] = $baba.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $baba.$takimkisa;
$wp["352"] = $baba.$takimkisa."123";
$wp["353"] = $baba.$takimkisa."1905";
$wp["354"] = $baba.$takimkisa."1907";
$wp["355"] = $baba.$takimkisa."1903";
$wp["356"] = $baba.$takimkisa."1938";
$wp["357"] = $baba.$takimkisa."1919";
$wp["358"] = $baba.$takimkisa."1881";
$wp["359"] = $baba.$takimkisa."2018";
$wp["360"] = $baba.$takimkisa."2019";
$wp["361"] = $baba.$takimkisa.$lakap;
$wp["362"] = $baba.$takimkisa.$anne;
$wp["363"] = $baba.$takimkisa.$baba;
$wp["364"] = $baba.$takimkisa.$kardes;
$wp["365"] = $baba.$takimkisa.$sevgili;
$wp["366"] = $baba.$takimkisa.$sevgilisoyad;
$wp["367"] = $baba.$takimkisa.$dogumtarihi;
$wp["368"] = $baba.$takimkisa.$dogumyili;
$wp["369"] = $baba.$takimkisa.$cikmayili;
$wp["370"] = $baba.$takimkisa.$cikmatarihi;
$wp["371"] = $baba.$takimkisa.$sehir;
$wp["372"] = $baba.$takimkisa.$takim;
$wp["373"] = $baba.$takimkisa.$takimtarihi;
$wp["374"] = $baba.$takimkisa.$takimkisa;
$wp["375"] = $baba.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $baba.$plaka;
$wp["377"] = $baba.$plaka."123";
$wp["378"] = $baba.$plaka."1905";
$wp["379"] = $baba.$plaka."1907";
$wp["380"] = $baba.$plaka."1903";
$wp["381"] = $baba.$plaka."1938";
$wp["382"] = $baba.$plaka."1919";
$wp["383"] = $baba.$plaka."1881";
$wp["384"] = $baba.$plaka."2018";
$wp["385"] = $baba.$plaka."2019";
$wp["386"] = $baba.$plaka.$lakap;
$wp["387"] = $baba.$plaka.$anne;
$wp["388"] = $baba.$plaka.$baba;
$wp["389"] = $baba.$plaka.$kardes;
$wp["390"] = $baba.$plaka.$sevgili;
$wp["391"] = $baba.$plaka.$sevgilisoyad;
$wp["392"] = $baba.$plaka.$dogumtarihi;
$wp["393"] = $baba.$plaka.$dogumyili;
$wp["394"] = $baba.$plaka.$cikmayili;
$wp["395"] = $baba.$plaka.$cikmatarihi;
$wp["396"] = $baba.$plaka.$sehir;
$wp["397"] = $baba.$plaka.$takim;
$wp["398"] = $baba.$plaka.$takimtarihi;
$wp["399"] = $baba.$plaka.$takimkisa;
$wp["400"] = $baba.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $baba.$eskisifre;
$wp["402"] = $baba.$eskisifre."123";
$wp["403"] = $baba.$eskisifre."1905";
$wp["404"] = $baba.$eskisifre."1907";
$wp["405"] = $baba.$eskisifre."1903";
$wp["406"] = $baba.$eskisifre."1938";
$wp["407"] = $baba.$eskisifre."1919";
$wp["408"] = $baba.$eskisifre."1881";
$wp["409"] = $baba.$eskisifre."2018";
$wp["410"] = $baba.$eskisifre."2019";
$wp["411"] = $baba.$eskisifre.$lakap;
$wp["412"] = $baba.$eskisifre.$anne;
$wp["413"] = $baba.$eskisifre.$baba;
$wp["414"] = $baba.$eskisifre.$kardes;
$wp["415"] = $baba.$eskisifre.$sevgili;
$wp["416"] = $baba.$eskisifre.$sevgilisoyad;
$wp["417"] = $baba.$eskisifre.$dogumtarihi;
$wp["418"] = $baba.$eskisifre.$dogumyili;
$wp["419"] = $baba.$eskisifre.$cikmayili;
$wp["420"] = $baba.$eskisifre.$cikmatarihi;
$wp["421"] = $baba.$eskisifre.$sehir;
$wp["422"] = $baba.$eskisifre.$takim;
$wp["423"] = $baba.$eskisifre.$takimtarihi;
$wp["424"] = $baba.$eskisifre.$takimkisa;
$wp["425"] = $baba.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $baba.$tel;
$wp["427"] = $baba.$tel."123";
$wp["428"] = $baba.$tel."1905";
$wp["429"] = $baba.$tel."1907";
$wp["430"] = $baba.$tel."1903";
$wp["431"] = $baba.$tel."1938";
$wp["432"] = $baba.$tel."1919";
$wp["433"] = $baba.$tel."1881";
$wp["434"] = $baba.$tel."2018";
$wp["435"] = $baba.$tel."2019";
$wp["436"] = $baba.$tel.$lakap;
$wp["437"] = $baba.$tel.$anne;
$wp["438"] = $baba.$tel.$baba;
$wp["439"] = $baba.$tel.$kardes;
$wp["440"] = $baba.$tel.$sevgili;
$wp["441"] = $baba.$tel.$sevgilisoyad;
$wp["442"] = $baba.$tel.$dogumtarihi;
$wp["443"] = $baba.$tel.$dogumyili;
$wp["444"] = $baba.$tel.$cikmayili;
$wp["445"] = $baba.$tel.$cikmatarihi;
$wp["446"] = $baba.$tel.$sehir;
$wp["447"] = $baba.$tel.$takim;
$wp["448"] = $baba.$tel.$takimtarihi;
$wp["449"] = $baba.$tel.$takimkisa;
$wp["450"] = $baba.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $baba.$annetel;
$wp["452"] = $baba.$annetel."123";
$wp["453"] = $baba.$annetel."1905";
$wp["454"] = $baba.$annetel."1907";
$wp["455"] = $baba.$annetel."1903";
$wp["456"] = $baba.$annetel."1938";
$wp["457"] = $baba.$annetel."1919";
$wp["458"] = $baba.$annetel."1881";
$wp["459"] = $baba.$annetel."2018";
$wp["460"] = $baba.$annetel."2019";
$wp["461"] = $baba.$annetel.$lakap;
$wp["462"] = $baba.$annetel.$anne;
$wp["463"] = $baba.$annetel.$baba;
$wp["464"] = $baba.$annetel.$kardes;
$wp["465"] = $baba.$annetel.$sevgili;
$wp["466"] = $baba.$annetel.$sevgilisoyad;
$wp["467"] = $baba.$annetel.$dogumtarihi;
$wp["468"] = $baba.$annetel.$dogumyili;
$wp["469"] = $baba.$annetel.$cikmayili;
$wp["470"] = $baba.$annetel.$cikmatarihi;
$wp["471"] = $baba.$annetel.$sehir;
$wp["472"] = $baba.$annetel.$takim;
$wp["473"] = $baba.$annetel.$takimtarihi;
$wp["474"] = $baba.$annetel.$takimkisa;
$wp["475"] = $baba.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $baba.$babatel;
$wp["477"] = $baba.$babatel."123";
$wp["478"] = $baba.$babatel."1905";
$wp["479"] = $baba.$babatel."1907";
$wp["480"] = $baba.$babatel."1903";
$wp["481"] = $baba.$babatel."1938";
$wp["482"] = $baba.$babatel."1919";
$wp["483"] = $baba.$babatel."1881";
$wp["484"] = $baba.$babatel."2018";
$wp["485"] = $baba.$babatel."2019";
$wp["486"] = $baba.$babatel.$lakap;
$wp["487"] = $baba.$babatel.$anne;
$wp["488"] = $baba.$babatel.$baba;
$wp["489"] = $baba.$babatel.$kardes;
$wp["490"] = $baba.$babatel.$sevgili;
$wp["491"] = $baba.$babatel.$sevgilisoyad;
$wp["492"] = $baba.$babatel.$dogumtarihi;
$wp["493"] = $baba.$babatel.$dogumyili;
$wp["494"] = $baba.$babatel.$cikmayili;
$wp["495"] = $baba.$babatel.$cikmatarihi;
$wp["496"] = $baba.$babatel.$sehir;
$wp["497"] = $baba.$babatel.$takim;
$wp["498"] = $baba.$babatel.$takimtarihi;
$wp["499"] = $baba.$babatel.$takimkisa;
$wp["500"] = $baba.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $baba.$kardestel;
$wp["502"] = $baba.$kardestel."123";
$wp["503"] = $baba.$kardestel."1905";
$wp["504"] = $baba.$kardestel."1907";
$wp["505"] = $baba.$kardestel."1903";
$wp["506"] = $baba.$kardestel."1938";
$wp["507"] = $baba.$kardestel."1919";
$wp["508"] = $baba.$kardestel."1881";
$wp["509"] = $baba.$kardestel."2018";
$wp["510"] = $baba.$kardestel."2019";
$wp["511"] = $baba.$kardestel.$lakap;
$wp["512"] = $baba.$kardestel.$anne;
$wp["513"] = $baba.$kardestel.$baba;
$wp["514"] = $baba.$kardestel.$kardes;
$wp["515"] = $baba.$kardestel.$sevgili;
$wp["516"] = $baba.$kardestel.$sevgilisoyad;
$wp["517"] = $baba.$kardestel.$dogumtarihi;
$wp["518"] = $baba.$kardestel.$dogumyili;
$wp["519"] = $baba.$kardestel.$cikmayili;
$wp["520"] = $baba.$kardestel.$cikmatarihi;
$wp["521"] = $baba.$kardestel.$sehir;
$wp["522"] = $baba.$kardestel.$takim;
$wp["523"] = $baba.$kardestel.$takimtarihi;
$wp["524"] = $baba.$kardestel.$takimkisa;
$wp["525"] = $baba.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $baba.$sevgilitel;
$wp["527"] = $baba.$sevgilitel."123";
$wp["528"] = $baba.$sevgilitel."1905";
$wp["529"] = $baba.$sevgilitel."1907";
$wp["530"] = $baba.$sevgilitel."1903";
$wp["531"] = $baba.$sevgilitel."1938";
$wp["532"] = $baba.$sevgilitel."1919";
$wp["533"] = $baba.$sevgilitel."1881";
$wp["534"] = $baba.$sevgilitel."2018";
$wp["535"] = $baba.$sevgilitel."2019";
$wp["536"] = $baba.$sevgilitel.$lakap;
$wp["537"] = $baba.$sevgilitel.$anne;
$wp["538"] = $baba.$sevgilitel.$baba;
$wp["539"] = $baba.$sevgilitel.$kardes;
$wp["540"] = $baba.$sevgilitel.$sevgili;
$wp["541"] = $baba.$sevgilitel.$sevgilisoyad;
$wp["542"] = $baba.$sevgilitel.$dogumtarihi;
$wp["543"] = $baba.$sevgilitel.$dogumyili;
$wp["544"] = $baba.$sevgilitel.$cikmayili;
$wp["545"] = $baba.$sevgilitel.$cikmatarihi;
$wp["546"] = $baba.$sevgilitel.$sehir;
$wp["547"] = $baba.$sevgilitel.$takim;
$wp["548"] = $baba.$sevgilitel.$takimtarihi;
$wp["549"] = $baba.$sevgilitel.$takimkisa;
$wp["550"] = $baba.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $baba.$tckimlikno;
$wp["552"] = $baba.$tckimlikno."13";
$wp["553"] = $baba.$tckimlikno."1905";
$wp["554"] = $baba.$tckimlikno."1907";
$wp["555"] = $baba.$tckimlikno."1903";
$wp["556"] = $baba.$tckimlikno."1938";
$wp["557"] = $baba.$tckimlikno."1919";
$wp["558"] = $baba.$tckimlikno."1881";
$wp["559"] = $baba.$tckimlikno."2018";
$wp["560"] = $baba.$tckimlikno."2019";
$wp["561"] = $baba.$tckimlikno.$lakap;
$wp["562"] = $baba.$tckimlikno.$anne;
$wp["563"] = $baba.$tckimlikno.$baba;
$wp["564"] = $baba.$tckimlikno.$kardes;
$wp["565"] = $baba.$tckimlikno.$sevgili;
$wp["566"] = $baba.$tckimlikno.$sevgilisoyad;
$wp["567"] = $baba.$tckimlikno.$dogumtarihi;
$wp["568"] = $baba.$tckimlikno.$dogumyili;
$wp["569"] = $baba.$tckimlikno.$cikmayili;
$wp["570"] = $baba.$tckimlikno.$cikmatarihi;
$wp["571"] = $baba.$tckimlikno.$sehir;
$wp["572"] = $baba.$tckimlikno.$takim;
$wp["573"] = $baba.$tckimlikno.$takimtarihi;
$wp["574"] = $baba.$tckimlikno.$takimkisa;
$wp["575"] = $baba.$tckimlikno.$plaka;






for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);


 ?>