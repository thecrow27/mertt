<?php 

error_reporting(0);

include "kayit.php";






$wp["1"] = $babatel;
$wp["2"] = $babatel.$soyadad."123";
$wp["3"] = $babatel.$soyadad."1905";
$wp["4"] = $babatel.$soyadad."1907";
$wp["5"] = $babatel.$soyadad."1903";
$wp["6"] = $babatel.$soyadad."1938";
$wp["7"] = $babatel.$soyadad."1919";
$wp["8"] = $babatel.$soyadad."1881";
$wp["9"] = $babatel.$soyadad."2018";
$wp["10"] = $babatel.$soyadad."2019";
$wp["11"] = $babatel.$soyadad.$lakap;
$wp["12"] = $babatel.$soyadad.$anne;
$wp["13"] = $babatel.$soyadad.$baba;
$wp["14"] = $babatel.$soyadad.$kardes;
$wp["15"] = $babatel.$soyadad.$sevgili;
$wp["16"] = $babatel.$soyadad.$sevgilisoyad;
$wp["17"] = $babatel.$soyadad.$dogumtarihi;
$wp["18"] = $babatel.$soyadad.$dogumyili;
$wp["19"] = $babatel.$soyadad.$cikmayili;
$wp["20"] = $babatel.$soyadad.$cikmatarihi;
$wp["21"] = $babatel.$soyadad.$sehir;
$wp["22"] = $babatel.$soyadad.$takim;
$wp["23"] = $babatel.$soyadad.$takimtarihi;
$wp["24"] = $babatel.$soyadad.$takimkisa;
$wp["25"] = $babatel.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $babatel.$lakap;
$wp["27"] = $babatel.$lakap."123";
$wp["28"] = $babatel.$lakap."1905";
$wp["29"] = $babatel.$lakap."1907";
$wp["30"] = $babatel.$lakap."1903";
$wp["31"] = $babatel.$lakap."1938";
$wp["32"] = $babatel.$lakap."1919";
$wp["33"] = $babatel.$lakap."1881";
$wp["34"] = $babatel.$lakap."2018";
$wp["35"] = $babatel.$lakap."2019";
$wp["36"] = $babatel.$lakap.$lakap;
$wp["37"] = $babatel.$lakap.$anne;
$wp["38"] = $babatel.$lakap.$baba;
$wp["39"] = $babatel.$lakap.$kardes;
$wp["40"] = $babatel.$lakap.$sevgili;
$wp["41"] = $babatel.$lakap.$sevgilisoyad;
$wp["42"] = $babatel.$lakap.$dogumtarihi;
$wp["43"] = $babatel.$lakap.$dogumyili;
$wp["44"] = $babatel.$lakap.$cikmayili;
$wp["45"] = $babatel.$lakap.$cikmatarihi;
$wp["46"] = $babatel.$lakap.$sehir;
$wp["47"] = $babatel.$lakap.$takim;
$wp["48"] = $babatel.$lakap.$takimtarihi;
$wp["49"] = $babatel.$lakap.$takimkisa;
$wp["50"] = $babatel.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $babatel.$anne;
$wp["52"] = $babatel.$anne."123";
$wp["53"] = $babatel.$anne."1905";
$wp["54"] = $babatel.$anne."1907";
$wp["55"] = $babatel.$anne."1903";
$wp["56"] = $babatel.$anne."1938";
$wp["57"] = $babatel.$anne."1919";
$wp["58"] = $babatel.$anne."1881";
$wp["59"] = $babatel.$anne."2018";
$wp["60"] = $babatel.$anne."2019";
$wp["61"] = $babatel.$anne.$lakap;
$wp["62"] = $babatel.$anne.$anne;
$wp["63"] = $babatel.$anne.$baba;
$wp["64"] = $babatel.$anne.$kardes;
$wp["65"] = $babatel.$anne.$sevgili;
$wp["66"] = $babatel.$anne.$sevgilisoyad;
$wp["67"] = $babatel.$anne.$dogumtarihi;
$wp["68"] = $babatel.$anne.$dogumyili;
$wp["69"] = $babatel.$anne.$cikmayili;
$wp["70"] = $babatel.$anne.$cikmatarihi;
$wp["71"] = $babatel.$anne.$sehir;
$wp["72"] = $babatel.$anne.$takim;
$wp["73"] = $babatel.$anne.$takimtarihi;
$wp["74"] = $babatel.$anne.$takimkisa;
$wp["75"] = $babatel.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $babatel.$baba;
$wp["77"] = $babatel.$baba."123";
$wp["78"] = $babatel.$baba."1905";
$wp["79"] = $babatel.$baba."1907";
$wp["80"] = $babatel.$baba."1903";
$wp["81"] = $babatel.$baba."1938";
$wp["82"] = $babatel.$baba."1919";
$wp["83"] = $babatel.$baba."1881";
$wp["84"] = $babatel.$baba."2018";
$wp["85"] = $babatel.$baba."2019";
$wp["86"] = $babatel.$baba.$lakap;
$wp["87"] = $babatel.$baba.$anne;
$wp["88"] = $babatel.$baba.$baba;
$wp["89"] = $babatel.$baba.$kardes;
$wp["90"] = $babatel.$baba.$sevgili;
$wp["91"] = $babatel.$baba.$sevgilisoyad;
$wp["92"] = $babatel.$baba.$dogumtarihi;
$wp["93"] = $babatel.$baba.$dogumyili;
$wp["94"] = $babatel.$baba.$cikmayili;
$wp["95"] = $babatel.$baba.$cikmatarihi;
$wp["96"] = $babatel.$baba.$sehir;
$wp["97"] = $babatel.$baba.$takim;
$wp["98"] = $babatel.$baba.$takimtarihi;
$wp["99"] = $babatel.$baba.$takimkisa;
$wp["100"] = $babatel.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $babatel.$kardes;
$wp["102"] = $babatel.$kardes."123";
$wp["103"] = $babatel.$kardes."1905";
$wp["104"] = $babatel.$kardes."1907";
$wp["105"] = $babatel.$kardes."1903";
$wp["106"] = $babatel.$kardes."1938";
$wp["107"] = $babatel.$kardes."1919";
$wp["108"] = $babatel.$kardes."1881";
$wp["109"] = $babatel.$kardes."2018";
$wp["110"] = $babatel.$kardes."2019";
$wp["111"] = $babatel.$kardes.$lakap;
$wp["112"] = $babatel.$kardes.$anne;
$wp["113"] = $babatel.$kardes.$baba;
$wp["114"] = $babatel.$kardes.$kardes;
$wp["115"] = $babatel.$kardes.$sevgili;
$wp["116"] = $babatel.$kardes.$sevgilisoyad;
$wp["117"] = $babatel.$kardes.$dogumtarihi;
$wp["118"] = $babatel.$kardes.$dogumyili;
$wp["119"] = $babatel.$kardes.$cikmayili;
$wp["120"] = $babatel.$kardes.$cikmatarihi;
$wp["121"] = $babatel.$kardes.$sehir;
$wp["122"] = $babatel.$kardes.$takim;
$wp["123"] = $babatel.$kardes.$takimtarihi;
$wp["124"] = $babatel.$kardes.$takimkisa;
$wp["125"] = $babatel.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $babatel.$sevgili;
$wp["127"] = $babatel.$sevgili."123";
$wp["128"] = $babatel.$sevgili."1905";
$wp["129"] = $babatel.$sevgili."1907";
$wp["130"] = $babatel.$sevgili."1903";
$wp["131"] = $babatel.$sevgili."1938";
$wp["132"] = $babatel.$sevgili."1919";
$wp["133"] = $babatel.$sevgili."1881";
$wp["134"] = $babatel.$sevgili."2018";
$wp["135"] = $babatel.$sevgili."2019";
$wp["136"] = $babatel.$sevgili.$lakap;
$wp["137"] = $babatel.$sevgili.$anne;
$wp["138"] = $babatel.$sevgili.$baba;
$wp["139"] = $babatel.$sevgili.$kardes;
$wp["140"] = $babatel.$sevgili.$sevgili;
$wp["141"] = $babatel.$sevgili.$sevgilisoyad;
$wp["142"] = $babatel.$sevgili.$dogumtarihi;
$wp["143"] = $babatel.$sevgili.$dogumyili;
$wp["144"] = $babatel.$sevgili.$cikmayili;
$wp["145"] = $babatel.$sevgili.$cikmatarihi;
$wp["146"] = $babatel.$sevgili.$sehir;
$wp["147"] = $babatel.$sevgili.$takim;
$wp["148"] = $babatel.$sevgili.$takimtarihi;
$wp["149"] = $babatel.$sevgili.$takimkisa;
$wp["150"] = $babatel.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $babatel.$sevgilisoyad;
$wp["152"] = $babatel.$sevgilisoyad."123";
$wp["153"] = $babatel.$sevgilisoyad."1905";
$wp["154"] = $babatel.$sevgilisoyad."1907";
$wp["155"] = $babatel.$sevgilisoyad."1903";
$wp["156"] = $babatel.$sevgilisoyad."1938";
$wp["157"] = $babatel.$sevgilisoyad."1919";
$wp["158"] = $babatel.$sevgilisoyad."1881";
$wp["159"] = $babatel.$sevgilisoyad."2018";
$wp["160"] = $babatel.$sevgilisoyad."2019";
$wp["161"] = $babatel.$sevgilisoyad.$lakap;
$wp["162"] = $babatel.$sevgilisoyad.$anne;
$wp["163"] = $babatel.$sevgilisoyad.$baba;
$wp["164"] = $babatel.$sevgilisoyad.$kardes;
$wp["165"] = $babatel.$sevgilisoyad.$sevgili;
$wp["166"] = $babatel.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $babatel.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $babatel.$sevgilisoyad.$dogumyili;
$wp["169"] = $babatel.$sevgilisoyad.$cikmayili;
$wp["170"] = $babatel.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $babatel.$sevgilisoyad.$sehir;
$wp["172"] = $babatel.$sevgilisoyad.$takim;
$wp["173"] = $babatel.$sevgilisoyad.$takimtarihi;
$wp["174"] = $babatel.$sevgilisoyad.$takimkisa;
$wp["175"] = $babatel.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $babatel.$dogumtarihi;
$wp["177"] = $babatel.$dogumtarihi."123";
$wp["178"] = $babatel.$dogumtarihi."1905";
$wp["179"] = $babatel.$dogumtarihi."1907";
$wp["180"] = $babatel.$dogumtarihi."1903";
$wp["181"] = $babatel.$dogumtarihi."1938";
$wp["200"] = $babatel.$dogumtarihi."1919";
$wp["182"] = $babatel.$dogumtarihi."1881";
$wp["183"] = $babatel.$dogumtarihi."2018";
$wp["184"] = $babatel.$dogumtarihi."2019";
$wp["185"] = $babatel.$dogumtarihi.$lakap;
$wp["186"] = $babatel.$dogumtarihi.$anne;
$wp["187"] = $babatel.$dogumtarihi.$baba;
$wp["188"] = $babatel.$dogumtarihi.$kardes;
$wp["189"] = $babatel.$dogumtarihi.$sevgili;
$wp["190"] = $babatel.$dogumtarihi.$dogumtarihi;
$wp["191"] = $babatel.$dogumtarihi.$dogumtarihi;
$wp["192"] = $babatel.$dogumtarihi.$dogumyili;
$wp["193"] = $babatel.$dogumtarihi.$cikmayili;
$wp["194"] = $babatel.$dogumtarihi.$cikmatarihi;
$wp["195"] = $babatel.$dogumtarihi.$sehir;
$wp["196"] = $babatel.$dogumtarihi.$takim;
$wp["197"] = $babatel.$dogumtarihi.$takimtarihi;
$wp["198"] = $babatel.$dogumtarihi.$takimkisa;
$wp["199"] = $babatel.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $babatel.$dogumyili;
$wp["202"] = $babatel.$dogumyili."123";
$wp["203"] = $babatel.$dogumyili."1905";
$wp["204"] = $babatel.$dogumyili."1907";
$wp["205"] = $babatel.$dogumyili."1903";
$wp["206"] = $babatel.$dogumyili."1938";
$wp["207"] = $babatel.$dogumyili."1919";
$wp["208"] = $babatel.$dogumyili."1881";
$wp["209"] = $babatel.$dogumyili."2018";
$wp["210"] = $babatel.$dogumyili."2019";
$wp["211"] = $babatel.$dogumyili.$lakap;
$wp["212"] = $babatel.$dogumyili.$anne;
$wp["213"] = $babatel.$dogumyili.$baba;
$wp["214"] = $babatel.$dogumyili.$kardes;
$wp["215"] = $babatel.$dogumyili.$sevgili;
$wp["216"] = $babatel.$dogumyili.$dogumyili;
$wp["217"] = $babatel.$dogumyili.$dogumyili;
$wp["218"] = $babatel.$dogumyili.$dogumyili;
$wp["219"] = $babatel.$dogumyili.$cikmayili;
$wp["220"] = $babatel.$dogumyili.$cikmatarihi;
$wp["221"] = $babatel.$dogumyili.$sehir;
$wp["222"] = $babatel.$dogumyili.$takim;
$wp["223"] = $babatel.$dogumyili.$takimtarihi;
$wp["224"] = $babatel.$dogumyili.$takimkisa;
$wp["225"] = $babatel.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $babatel.$cikmayili;
$wp["227"] = $babatel.$cikmayili."123";
$wp["228"] = $babatel.$cikmayili."1905";
$wp["229"] = $babatel.$cikmayili."1907";
$wp["230"] = $babatel.$cikmayili."1903";
$wp["231"] = $babatel.$cikmayili."1938";
$wp["232"] = $babatel.$cikmayili."1919";
$wp["233"] = $babatel.$cikmayili."1881";
$wp["234"] = $babatel.$cikmayili."2018";
$wp["235"] = $babatel.$cikmayili."2019";
$wp["236"] = $babatel.$cikmayili.$lakap;
$wp["237"] = $babatel.$cikmayili.$anne;
$wp["238"] = $babatel.$cikmayili.$baba;
$wp["239"] = $babatel.$cikmayili.$kardes;
$wp["240"] = $babatel.$cikmayili.$sevgili;
$wp["241"] = $babatel.$cikmayili.$cikmayili;
$wp["242"] = $babatel.$cikmayili.$dogumyili;
$wp["243"] = $babatel.$cikmayili.$cikmayili;
$wp["244"] = $babatel.$cikmayili.$cikmayili;
$wp["245"] = $babatel.$cikmayili.$cikmatarihi;
$wp["246"] = $babatel.$cikmayili.$sehir;
$wp["247"] = $babatel.$cikmayili.$takim;
$wp["248"] = $babatel.$cikmayili.$takimtarihi;
$wp["249"] = $babatel.$cikmayili.$takimkisa;
$wp["250"] = $babatel.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $babatel.$cikmatarihi;
$wp["252"] = $babatel.$cikmatarihi."123";
$wp["253"] = $babatel.$cikmatarihi."1905";
$wp["254"] = $babatel.$cikmatarihi."1907";
$wp["255"] = $babatel.$cikmatarihi."1903";
$wp["256"] = $babatel.$cikmatarihi."1938";
$wp["257"] = $babatel.$cikmatarihi."1919";
$wp["258"] = $babatel.$cikmatarihi."1881";
$wp["259"] = $babatel.$cikmatarihi."2018";
$wp["260"] = $babatel.$cikmatarihi."2019";
$wp["261"] = $babatel.$cikmatarihi.$lakap;
$wp["262"] = $babatel.$cikmatarihi.$anne;
$wp["263"] = $babatel.$cikmatarihi.$baba;
$wp["264"] = $babatel.$cikmatarihi.$kardes;
$wp["265"] = $babatel.$cikmatarihi.$sevgili;
$wp["267"] = $babatel.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $babatel.$cikmatarihi.$dogumtarihi;
$wp["269"] = $babatel.$cikmatarihi.$dogumyili;
$wp["270"] = $babatel.$cikmatarihi.$cikmayili;
$wp["271"] = $babatel.$cikmatarihi.$cikmatarihi;
$wp["272"] = $babatel.$cikmatarihi.$sehir;
$wp["273"] = $babatel.$cikmatarihi.$takim;
$wp["274"] = $babatel.$cikmatarihi.$takimtarihi;
$wp["275"] = $babatel.$cikmatarihi.$takimkisa;
$wp["266"] = $babatel.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $babatel.$sehir;
$wp["277"] = $babatel.$sehir."123";
$wp["278"] = $babatel.$sehir."1905";
$wp["279"] = $babatel.$sehir."1907";
$wp["280"] = $babatel.$sehir."1903";
$wp["281"] = $babatel.$sehir."1938";
$wp["282"] = $babatel.$sehir."1919";
$wp["283"] = $babatel.$sehir."1881";
$wp["284"] = $babatel.$sehir."2018";
$wp["285"] = $babatel.$sehir."2019";
$wp["286"] = $babatel.$sehir.$lakap;
$wp["287"] = $babatel.$sehir.$anne;
$wp["288"] = $babatel.$sehir.$baba;
$wp["289"] = $babatel.$sehir.$kardes;
$wp["290"] = $babatel.$sehir.$sevgili;
$wp["291"] = $babatel.$sehir.$sevgilisoyad;
$wp["292"] = $babatel.$sehir.$dogumtarihi;
$wp["293"] = $babatel.$sehir.$dogumyili;
$wp["294"] = $babatel.$sehir.$cikmayili;
$wp["295"] = $babatel.$sehir.$cikmatarihi;
$wp["296"] = $babatel.$sehir.$sehir;
$wp["297"] = $babatel.$sehir.$takim;
$wp["298"] = $babatel.$sehir.$takimtarihi;
$wp["299"] = $babatel.$sehir.$takimkisa;
$wp["300"] = $babatel.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $babatel.$takim;
$wp["302"] = $babatel.$takim."123";
$wp["303"] = $babatel.$takim."1905";
$wp["304"] = $babatel.$takim."1907";
$wp["305"] = $babatel.$takim."1903";
$wp["306"] = $babatel.$takim."1938";
$wp["307"] = $babatel.$takim."1919";
$wp["308"] = $babatel.$takim."1881";
$wp["309"] = $babatel.$takim."2018";
$wp["310"] = $babatel.$takim."2019";
$wp["311"] = $babatel.$takim.$lakap;
$wp["312"] = $babatel.$takim.$anne;
$wp["313"] = $babatel.$takim.$baba;
$wp["314"] = $babatel.$takim.$kardes;
$wp["315"] = $babatel.$takim.$sevgili;
$wp["316"] = $babatel.$takim.$sevgilisoyad;
$wp["317"] = $babatel.$takim.$dogumtarihi;
$wp["318"] = $babatel.$takim.$dogumyili;
$wp["319"] = $babatel.$takim.$cikmayili;
$wp["320"] = $babatel.$takim.$cikmatarihi;
$wp["321"] = $babatel.$takim.$sehir;
$wp["322"] = $babatel.$takim.$takim;
$wp["323"] = $babatel.$takim.$takimtarihi;
$wp["324"] = $babatel.$takim.$takimkisa;
$wp["325"] = $babatel.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $babatel.$takimtarihi;
$wp["327"] = $babatel.$takimtarihi."123";
$wp["328"] = $babatel.$takimtarihi."1905";
$wp["329"] = $babatel.$takimtarihi."1907";
$wp["330"] = $babatel.$takimtarihi."1903";
$wp["331"] = $babatel.$takimtarihi."1938";
$wp["332"] = $babatel.$takimtarihi."1919";
$wp["333"] = $babatel.$takimtarihi."1881";
$wp["334"] = $babatel.$takimtarihi."2018";
$wp["335"] = $babatel.$takimtarihi."2019";
$wp["336"] = $babatel.$takimtarihi.$lakap;
$wp["337"] = $babatel.$takimtarihi.$anne;
$wp["338"] = $babatel.$takimtarihi.$baba;
$wp["339"] = $babatel.$takimtarihi.$kardes;
$wp["340"] = $babatel.$takimtarihi.$sevgili;
$wp["341"] = $babatel.$takimtarihi.$sevgilisoyad;
$wp["342"] = $babatel.$takimtarihi.$dogumtarihi;
$wp["343"] = $babatel.$takimtarihi.$dogumyili;
$wp["344"] = $babatel.$takimtarihi.$cikmayili;
$wp["345"] = $babatel.$takimtarihi.$cikmatarihi;
$wp["346"] = $babatel.$takimtarihi.$sehir;
$wp["347"] = $babatel.$takimtarihi.$takim;
$wp["348"] = $babatel.$takimtarihi.$takimtarihi;
$wp["349"] = $babatel.$takimtarihi.$takimkisa;
$wp["350"] = $babatel.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $babatel.$takimkisa;
$wp["352"] = $babatel.$takimkisa."123";
$wp["353"] = $babatel.$takimkisa."1905";
$wp["354"] = $babatel.$takimkisa."1907";
$wp["355"] = $babatel.$takimkisa."1903";
$wp["356"] = $babatel.$takimkisa."1938";
$wp["357"] = $babatel.$takimkisa."1919";
$wp["358"] = $babatel.$takimkisa."1881";
$wp["359"] = $babatel.$takimkisa."2018";
$wp["360"] = $babatel.$takimkisa."2019";
$wp["361"] = $babatel.$takimkisa.$lakap;
$wp["362"] = $babatel.$takimkisa.$anne;
$wp["363"] = $babatel.$takimkisa.$baba;
$wp["364"] = $babatel.$takimkisa.$kardes;
$wp["365"] = $babatel.$takimkisa.$sevgili;
$wp["366"] = $babatel.$takimkisa.$sevgilisoyad;
$wp["367"] = $babatel.$takimkisa.$dogumtarihi;
$wp["368"] = $babatel.$takimkisa.$dogumyili;
$wp["369"] = $babatel.$takimkisa.$cikmayili;
$wp["370"] = $babatel.$takimkisa.$cikmatarihi;
$wp["371"] = $babatel.$takimkisa.$sehir;
$wp["372"] = $babatel.$takimkisa.$takim;
$wp["373"] = $babatel.$takimkisa.$takimtarihi;
$wp["374"] = $babatel.$takimkisa.$takimkisa;
$wp["375"] = $babatel.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $babatel.$plaka;
$wp["377"] = $babatel.$plaka."123";
$wp["378"] = $babatel.$plaka."1905";
$wp["379"] = $babatel.$plaka."1907";
$wp["380"] = $babatel.$plaka."1903";
$wp["381"] = $babatel.$plaka."1938";
$wp["382"] = $babatel.$plaka."1919";
$wp["383"] = $babatel.$plaka."1881";
$wp["384"] = $babatel.$plaka."2018";
$wp["385"] = $babatel.$plaka."2019";
$wp["386"] = $babatel.$plaka.$lakap;
$wp["387"] = $babatel.$plaka.$anne;
$wp["388"] = $babatel.$plaka.$baba;
$wp["389"] = $babatel.$plaka.$kardes;
$wp["390"] = $babatel.$plaka.$sevgili;
$wp["391"] = $babatel.$plaka.$sevgilisoyad;
$wp["392"] = $babatel.$plaka.$dogumtarihi;
$wp["393"] = $babatel.$plaka.$dogumyili;
$wp["394"] = $babatel.$plaka.$cikmayili;
$wp["395"] = $babatel.$plaka.$cikmatarihi;
$wp["396"] = $babatel.$plaka.$sehir;
$wp["397"] = $babatel.$plaka.$takim;
$wp["398"] = $babatel.$plaka.$takimtarihi;
$wp["399"] = $babatel.$plaka.$takimkisa;
$wp["400"] = $babatel.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $babatel.$eskisifre;
$wp["402"] = $babatel.$eskisifre."123";
$wp["403"] = $babatel.$eskisifre."1905";
$wp["404"] = $babatel.$eskisifre."1907";
$wp["405"] = $babatel.$eskisifre."1903";
$wp["406"] = $babatel.$eskisifre."1938";
$wp["407"] = $babatel.$eskisifre."1919";
$wp["408"] = $babatel.$eskisifre."1881";
$wp["409"] = $babatel.$eskisifre."2018";
$wp["410"] = $babatel.$eskisifre."2019";
$wp["411"] = $babatel.$eskisifre.$lakap;
$wp["412"] = $babatel.$eskisifre.$anne;
$wp["413"] = $babatel.$eskisifre.$baba;
$wp["414"] = $babatel.$eskisifre.$kardes;
$wp["415"] = $babatel.$eskisifre.$sevgili;
$wp["416"] = $babatel.$eskisifre.$sevgilisoyad;
$wp["417"] = $babatel.$eskisifre.$dogumtarihi;
$wp["418"] = $babatel.$eskisifre.$dogumyili;
$wp["419"] = $babatel.$eskisifre.$cikmayili;
$wp["420"] = $babatel.$eskisifre.$cikmatarihi;
$wp["421"] = $babatel.$eskisifre.$sehir;
$wp["422"] = $babatel.$eskisifre.$takim;
$wp["423"] = $babatel.$eskisifre.$takimtarihi;
$wp["424"] = $babatel.$eskisifre.$takimkisa;
$wp["425"] = $babatel.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $babatel.$tel;
$wp["427"] = $babatel.$tel."123";
$wp["428"] = $babatel.$tel."1905";
$wp["429"] = $babatel.$tel."1907";
$wp["430"] = $babatel.$tel."1903";
$wp["431"] = $babatel.$tel."1938";
$wp["432"] = $babatel.$tel."1919";
$wp["433"] = $babatel.$tel."1881";
$wp["434"] = $babatel.$tel."2018";
$wp["435"] = $babatel.$tel."2019";
$wp["436"] = $babatel.$tel.$lakap;
$wp["437"] = $babatel.$tel.$anne;
$wp["438"] = $babatel.$tel.$baba;
$wp["439"] = $babatel.$tel.$kardes;
$wp["440"] = $babatel.$tel.$sevgili;
$wp["441"] = $babatel.$tel.$sevgilisoyad;
$wp["442"] = $babatel.$tel.$dogumtarihi;
$wp["443"] = $babatel.$tel.$dogumyili;
$wp["444"] = $babatel.$tel.$cikmayili;
$wp["445"] = $babatel.$tel.$cikmatarihi;
$wp["446"] = $babatel.$tel.$sehir;
$wp["447"] = $babatel.$tel.$takim;
$wp["448"] = $babatel.$tel.$takimtarihi;
$wp["449"] = $babatel.$tel.$takimkisa;
$wp["450"] = $babatel.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $babatel.$annetel;
$wp["452"] = $babatel.$annetel."123";
$wp["453"] = $babatel.$annetel."1905";
$wp["454"] = $babatel.$annetel."1907";
$wp["455"] = $babatel.$annetel."1903";
$wp["456"] = $babatel.$annetel."1938";
$wp["457"] = $babatel.$annetel."1919";
$wp["458"] = $babatel.$annetel."1881";
$wp["459"] = $babatel.$annetel."2018";
$wp["460"] = $babatel.$annetel."2019";
$wp["461"] = $babatel.$annetel.$lakap;
$wp["462"] = $babatel.$annetel.$anne;
$wp["463"] = $babatel.$annetel.$baba;
$wp["464"] = $babatel.$annetel.$kardes;
$wp["465"] = $babatel.$annetel.$sevgili;
$wp["466"] = $babatel.$annetel.$sevgilisoyad;
$wp["467"] = $babatel.$annetel.$dogumtarihi;
$wp["468"] = $babatel.$annetel.$dogumyili;
$wp["469"] = $babatel.$annetel.$cikmayili;
$wp["470"] = $babatel.$annetel.$cikmatarihi;
$wp["471"] = $babatel.$annetel.$sehir;
$wp["472"] = $babatel.$annetel.$takim;
$wp["473"] = $babatel.$annetel.$takimtarihi;
$wp["474"] = $babatel.$annetel.$takimkisa;
$wp["475"] = $babatel.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $babatel.$babatel;
$wp["477"] = $babatel.$babatel."123";
$wp["478"] = $babatel.$babatel."1905";
$wp["479"] = $babatel.$babatel."1907";
$wp["480"] = $babatel.$babatel."1903";
$wp["481"] = $babatel.$babatel."1938";
$wp["482"] = $babatel.$babatel."1919";
$wp["483"] = $babatel.$babatel."1881";
$wp["484"] = $babatel.$babatel."2018";
$wp["485"] = $babatel.$babatel."2019";
$wp["486"] = $babatel.$babatel.$lakap;
$wp["487"] = $babatel.$babatel.$anne;
$wp["488"] = $babatel.$babatel.$baba;
$wp["489"] = $babatel.$babatel.$kardes;
$wp["490"] = $babatel.$babatel.$sevgili;
$wp["491"] = $babatel.$babatel.$sevgilisoyad;
$wp["492"] = $babatel.$babatel.$dogumtarihi;
$wp["493"] = $babatel.$babatel.$dogumyili;
$wp["494"] = $babatel.$babatel.$cikmayili;
$wp["495"] = $babatel.$babatel.$cikmatarihi;
$wp["496"] = $babatel.$babatel.$sehir;
$wp["497"] = $babatel.$babatel.$takim;
$wp["498"] = $babatel.$babatel.$takimtarihi;
$wp["499"] = $babatel.$babatel.$takimkisa;
$wp["500"] = $babatel.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $babatel.$kardestel;
$wp["502"] = $babatel.$kardestel."123";
$wp["503"] = $babatel.$kardestel."1905";
$wp["504"] = $babatel.$kardestel."1907";
$wp["505"] = $babatel.$kardestel."1903";
$wp["506"] = $babatel.$kardestel."1938";
$wp["507"] = $babatel.$kardestel."1919";
$wp["508"] = $babatel.$kardestel."1881";
$wp["509"] = $babatel.$kardestel."2018";
$wp["510"] = $babatel.$kardestel."2019";
$wp["511"] = $babatel.$kardestel.$lakap;
$wp["512"] = $babatel.$kardestel.$anne;
$wp["513"] = $babatel.$kardestel.$baba;
$wp["514"] = $babatel.$kardestel.$kardes;
$wp["515"] = $babatel.$kardestel.$sevgili;
$wp["516"] = $babatel.$kardestel.$sevgilisoyad;
$wp["517"] = $babatel.$kardestel.$dogumtarihi;
$wp["518"] = $babatel.$kardestel.$dogumyili;
$wp["519"] = $babatel.$kardestel.$cikmayili;
$wp["520"] = $babatel.$kardestel.$cikmatarihi;
$wp["521"] = $babatel.$kardestel.$sehir;
$wp["522"] = $babatel.$kardestel.$takim;
$wp["523"] = $babatel.$kardestel.$takimtarihi;
$wp["524"] = $babatel.$kardestel.$takimkisa;
$wp["525"] = $babatel.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $babatel.$sevgilitel;
$wp["527"] = $babatel.$sevgilitel."123";
$wp["528"] = $babatel.$sevgilitel."1905";
$wp["529"] = $babatel.$sevgilitel."1907";
$wp["530"] = $babatel.$sevgilitel."1903";
$wp["531"] = $babatel.$sevgilitel."1938";
$wp["532"] = $babatel.$sevgilitel."1919";
$wp["533"] = $babatel.$sevgilitel."1881";
$wp["534"] = $babatel.$sevgilitel."2018";
$wp["535"] = $babatel.$sevgilitel."2019";
$wp["536"] = $babatel.$sevgilitel.$lakap;
$wp["537"] = $babatel.$sevgilitel.$anne;
$wp["538"] = $babatel.$sevgilitel.$baba;
$wp["539"] = $babatel.$sevgilitel.$kardes;
$wp["540"] = $babatel.$sevgilitel.$sevgili;
$wp["541"] = $babatel.$sevgilitel.$sevgilisoyad;
$wp["542"] = $babatel.$sevgilitel.$dogumtarihi;
$wp["543"] = $babatel.$sevgilitel.$dogumyili;
$wp["544"] = $babatel.$sevgilitel.$cikmayili;
$wp["545"] = $babatel.$sevgilitel.$cikmatarihi;
$wp["546"] = $babatel.$sevgilitel.$sehir;
$wp["547"] = $babatel.$sevgilitel.$takim;
$wp["548"] = $babatel.$sevgilitel.$takimtarihi;
$wp["549"] = $babatel.$sevgilitel.$takimkisa;
$wp["550"] = $babatel.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $babatel.$tckimlikno;
$wp["552"] = $babatel.$tckimlikno."13";
$wp["553"] = $babatel.$tckimlikno."1905";
$wp["554"] = $babatel.$tckimlikno."1907";
$wp["555"] = $babatel.$tckimlikno."1903";
$wp["556"] = $babatel.$tckimlikno."1938";
$wp["557"] = $babatel.$tckimlikno."1919";
$wp["558"] = $babatel.$tckimlikno."1881";
$wp["559"] = $babatel.$tckimlikno."2018";
$wp["560"] = $babatel.$tckimlikno."2019";
$wp["561"] = $babatel.$tckimlikno.$lakap;
$wp["562"] = $babatel.$tckimlikno.$anne;
$wp["563"] = $babatel.$tckimlikno.$baba;
$wp["564"] = $babatel.$tckimlikno.$kardes;
$wp["565"] = $babatel.$tckimlikno.$sevgili;
$wp["566"] = $babatel.$tckimlikno.$sevgilisoyad;
$wp["567"] = $babatel.$tckimlikno.$dogumtarihi;
$wp["568"] = $babatel.$tckimlikno.$dogumyili;
$wp["569"] = $babatel.$tckimlikno.$cikmayili;
$wp["570"] = $babatel.$tckimlikno.$cikmatarihi;
$wp["571"] = $babatel.$tckimlikno.$sehir;
$wp["572"] = $babatel.$tckimlikno.$takim;
$wp["573"] = $babatel.$tckimlikno.$takimtarihi;
$wp["574"] = $babatel.$tckimlikno.$takimkisa;
$wp["575"] = $babatel.$tckimlikno.$plaka;



for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);


 ?>