<?php 

error_reporting(0);

include "kayit.php";




$wp["1"] = $kardestel;
$wp["2"] = $kardestel.$soyadad."123";
$wp["3"] = $kardestel.$soyadad."1905";
$wp["4"] = $kardestel.$soyadad."1907";
$wp["5"] = $kardestel.$soyadad."1903";
$wp["6"] = $kardestel.$soyadad."1938";
$wp["7"] = $kardestel.$soyadad."1919";
$wp["8"] = $kardestel.$soyadad."1881";
$wp["9"] = $kardestel.$soyadad."2018";
$wp["10"] = $kardestel.$soyadad."2019";
$wp["11"] = $kardestel.$soyadad.$lakap;
$wp["12"] = $kardestel.$soyadad.$anne;
$wp["13"] = $kardestel.$soyadad.$baba;
$wp["14"] = $kardestel.$soyadad.$kardes;
$wp["15"] = $kardestel.$soyadad.$sevgili;
$wp["16"] = $kardestel.$soyadad.$sevgilisoyad;
$wp["17"] = $kardestel.$soyadad.$dogumtarihi;
$wp["18"] = $kardestel.$soyadad.$dogumyili;
$wp["19"] = $kardestel.$soyadad.$cikmayili;
$wp["20"] = $kardestel.$soyadad.$cikmatarihi;
$wp["21"] = $kardestel.$soyadad.$sehir;
$wp["22"] = $kardestel.$soyadad.$takim;
$wp["23"] = $kardestel.$soyadad.$takimtarihi;
$wp["24"] = $kardestel.$soyadad.$takimkisa;
$wp["25"] = $kardestel.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $kardestel.$lakap;
$wp["27"] = $kardestel.$lakap."123";
$wp["28"] = $kardestel.$lakap."1905";
$wp["29"] = $kardestel.$lakap."1907";
$wp["30"] = $kardestel.$lakap."1903";
$wp["31"] = $kardestel.$lakap."1938";
$wp["32"] = $kardestel.$lakap."1919";
$wp["33"] = $kardestel.$lakap."1881";
$wp["34"] = $kardestel.$lakap."2018";
$wp["35"] = $kardestel.$lakap."2019";
$wp["36"] = $kardestel.$lakap.$lakap;
$wp["37"] = $kardestel.$lakap.$anne;
$wp["38"] = $kardestel.$lakap.$baba;
$wp["39"] = $kardestel.$lakap.$kardes;
$wp["40"] = $kardestel.$lakap.$sevgili;
$wp["41"] = $kardestel.$lakap.$sevgilisoyad;
$wp["42"] = $kardestel.$lakap.$dogumtarihi;
$wp["43"] = $kardestel.$lakap.$dogumyili;
$wp["44"] = $kardestel.$lakap.$cikmayili;
$wp["45"] = $kardestel.$lakap.$cikmatarihi;
$wp["46"] = $kardestel.$lakap.$sehir;
$wp["47"] = $kardestel.$lakap.$takim;
$wp["48"] = $kardestel.$lakap.$takimtarihi;
$wp["49"] = $kardestel.$lakap.$takimkisa;
$wp["50"] = $kardestel.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $kardestel.$anne;
$wp["52"] = $kardestel.$anne."123";
$wp["53"] = $kardestel.$anne."1905";
$wp["54"] = $kardestel.$anne."1907";
$wp["55"] = $kardestel.$anne."1903";
$wp["56"] = $kardestel.$anne."1938";
$wp["57"] = $kardestel.$anne."1919";
$wp["58"] = $kardestel.$anne."1881";
$wp["59"] = $kardestel.$anne."2018";
$wp["60"] = $kardestel.$anne."2019";
$wp["61"] = $kardestel.$anne.$lakap;
$wp["62"] = $kardestel.$anne.$anne;
$wp["63"] = $kardestel.$anne.$baba;
$wp["64"] = $kardestel.$anne.$kardes;
$wp["65"] = $kardestel.$anne.$sevgili;
$wp["66"] = $kardestel.$anne.$sevgilisoyad;
$wp["67"] = $kardestel.$anne.$dogumtarihi;
$wp["68"] = $kardestel.$anne.$dogumyili;
$wp["69"] = $kardestel.$anne.$cikmayili;
$wp["70"] = $kardestel.$anne.$cikmatarihi;
$wp["71"] = $kardestel.$anne.$sehir;
$wp["72"] = $kardestel.$anne.$takim;
$wp["73"] = $kardestel.$anne.$takimtarihi;
$wp["74"] = $kardestel.$anne.$takimkisa;
$wp["75"] = $kardestel.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $kardestel.$baba;
$wp["77"] = $kardestel.$baba."123";
$wp["78"] = $kardestel.$baba."1905";
$wp["79"] = $kardestel.$baba."1907";
$wp["80"] = $kardestel.$baba."1903";
$wp["81"] = $kardestel.$baba."1938";
$wp["82"] = $kardestel.$baba."1919";
$wp["83"] = $kardestel.$baba."1881";
$wp["84"] = $kardestel.$baba."2018";
$wp["85"] = $kardestel.$baba."2019";
$wp["86"] = $kardestel.$baba.$lakap;
$wp["87"] = $kardestel.$baba.$anne;
$wp["88"] = $kardestel.$baba.$baba;
$wp["89"] = $kardestel.$baba.$kardes;
$wp["90"] = $kardestel.$baba.$sevgili;
$wp["91"] = $kardestel.$baba.$sevgilisoyad;
$wp["92"] = $kardestel.$baba.$dogumtarihi;
$wp["93"] = $kardestel.$baba.$dogumyili;
$wp["94"] = $kardestel.$baba.$cikmayili;
$wp["95"] = $kardestel.$baba.$cikmatarihi;
$wp["96"] = $kardestel.$baba.$sehir;
$wp["97"] = $kardestel.$baba.$takim;
$wp["98"] = $kardestel.$baba.$takimtarihi;
$wp["99"] = $kardestel.$baba.$takimkisa;
$wp["100"] = $kardestel.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $kardestel.$kardes;
$wp["102"] = $kardestel.$kardes."123";
$wp["103"] = $kardestel.$kardes."1905";
$wp["104"] = $kardestel.$kardes."1907";
$wp["105"] = $kardestel.$kardes."1903";
$wp["106"] = $kardestel.$kardes."1938";
$wp["107"] = $kardestel.$kardes."1919";
$wp["108"] = $kardestel.$kardes."1881";
$wp["109"] = $kardestel.$kardes."2018";
$wp["110"] = $kardestel.$kardes."2019";
$wp["111"] = $kardestel.$kardes.$lakap;
$wp["112"] = $kardestel.$kardes.$anne;
$wp["113"] = $kardestel.$kardes.$baba;
$wp["114"] = $kardestel.$kardes.$kardes;
$wp["115"] = $kardestel.$kardes.$sevgili;
$wp["116"] = $kardestel.$kardes.$sevgilisoyad;
$wp["117"] = $kardestel.$kardes.$dogumtarihi;
$wp["118"] = $kardestel.$kardes.$dogumyili;
$wp["119"] = $kardestel.$kardes.$cikmayili;
$wp["120"] = $kardestel.$kardes.$cikmatarihi;
$wp["121"] = $kardestel.$kardes.$sehir;
$wp["122"] = $kardestel.$kardes.$takim;
$wp["123"] = $kardestel.$kardes.$takimtarihi;
$wp["124"] = $kardestel.$kardes.$takimkisa;
$wp["125"] = $kardestel.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $kardestel.$sevgili;
$wp["127"] = $kardestel.$sevgili."123";
$wp["128"] = $kardestel.$sevgili."1905";
$wp["129"] = $kardestel.$sevgili."1907";
$wp["130"] = $kardestel.$sevgili."1903";
$wp["131"] = $kardestel.$sevgili."1938";
$wp["132"] = $kardestel.$sevgili."1919";
$wp["133"] = $kardestel.$sevgili."1881";
$wp["134"] = $kardestel.$sevgili."2018";
$wp["135"] = $kardestel.$sevgili."2019";
$wp["136"] = $kardestel.$sevgili.$lakap;
$wp["137"] = $kardestel.$sevgili.$anne;
$wp["138"] = $kardestel.$sevgili.$baba;
$wp["139"] = $kardestel.$sevgili.$kardes;
$wp["140"] = $kardestel.$sevgili.$sevgili;
$wp["141"] = $kardestel.$sevgili.$sevgilisoyad;
$wp["142"] = $kardestel.$sevgili.$dogumtarihi;
$wp["143"] = $kardestel.$sevgili.$dogumyili;
$wp["144"] = $kardestel.$sevgili.$cikmayili;
$wp["145"] = $kardestel.$sevgili.$cikmatarihi;
$wp["146"] = $kardestel.$sevgili.$sehir;
$wp["147"] = $kardestel.$sevgili.$takim;
$wp["148"] = $kardestel.$sevgili.$takimtarihi;
$wp["149"] = $kardestel.$sevgili.$takimkisa;
$wp["150"] = $kardestel.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $kardestel.$sevgilisoyad;
$wp["152"] = $kardestel.$sevgilisoyad."123";
$wp["153"] = $kardestel.$sevgilisoyad."1905";
$wp["154"] = $kardestel.$sevgilisoyad."1907";
$wp["155"] = $kardestel.$sevgilisoyad."1903";
$wp["156"] = $kardestel.$sevgilisoyad."1938";
$wp["157"] = $kardestel.$sevgilisoyad."1919";
$wp["158"] = $kardestel.$sevgilisoyad."1881";
$wp["159"] = $kardestel.$sevgilisoyad."2018";
$wp["160"] = $kardestel.$sevgilisoyad."2019";
$wp["161"] = $kardestel.$sevgilisoyad.$lakap;
$wp["162"] = $kardestel.$sevgilisoyad.$anne;
$wp["163"] = $kardestel.$sevgilisoyad.$baba;
$wp["164"] = $kardestel.$sevgilisoyad.$kardes;
$wp["165"] = $kardestel.$sevgilisoyad.$sevgili;
$wp["166"] = $kardestel.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $kardestel.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $kardestel.$sevgilisoyad.$dogumyili;
$wp["169"] = $kardestel.$sevgilisoyad.$cikmayili;
$wp["170"] = $kardestel.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $kardestel.$sevgilisoyad.$sehir;
$wp["172"] = $kardestel.$sevgilisoyad.$takim;
$wp["173"] = $kardestel.$sevgilisoyad.$takimtarihi;
$wp["174"] = $kardestel.$sevgilisoyad.$takimkisa;
$wp["175"] = $kardestel.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $kardestel.$dogumtarihi;
$wp["177"] = $kardestel.$dogumtarihi."123";
$wp["178"] = $kardestel.$dogumtarihi."1905";
$wp["179"] = $kardestel.$dogumtarihi."1907";
$wp["180"] = $kardestel.$dogumtarihi."1903";
$wp["181"] = $kardestel.$dogumtarihi."1938";
$wp["200"] = $kardestel.$dogumtarihi."1919";
$wp["182"] = $kardestel.$dogumtarihi."1881";
$wp["183"] = $kardestel.$dogumtarihi."2018";
$wp["184"] = $kardestel.$dogumtarihi."2019";
$wp["185"] = $kardestel.$dogumtarihi.$lakap;
$wp["186"] = $kardestel.$dogumtarihi.$anne;
$wp["187"] = $kardestel.$dogumtarihi.$baba;
$wp["188"] = $kardestel.$dogumtarihi.$kardes;
$wp["189"] = $kardestel.$dogumtarihi.$sevgili;
$wp["190"] = $kardestel.$dogumtarihi.$dogumtarihi;
$wp["191"] = $kardestel.$dogumtarihi.$dogumtarihi;
$wp["192"] = $kardestel.$dogumtarihi.$dogumyili;
$wp["193"] = $kardestel.$dogumtarihi.$cikmayili;
$wp["194"] = $kardestel.$dogumtarihi.$cikmatarihi;
$wp["195"] = $kardestel.$dogumtarihi.$sehir;
$wp["196"] = $kardestel.$dogumtarihi.$takim;
$wp["197"] = $kardestel.$dogumtarihi.$takimtarihi;
$wp["198"] = $kardestel.$dogumtarihi.$takimkisa;
$wp["199"] = $kardestel.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $kardestel.$dogumyili;
$wp["202"] = $kardestel.$dogumyili."123";
$wp["203"] = $kardestel.$dogumyili."1905";
$wp["204"] = $kardestel.$dogumyili."1907";
$wp["205"] = $kardestel.$dogumyili."1903";
$wp["206"] = $kardestel.$dogumyili."1938";
$wp["207"] = $kardestel.$dogumyili."1919";
$wp["208"] = $kardestel.$dogumyili."1881";
$wp["209"] = $kardestel.$dogumyili."2018";
$wp["210"] = $kardestel.$dogumyili."2019";
$wp["211"] = $kardestel.$dogumyili.$lakap;
$wp["212"] = $kardestel.$dogumyili.$anne;
$wp["213"] = $kardestel.$dogumyili.$baba;
$wp["214"] = $kardestel.$dogumyili.$kardes;
$wp["215"] = $kardestel.$dogumyili.$sevgili;
$wp["216"] = $kardestel.$dogumyili.$dogumyili;
$wp["217"] = $kardestel.$dogumyili.$dogumyili;
$wp["218"] = $kardestel.$dogumyili.$dogumyili;
$wp["219"] = $kardestel.$dogumyili.$cikmayili;
$wp["220"] = $kardestel.$dogumyili.$cikmatarihi;
$wp["221"] = $kardestel.$dogumyili.$sehir;
$wp["222"] = $kardestel.$dogumyili.$takim;
$wp["223"] = $kardestel.$dogumyili.$takimtarihi;
$wp["224"] = $kardestel.$dogumyili.$takimkisa;
$wp["225"] = $kardestel.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $kardestel.$cikmayili;
$wp["227"] = $kardestel.$cikmayili."123";
$wp["228"] = $kardestel.$cikmayili."1905";
$wp["229"] = $kardestel.$cikmayili."1907";
$wp["230"] = $kardestel.$cikmayili."1903";
$wp["231"] = $kardestel.$cikmayili."1938";
$wp["232"] = $kardestel.$cikmayili."1919";
$wp["233"] = $kardestel.$cikmayili."1881";
$wp["234"] = $kardestel.$cikmayili."2018";
$wp["235"] = $kardestel.$cikmayili."2019";
$wp["236"] = $kardestel.$cikmayili.$lakap;
$wp["237"] = $kardestel.$cikmayili.$anne;
$wp["238"] = $kardestel.$cikmayili.$baba;
$wp["239"] = $kardestel.$cikmayili.$kardes;
$wp["240"] = $kardestel.$cikmayili.$sevgili;
$wp["241"] = $kardestel.$cikmayili.$cikmayili;
$wp["242"] = $kardestel.$cikmayili.$dogumyili;
$wp["243"] = $kardestel.$cikmayili.$cikmayili;
$wp["244"] = $kardestel.$cikmayili.$cikmayili;
$wp["245"] = $kardestel.$cikmayili.$cikmatarihi;
$wp["246"] = $kardestel.$cikmayili.$sehir;
$wp["247"] = $kardestel.$cikmayili.$takim;
$wp["248"] = $kardestel.$cikmayili.$takimtarihi;
$wp["249"] = $kardestel.$cikmayili.$takimkisa;
$wp["250"] = $kardestel.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $kardestel.$cikmatarihi;
$wp["252"] = $kardestel.$cikmatarihi."123";
$wp["253"] = $kardestel.$cikmatarihi."1905";
$wp["254"] = $kardestel.$cikmatarihi."1907";
$wp["255"] = $kardestel.$cikmatarihi."1903";
$wp["256"] = $kardestel.$cikmatarihi."1938";
$wp["257"] = $kardestel.$cikmatarihi."1919";
$wp["258"] = $kardestel.$cikmatarihi."1881";
$wp["259"] = $kardestel.$cikmatarihi."2018";
$wp["260"] = $kardestel.$cikmatarihi."2019";
$wp["261"] = $kardestel.$cikmatarihi.$lakap;
$wp["262"] = $kardestel.$cikmatarihi.$anne;
$wp["263"] = $kardestel.$cikmatarihi.$baba;
$wp["264"] = $kardestel.$cikmatarihi.$kardes;
$wp["265"] = $kardestel.$cikmatarihi.$sevgili;
$wp["267"] = $kardestel.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $kardestel.$cikmatarihi.$dogumtarihi;
$wp["269"] = $kardestel.$cikmatarihi.$dogumyili;
$wp["270"] = $kardestel.$cikmatarihi.$cikmayili;
$wp["271"] = $kardestel.$cikmatarihi.$cikmatarihi;
$wp["272"] = $kardestel.$cikmatarihi.$sehir;
$wp["273"] = $kardestel.$cikmatarihi.$takim;
$wp["274"] = $kardestel.$cikmatarihi.$takimtarihi;
$wp["275"] = $kardestel.$cikmatarihi.$takimkisa;
$wp["266"] = $kardestel.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $kardestel.$sehir;
$wp["277"] = $kardestel.$sehir."123";
$wp["278"] = $kardestel.$sehir."1905";
$wp["279"] = $kardestel.$sehir."1907";
$wp["280"] = $kardestel.$sehir."1903";
$wp["281"] = $kardestel.$sehir."1938";
$wp["282"] = $kardestel.$sehir."1919";
$wp["283"] = $kardestel.$sehir."1881";
$wp["284"] = $kardestel.$sehir."2018";
$wp["285"] = $kardestel.$sehir."2019";
$wp["286"] = $kardestel.$sehir.$lakap;
$wp["287"] = $kardestel.$sehir.$anne;
$wp["288"] = $kardestel.$sehir.$baba;
$wp["289"] = $kardestel.$sehir.$kardes;
$wp["290"] = $kardestel.$sehir.$sevgili;
$wp["291"] = $kardestel.$sehir.$sevgilisoyad;
$wp["292"] = $kardestel.$sehir.$dogumtarihi;
$wp["293"] = $kardestel.$sehir.$dogumyili;
$wp["294"] = $kardestel.$sehir.$cikmayili;
$wp["295"] = $kardestel.$sehir.$cikmatarihi;
$wp["296"] = $kardestel.$sehir.$sehir;
$wp["297"] = $kardestel.$sehir.$takim;
$wp["298"] = $kardestel.$sehir.$takimtarihi;
$wp["299"] = $kardestel.$sehir.$takimkisa;
$wp["300"] = $kardestel.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $kardestel.$takim;
$wp["302"] = $kardestel.$takim."123";
$wp["303"] = $kardestel.$takim."1905";
$wp["304"] = $kardestel.$takim."1907";
$wp["305"] = $kardestel.$takim."1903";
$wp["306"] = $kardestel.$takim."1938";
$wp["307"] = $kardestel.$takim."1919";
$wp["308"] = $kardestel.$takim."1881";
$wp["309"] = $kardestel.$takim."2018";
$wp["310"] = $kardestel.$takim."2019";
$wp["311"] = $kardestel.$takim.$lakap;
$wp["312"] = $kardestel.$takim.$anne;
$wp["313"] = $kardestel.$takim.$baba;
$wp["314"] = $kardestel.$takim.$kardes;
$wp["315"] = $kardestel.$takim.$sevgili;
$wp["316"] = $kardestel.$takim.$sevgilisoyad;
$wp["317"] = $kardestel.$takim.$dogumtarihi;
$wp["318"] = $kardestel.$takim.$dogumyili;
$wp["319"] = $kardestel.$takim.$cikmayili;
$wp["320"] = $kardestel.$takim.$cikmatarihi;
$wp["321"] = $kardestel.$takim.$sehir;
$wp["322"] = $kardestel.$takim.$takim;
$wp["323"] = $kardestel.$takim.$takimtarihi;
$wp["324"] = $kardestel.$takim.$takimkisa;
$wp["325"] = $kardestel.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $kardestel.$takimtarihi;
$wp["327"] = $kardestel.$takimtarihi."123";
$wp["328"] = $kardestel.$takimtarihi."1905";
$wp["329"] = $kardestel.$takimtarihi."1907";
$wp["330"] = $kardestel.$takimtarihi."1903";
$wp["331"] = $kardestel.$takimtarihi."1938";
$wp["332"] = $kardestel.$takimtarihi."1919";
$wp["333"] = $kardestel.$takimtarihi."1881";
$wp["334"] = $kardestel.$takimtarihi."2018";
$wp["335"] = $kardestel.$takimtarihi."2019";
$wp["336"] = $kardestel.$takimtarihi.$lakap;
$wp["337"] = $kardestel.$takimtarihi.$anne;
$wp["338"] = $kardestel.$takimtarihi.$baba;
$wp["339"] = $kardestel.$takimtarihi.$kardes;
$wp["340"] = $kardestel.$takimtarihi.$sevgili;
$wp["341"] = $kardestel.$takimtarihi.$sevgilisoyad;
$wp["342"] = $kardestel.$takimtarihi.$dogumtarihi;
$wp["343"] = $kardestel.$takimtarihi.$dogumyili;
$wp["344"] = $kardestel.$takimtarihi.$cikmayili;
$wp["345"] = $kardestel.$takimtarihi.$cikmatarihi;
$wp["346"] = $kardestel.$takimtarihi.$sehir;
$wp["347"] = $kardestel.$takimtarihi.$takim;
$wp["348"] = $kardestel.$takimtarihi.$takimtarihi;
$wp["349"] = $kardestel.$takimtarihi.$takimkisa;
$wp["350"] = $kardestel.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $kardestel.$takimkisa;
$wp["352"] = $kardestel.$takimkisa."123";
$wp["353"] = $kardestel.$takimkisa."1905";
$wp["354"] = $kardestel.$takimkisa."1907";
$wp["355"] = $kardestel.$takimkisa."1903";
$wp["356"] = $kardestel.$takimkisa."1938";
$wp["357"] = $kardestel.$takimkisa."1919";
$wp["358"] = $kardestel.$takimkisa."1881";
$wp["359"] = $kardestel.$takimkisa."2018";
$wp["360"] = $kardestel.$takimkisa."2019";
$wp["361"] = $kardestel.$takimkisa.$lakap;
$wp["362"] = $kardestel.$takimkisa.$anne;
$wp["363"] = $kardestel.$takimkisa.$baba;
$wp["364"] = $kardestel.$takimkisa.$kardes;
$wp["365"] = $kardestel.$takimkisa.$sevgili;
$wp["366"] = $kardestel.$takimkisa.$sevgilisoyad;
$wp["367"] = $kardestel.$takimkisa.$dogumtarihi;
$wp["368"] = $kardestel.$takimkisa.$dogumyili;
$wp["369"] = $kardestel.$takimkisa.$cikmayili;
$wp["370"] = $kardestel.$takimkisa.$cikmatarihi;
$wp["371"] = $kardestel.$takimkisa.$sehir;
$wp["372"] = $kardestel.$takimkisa.$takim;
$wp["373"] = $kardestel.$takimkisa.$takimtarihi;
$wp["374"] = $kardestel.$takimkisa.$takimkisa;
$wp["375"] = $kardestel.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $kardestel.$plaka;
$wp["377"] = $kardestel.$plaka."123";
$wp["378"] = $kardestel.$plaka."1905";
$wp["379"] = $kardestel.$plaka."1907";
$wp["380"] = $kardestel.$plaka."1903";
$wp["381"] = $kardestel.$plaka."1938";
$wp["382"] = $kardestel.$plaka."1919";
$wp["383"] = $kardestel.$plaka."1881";
$wp["384"] = $kardestel.$plaka."2018";
$wp["385"] = $kardestel.$plaka."2019";
$wp["386"] = $kardestel.$plaka.$lakap;
$wp["387"] = $kardestel.$plaka.$anne;
$wp["388"] = $kardestel.$plaka.$baba;
$wp["389"] = $kardestel.$plaka.$kardes;
$wp["390"] = $kardestel.$plaka.$sevgili;
$wp["391"] = $kardestel.$plaka.$sevgilisoyad;
$wp["392"] = $kardestel.$plaka.$dogumtarihi;
$wp["393"] = $kardestel.$plaka.$dogumyili;
$wp["394"] = $kardestel.$plaka.$cikmayili;
$wp["395"] = $kardestel.$plaka.$cikmatarihi;
$wp["396"] = $kardestel.$plaka.$sehir;
$wp["397"] = $kardestel.$plaka.$takim;
$wp["398"] = $kardestel.$plaka.$takimtarihi;
$wp["399"] = $kardestel.$plaka.$takimkisa;
$wp["400"] = $kardestel.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $kardestel.$eskisifre;
$wp["402"] = $kardestel.$eskisifre."123";
$wp["403"] = $kardestel.$eskisifre."1905";
$wp["404"] = $kardestel.$eskisifre."1907";
$wp["405"] = $kardestel.$eskisifre."1903";
$wp["406"] = $kardestel.$eskisifre."1938";
$wp["407"] = $kardestel.$eskisifre."1919";
$wp["408"] = $kardestel.$eskisifre."1881";
$wp["409"] = $kardestel.$eskisifre."2018";
$wp["410"] = $kardestel.$eskisifre."2019";
$wp["411"] = $kardestel.$eskisifre.$lakap;
$wp["412"] = $kardestel.$eskisifre.$anne;
$wp["413"] = $kardestel.$eskisifre.$baba;
$wp["414"] = $kardestel.$eskisifre.$kardes;
$wp["415"] = $kardestel.$eskisifre.$sevgili;
$wp["416"] = $kardestel.$eskisifre.$sevgilisoyad;
$wp["417"] = $kardestel.$eskisifre.$dogumtarihi;
$wp["418"] = $kardestel.$eskisifre.$dogumyili;
$wp["419"] = $kardestel.$eskisifre.$cikmayili;
$wp["420"] = $kardestel.$eskisifre.$cikmatarihi;
$wp["421"] = $kardestel.$eskisifre.$sehir;
$wp["422"] = $kardestel.$eskisifre.$takim;
$wp["423"] = $kardestel.$eskisifre.$takimtarihi;
$wp["424"] = $kardestel.$eskisifre.$takimkisa;
$wp["425"] = $kardestel.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $kardestel.$tel;
$wp["427"] = $kardestel.$tel."123";
$wp["428"] = $kardestel.$tel."1905";
$wp["429"] = $kardestel.$tel."1907";
$wp["430"] = $kardestel.$tel."1903";
$wp["431"] = $kardestel.$tel."1938";
$wp["432"] = $kardestel.$tel."1919";
$wp["433"] = $kardestel.$tel."1881";
$wp["434"] = $kardestel.$tel."2018";
$wp["435"] = $kardestel.$tel."2019";
$wp["436"] = $kardestel.$tel.$lakap;
$wp["437"] = $kardestel.$tel.$anne;
$wp["438"] = $kardestel.$tel.$baba;
$wp["439"] = $kardestel.$tel.$kardes;
$wp["440"] = $kardestel.$tel.$sevgili;
$wp["441"] = $kardestel.$tel.$sevgilisoyad;
$wp["442"] = $kardestel.$tel.$dogumtarihi;
$wp["443"] = $kardestel.$tel.$dogumyili;
$wp["444"] = $kardestel.$tel.$cikmayili;
$wp["445"] = $kardestel.$tel.$cikmatarihi;
$wp["446"] = $kardestel.$tel.$sehir;
$wp["447"] = $kardestel.$tel.$takim;
$wp["448"] = $kardestel.$tel.$takimtarihi;
$wp["449"] = $kardestel.$tel.$takimkisa;
$wp["450"] = $kardestel.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $kardestel.$annetel;
$wp["452"] = $kardestel.$annetel."123";
$wp["453"] = $kardestel.$annetel."1905";
$wp["454"] = $kardestel.$annetel."1907";
$wp["455"] = $kardestel.$annetel."1903";
$wp["456"] = $kardestel.$annetel."1938";
$wp["457"] = $kardestel.$annetel."1919";
$wp["458"] = $kardestel.$annetel."1881";
$wp["459"] = $kardestel.$annetel."2018";
$wp["460"] = $kardestel.$annetel."2019";
$wp["461"] = $kardestel.$annetel.$lakap;
$wp["462"] = $kardestel.$annetel.$anne;
$wp["463"] = $kardestel.$annetel.$baba;
$wp["464"] = $kardestel.$annetel.$kardes;
$wp["465"] = $kardestel.$annetel.$sevgili;
$wp["466"] = $kardestel.$annetel.$sevgilisoyad;
$wp["467"] = $kardestel.$annetel.$dogumtarihi;
$wp["468"] = $kardestel.$annetel.$dogumyili;
$wp["469"] = $kardestel.$annetel.$cikmayili;
$wp["470"] = $kardestel.$annetel.$cikmatarihi;
$wp["471"] = $kardestel.$annetel.$sehir;
$wp["472"] = $kardestel.$annetel.$takim;
$wp["473"] = $kardestel.$annetel.$takimtarihi;
$wp["474"] = $kardestel.$annetel.$takimkisa;
$wp["475"] = $kardestel.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $kardestel.$babatel;
$wp["477"] = $kardestel.$babatel."123";
$wp["478"] = $kardestel.$babatel."1905";
$wp["479"] = $kardestel.$babatel."1907";
$wp["480"] = $kardestel.$babatel."1903";
$wp["481"] = $kardestel.$babatel."1938";
$wp["482"] = $kardestel.$babatel."1919";
$wp["483"] = $kardestel.$babatel."1881";
$wp["484"] = $kardestel.$babatel."2018";
$wp["485"] = $kardestel.$babatel."2019";
$wp["486"] = $kardestel.$babatel.$lakap;
$wp["487"] = $kardestel.$babatel.$anne;
$wp["488"] = $kardestel.$babatel.$baba;
$wp["489"] = $kardestel.$babatel.$kardes;
$wp["490"] = $kardestel.$babatel.$sevgili;
$wp["491"] = $kardestel.$babatel.$sevgilisoyad;
$wp["492"] = $kardestel.$babatel.$dogumtarihi;
$wp["493"] = $kardestel.$babatel.$dogumyili;
$wp["494"] = $kardestel.$babatel.$cikmayili;
$wp["495"] = $kardestel.$babatel.$cikmatarihi;
$wp["496"] = $kardestel.$babatel.$sehir;
$wp["497"] = $kardestel.$babatel.$takim;
$wp["498"] = $kardestel.$babatel.$takimtarihi;
$wp["499"] = $kardestel.$babatel.$takimkisa;
$wp["500"] = $kardestel.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $kardestel.$kardestel;
$wp["502"] = $kardestel.$kardestel."123";
$wp["503"] = $kardestel.$kardestel."1905";
$wp["504"] = $kardestel.$kardestel."1907";
$wp["505"] = $kardestel.$kardestel."1903";
$wp["506"] = $kardestel.$kardestel."1938";
$wp["507"] = $kardestel.$kardestel."1919";
$wp["508"] = $kardestel.$kardestel."1881";
$wp["509"] = $kardestel.$kardestel."2018";
$wp["510"] = $kardestel.$kardestel."2019";
$wp["511"] = $kardestel.$kardestel.$lakap;
$wp["512"] = $kardestel.$kardestel.$anne;
$wp["513"] = $kardestel.$kardestel.$baba;
$wp["514"] = $kardestel.$kardestel.$kardes;
$wp["515"] = $kardestel.$kardestel.$sevgili;
$wp["516"] = $kardestel.$kardestel.$sevgilisoyad;
$wp["517"] = $kardestel.$kardestel.$dogumtarihi;
$wp["518"] = $kardestel.$kardestel.$dogumyili;
$wp["519"] = $kardestel.$kardestel.$cikmayili;
$wp["520"] = $kardestel.$kardestel.$cikmatarihi;
$wp["521"] = $kardestel.$kardestel.$sehir;
$wp["522"] = $kardestel.$kardestel.$takim;
$wp["523"] = $kardestel.$kardestel.$takimtarihi;
$wp["524"] = $kardestel.$kardestel.$takimkisa;
$wp["525"] = $kardestel.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $kardestel.$sevgilitel;
$wp["527"] = $kardestel.$sevgilitel."123";
$wp["528"] = $kardestel.$sevgilitel."1905";
$wp["529"] = $kardestel.$sevgilitel."1907";
$wp["530"] = $kardestel.$sevgilitel."1903";
$wp["531"] = $kardestel.$sevgilitel."1938";
$wp["532"] = $kardestel.$sevgilitel."1919";
$wp["533"] = $kardestel.$sevgilitel."1881";
$wp["534"] = $kardestel.$sevgilitel."2018";
$wp["535"] = $kardestel.$sevgilitel."2019";
$wp["536"] = $kardestel.$sevgilitel.$lakap;
$wp["537"] = $kardestel.$sevgilitel.$anne;
$wp["538"] = $kardestel.$sevgilitel.$baba;
$wp["539"] = $kardestel.$sevgilitel.$kardes;
$wp["540"] = $kardestel.$sevgilitel.$sevgili;
$wp["541"] = $kardestel.$sevgilitel.$sevgilisoyad;
$wp["542"] = $kardestel.$sevgilitel.$dogumtarihi;
$wp["543"] = $kardestel.$sevgilitel.$dogumyili;
$wp["544"] = $kardestel.$sevgilitel.$cikmayili;
$wp["545"] = $kardestel.$sevgilitel.$cikmatarihi;
$wp["546"] = $kardestel.$sevgilitel.$sehir;
$wp["547"] = $kardestel.$sevgilitel.$takim;
$wp["548"] = $kardestel.$sevgilitel.$takimtarihi;
$wp["549"] = $kardestel.$sevgilitel.$takimkisa;
$wp["550"] = $kardestel.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $kardestel.$tckimlikno;
$wp["552"] = $kardestel.$tckimlikno."13";
$wp["553"] = $kardestel.$tckimlikno."1905";
$wp["554"] = $kardestel.$tckimlikno."1907";
$wp["555"] = $kardestel.$tckimlikno."1903";
$wp["556"] = $kardestel.$tckimlikno."1938";
$wp["557"] = $kardestel.$tckimlikno."1919";
$wp["558"] = $kardestel.$tckimlikno."1881";
$wp["559"] = $kardestel.$tckimlikno."2018";
$wp["560"] = $kardestel.$tckimlikno."2019";
$wp["561"] = $kardestel.$tckimlikno.$lakap;
$wp["562"] = $kardestel.$tckimlikno.$anne;
$wp["563"] = $kardestel.$tckimlikno.$baba;
$wp["564"] = $kardestel.$tckimlikno.$kardes;
$wp["565"] = $kardestel.$tckimlikno.$sevgili;
$wp["566"] = $kardestel.$tckimlikno.$sevgilisoyad;
$wp["567"] = $kardestel.$tckimlikno.$dogumtarihi;
$wp["568"] = $kardestel.$tckimlikno.$dogumyili;
$wp["569"] = $kardestel.$tckimlikno.$cikmayili;
$wp["570"] = $kardestel.$tckimlikno.$cikmatarihi;
$wp["571"] = $kardestel.$tckimlikno.$sehir;
$wp["572"] = $kardestel.$tckimlikno.$takim;
$wp["573"] = $kardestel.$tckimlikno.$takimtarihi;
$wp["574"] = $kardestel.$tckimlikno.$takimkisa;
$wp["575"] = $kardestel.$tckimlikno.$plaka;





for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);


 ?>