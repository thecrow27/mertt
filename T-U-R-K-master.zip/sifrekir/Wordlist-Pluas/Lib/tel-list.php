<?php 

error_reporting(0);

include "kayit.php";





$wp["1"] = $tel;
$wp["2"] = $tel.$soyadad."123";
$wp["3"] = $tel.$soyadad."1905";
$wp["4"] = $tel.$soyadad."1907";
$wp["5"] = $tel.$soyadad."1903";
$wp["6"] = $tel.$soyadad."1938";
$wp["7"] = $tel.$soyadad."1919";
$wp["8"] = $tel.$soyadad."1881";
$wp["9"] = $tel.$soyadad."2018";
$wp["10"] = $tel.$soyadad."2019";
$wp["11"] = $tel.$soyadad.$lakap;
$wp["12"] = $tel.$soyadad.$anne;
$wp["13"] = $tel.$soyadad.$baba;
$wp["14"] = $tel.$soyadad.$kardes;
$wp["15"] = $tel.$soyadad.$sevgili;
$wp["16"] = $tel.$soyadad.$sevgilisoyad;
$wp["17"] = $tel.$soyadad.$dogumtarihi;
$wp["18"] = $tel.$soyadad.$dogumyili;
$wp["19"] = $tel.$soyadad.$cikmayili;
$wp["20"] = $tel.$soyadad.$cikmatarihi;
$wp["21"] = $tel.$soyadad.$sehir;
$wp["22"] = $tel.$soyadad.$takim;
$wp["23"] = $tel.$soyadad.$takimtarihi;
$wp["24"] = $tel.$soyadad.$takimkisa;
$wp["25"] = $tel.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $tel.$lakap;
$wp["27"] = $tel.$lakap."123";
$wp["28"] = $tel.$lakap."1905";
$wp["29"] = $tel.$lakap."1907";
$wp["30"] = $tel.$lakap."1903";
$wp["31"] = $tel.$lakap."1938";
$wp["32"] = $tel.$lakap."1919";
$wp["33"] = $tel.$lakap."1881";
$wp["34"] = $tel.$lakap."2018";
$wp["35"] = $tel.$lakap."2019";
$wp["36"] = $tel.$lakap.$lakap;
$wp["37"] = $tel.$lakap.$anne;
$wp["38"] = $tel.$lakap.$baba;
$wp["39"] = $tel.$lakap.$kardes;
$wp["40"] = $tel.$lakap.$sevgili;
$wp["41"] = $tel.$lakap.$sevgilisoyad;
$wp["42"] = $tel.$lakap.$dogumtarihi;
$wp["43"] = $tel.$lakap.$dogumyili;
$wp["44"] = $tel.$lakap.$cikmayili;
$wp["45"] = $tel.$lakap.$cikmatarihi;
$wp["46"] = $tel.$lakap.$sehir;
$wp["47"] = $tel.$lakap.$takim;
$wp["48"] = $tel.$lakap.$takimtarihi;
$wp["49"] = $tel.$lakap.$takimkisa;
$wp["50"] = $tel.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $tel.$anne;
$wp["52"] = $tel.$anne."123";
$wp["53"] = $tel.$anne."1905";
$wp["54"] = $tel.$anne."1907";
$wp["55"] = $tel.$anne."1903";
$wp["56"] = $tel.$anne."1938";
$wp["57"] = $tel.$anne."1919";
$wp["58"] = $tel.$anne."1881";
$wp["59"] = $tel.$anne."2018";
$wp["60"] = $tel.$anne."2019";
$wp["61"] = $tel.$anne.$lakap;
$wp["62"] = $tel.$anne.$anne;
$wp["63"] = $tel.$anne.$baba;
$wp["64"] = $tel.$anne.$kardes;
$wp["65"] = $tel.$anne.$sevgili;
$wp["66"] = $tel.$anne.$sevgilisoyad;
$wp["67"] = $tel.$anne.$dogumtarihi;
$wp["68"] = $tel.$anne.$dogumyili;
$wp["69"] = $tel.$anne.$cikmayili;
$wp["70"] = $tel.$anne.$cikmatarihi;
$wp["71"] = $tel.$anne.$sehir;
$wp["72"] = $tel.$anne.$takim;
$wp["73"] = $tel.$anne.$takimtarihi;
$wp["74"] = $tel.$anne.$takimkisa;
$wp["75"] = $tel.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $tel.$baba;
$wp["77"] = $tel.$baba."123";
$wp["78"] = $tel.$baba."1905";
$wp["79"] = $tel.$baba."1907";
$wp["80"] = $tel.$baba."1903";
$wp["81"] = $tel.$baba."1938";
$wp["82"] = $tel.$baba."1919";
$wp["83"] = $tel.$baba."1881";
$wp["84"] = $tel.$baba."2018";
$wp["85"] = $tel.$baba."2019";
$wp["86"] = $tel.$baba.$lakap;
$wp["87"] = $tel.$baba.$anne;
$wp["88"] = $tel.$baba.$baba;
$wp["89"] = $tel.$baba.$kardes;
$wp["90"] = $tel.$baba.$sevgili;
$wp["91"] = $tel.$baba.$sevgilisoyad;
$wp["92"] = $tel.$baba.$dogumtarihi;
$wp["93"] = $tel.$baba.$dogumyili;
$wp["94"] = $tel.$baba.$cikmayili;
$wp["95"] = $tel.$baba.$cikmatarihi;
$wp["96"] = $tel.$baba.$sehir;
$wp["97"] = $tel.$baba.$takim;
$wp["98"] = $tel.$baba.$takimtarihi;
$wp["99"] = $tel.$baba.$takimkisa;
$wp["100"] = $tel.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $tel.$kardes;
$wp["102"] = $tel.$kardes."123";
$wp["103"] = $tel.$kardes."1905";
$wp["104"] = $tel.$kardes."1907";
$wp["105"] = $tel.$kardes."1903";
$wp["106"] = $tel.$kardes."1938";
$wp["107"] = $tel.$kardes."1919";
$wp["108"] = $tel.$kardes."1881";
$wp["109"] = $tel.$kardes."2018";
$wp["110"] = $tel.$kardes."2019";
$wp["111"] = $tel.$kardes.$lakap;
$wp["112"] = $tel.$kardes.$anne;
$wp["113"] = $tel.$kardes.$baba;
$wp["114"] = $tel.$kardes.$kardes;
$wp["115"] = $tel.$kardes.$sevgili;
$wp["116"] = $tel.$kardes.$sevgilisoyad;
$wp["117"] = $tel.$kardes.$dogumtarihi;
$wp["118"] = $tel.$kardes.$dogumyili;
$wp["119"] = $tel.$kardes.$cikmayili;
$wp["120"] = $tel.$kardes.$cikmatarihi;
$wp["121"] = $tel.$kardes.$sehir;
$wp["122"] = $tel.$kardes.$takim;
$wp["123"] = $tel.$kardes.$takimtarihi;
$wp["124"] = $tel.$kardes.$takimkisa;
$wp["125"] = $tel.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $tel.$sevgili;
$wp["127"] = $tel.$sevgili."123";
$wp["128"] = $tel.$sevgili."1905";
$wp["129"] = $tel.$sevgili."1907";
$wp["130"] = $tel.$sevgili."1903";
$wp["131"] = $tel.$sevgili."1938";
$wp["132"] = $tel.$sevgili."1919";
$wp["133"] = $tel.$sevgili."1881";
$wp["134"] = $tel.$sevgili."2018";
$wp["135"] = $tel.$sevgili."2019";
$wp["136"] = $tel.$sevgili.$lakap;
$wp["137"] = $tel.$sevgili.$anne;
$wp["138"] = $tel.$sevgili.$baba;
$wp["139"] = $tel.$sevgili.$kardes;
$wp["140"] = $tel.$sevgili.$sevgili;
$wp["141"] = $tel.$sevgili.$sevgilisoyad;
$wp["142"] = $tel.$sevgili.$dogumtarihi;
$wp["143"] = $tel.$sevgili.$dogumyili;
$wp["144"] = $tel.$sevgili.$cikmayili;
$wp["145"] = $tel.$sevgili.$cikmatarihi;
$wp["146"] = $tel.$sevgili.$sehir;
$wp["147"] = $tel.$sevgili.$takim;
$wp["148"] = $tel.$sevgili.$takimtarihi;
$wp["149"] = $tel.$sevgili.$takimkisa;
$wp["150"] = $tel.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $tel.$sevgilisoyad;
$wp["152"] = $tel.$sevgilisoyad."123";
$wp["153"] = $tel.$sevgilisoyad."1905";
$wp["154"] = $tel.$sevgilisoyad."1907";
$wp["155"] = $tel.$sevgilisoyad."1903";
$wp["156"] = $tel.$sevgilisoyad."1938";
$wp["157"] = $tel.$sevgilisoyad."1919";
$wp["158"] = $tel.$sevgilisoyad."1881";
$wp["159"] = $tel.$sevgilisoyad."2018";
$wp["160"] = $tel.$sevgilisoyad."2019";
$wp["161"] = $tel.$sevgilisoyad.$lakap;
$wp["162"] = $tel.$sevgilisoyad.$anne;
$wp["163"] = $tel.$sevgilisoyad.$baba;
$wp["164"] = $tel.$sevgilisoyad.$kardes;
$wp["165"] = $tel.$sevgilisoyad.$sevgili;
$wp["166"] = $tel.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $tel.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $tel.$sevgilisoyad.$dogumyili;
$wp["169"] = $tel.$sevgilisoyad.$cikmayili;
$wp["170"] = $tel.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $tel.$sevgilisoyad.$sehir;
$wp["172"] = $tel.$sevgilisoyad.$takim;
$wp["173"] = $tel.$sevgilisoyad.$takimtarihi;
$wp["174"] = $tel.$sevgilisoyad.$takimkisa;
$wp["175"] = $tel.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $tel.$dogumtarihi;
$wp["177"] = $tel.$dogumtarihi."123";
$wp["178"] = $tel.$dogumtarihi."1905";
$wp["179"] = $tel.$dogumtarihi."1907";
$wp["180"] = $tel.$dogumtarihi."1903";
$wp["181"] = $tel.$dogumtarihi."1938";
$wp["200"] = $tel.$dogumtarihi."1919";
$wp["182"] = $tel.$dogumtarihi."1881";
$wp["183"] = $tel.$dogumtarihi."2018";
$wp["184"] = $tel.$dogumtarihi."2019";
$wp["185"] = $tel.$dogumtarihi.$lakap;
$wp["186"] = $tel.$dogumtarihi.$anne;
$wp["187"] = $tel.$dogumtarihi.$baba;
$wp["188"] = $tel.$dogumtarihi.$kardes;
$wp["189"] = $tel.$dogumtarihi.$sevgili;
$wp["190"] = $tel.$dogumtarihi.$dogumtarihi;
$wp["191"] = $tel.$dogumtarihi.$dogumtarihi;
$wp["192"] = $tel.$dogumtarihi.$dogumyili;
$wp["193"] = $tel.$dogumtarihi.$cikmayili;
$wp["194"] = $tel.$dogumtarihi.$cikmatarihi;
$wp["195"] = $tel.$dogumtarihi.$sehir;
$wp["196"] = $tel.$dogumtarihi.$takim;
$wp["197"] = $tel.$dogumtarihi.$takimtarihi;
$wp["198"] = $tel.$dogumtarihi.$takimkisa;
$wp["199"] = $tel.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $tel.$dogumyili;
$wp["202"] = $tel.$dogumyili."123";
$wp["203"] = $tel.$dogumyili."1905";
$wp["204"] = $tel.$dogumyili."1907";
$wp["205"] = $tel.$dogumyili."1903";
$wp["206"] = $tel.$dogumyili."1938";
$wp["207"] = $tel.$dogumyili."1919";
$wp["208"] = $tel.$dogumyili."1881";
$wp["209"] = $tel.$dogumyili."2018";
$wp["210"] = $tel.$dogumyili."2019";
$wp["211"] = $tel.$dogumyili.$lakap;
$wp["212"] = $tel.$dogumyili.$anne;
$wp["213"] = $tel.$dogumyili.$baba;
$wp["214"] = $tel.$dogumyili.$kardes;
$wp["215"] = $tel.$dogumyili.$sevgili;
$wp["216"] = $tel.$dogumyili.$dogumyili;
$wp["217"] = $tel.$dogumyili.$dogumyili;
$wp["218"] = $tel.$dogumyili.$dogumyili;
$wp["219"] = $tel.$dogumyili.$cikmayili;
$wp["220"] = $tel.$dogumyili.$cikmatarihi;
$wp["221"] = $tel.$dogumyili.$sehir;
$wp["222"] = $tel.$dogumyili.$takim;
$wp["223"] = $tel.$dogumyili.$takimtarihi;
$wp["224"] = $tel.$dogumyili.$takimkisa;
$wp["225"] = $tel.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $tel.$cikmayili;
$wp["227"] = $tel.$cikmayili."123";
$wp["228"] = $tel.$cikmayili."1905";
$wp["229"] = $tel.$cikmayili."1907";
$wp["230"] = $tel.$cikmayili."1903";
$wp["231"] = $tel.$cikmayili."1938";
$wp["232"] = $tel.$cikmayili."1919";
$wp["233"] = $tel.$cikmayili."1881";
$wp["234"] = $tel.$cikmayili."2018";
$wp["235"] = $tel.$cikmayili."2019";
$wp["236"] = $tel.$cikmayili.$lakap;
$wp["237"] = $tel.$cikmayili.$anne;
$wp["238"] = $tel.$cikmayili.$baba;
$wp["239"] = $tel.$cikmayili.$kardes;
$wp["240"] = $tel.$cikmayili.$sevgili;
$wp["241"] = $tel.$cikmayili.$cikmayili;
$wp["242"] = $tel.$cikmayili.$dogumyili;
$wp["243"] = $tel.$cikmayili.$cikmayili;
$wp["244"] = $tel.$cikmayili.$cikmayili;
$wp["245"] = $tel.$cikmayili.$cikmatarihi;
$wp["246"] = $tel.$cikmayili.$sehir;
$wp["247"] = $tel.$cikmayili.$takim;
$wp["248"] = $tel.$cikmayili.$takimtarihi;
$wp["249"] = $tel.$cikmayili.$takimkisa;
$wp["250"] = $tel.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $tel.$cikmatarihi;
$wp["252"] = $tel.$cikmatarihi."123";
$wp["253"] = $tel.$cikmatarihi."1905";
$wp["254"] = $tel.$cikmatarihi."1907";
$wp["255"] = $tel.$cikmatarihi."1903";
$wp["256"] = $tel.$cikmatarihi."1938";
$wp["257"] = $tel.$cikmatarihi."1919";
$wp["258"] = $tel.$cikmatarihi."1881";
$wp["259"] = $tel.$cikmatarihi."2018";
$wp["260"] = $tel.$cikmatarihi."2019";
$wp["261"] = $tel.$cikmatarihi.$lakap;
$wp["262"] = $tel.$cikmatarihi.$anne;
$wp["263"] = $tel.$cikmatarihi.$baba;
$wp["264"] = $tel.$cikmatarihi.$kardes;
$wp["265"] = $tel.$cikmatarihi.$sevgili;
$wp["267"] = $tel.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $tel.$cikmatarihi.$dogumtarihi;
$wp["269"] = $tel.$cikmatarihi.$dogumyili;
$wp["270"] = $tel.$cikmatarihi.$cikmayili;
$wp["271"] = $tel.$cikmatarihi.$cikmatarihi;
$wp["272"] = $tel.$cikmatarihi.$sehir;
$wp["273"] = $tel.$cikmatarihi.$takim;
$wp["274"] = $tel.$cikmatarihi.$takimtarihi;
$wp["275"] = $tel.$cikmatarihi.$takimkisa;
$wp["266"] = $tel.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $tel.$sehir;
$wp["277"] = $tel.$sehir."123";
$wp["278"] = $tel.$sehir."1905";
$wp["279"] = $tel.$sehir."1907";
$wp["280"] = $tel.$sehir."1903";
$wp["281"] = $tel.$sehir."1938";
$wp["282"] = $tel.$sehir."1919";
$wp["283"] = $tel.$sehir."1881";
$wp["284"] = $tel.$sehir."2018";
$wp["285"] = $tel.$sehir."2019";
$wp["286"] = $tel.$sehir.$lakap;
$wp["287"] = $tel.$sehir.$anne;
$wp["288"] = $tel.$sehir.$baba;
$wp["289"] = $tel.$sehir.$kardes;
$wp["290"] = $tel.$sehir.$sevgili;
$wp["291"] = $tel.$sehir.$sevgilisoyad;
$wp["292"] = $tel.$sehir.$dogumtarihi;
$wp["293"] = $tel.$sehir.$dogumyili;
$wp["294"] = $tel.$sehir.$cikmayili;
$wp["295"] = $tel.$sehir.$cikmatarihi;
$wp["296"] = $tel.$sehir.$sehir;
$wp["297"] = $tel.$sehir.$takim;
$wp["298"] = $tel.$sehir.$takimtarihi;
$wp["299"] = $tel.$sehir.$takimkisa;
$wp["300"] = $tel.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $tel.$takim;
$wp["302"] = $tel.$takim."123";
$wp["303"] = $tel.$takim."1905";
$wp["304"] = $tel.$takim."1907";
$wp["305"] = $tel.$takim."1903";
$wp["306"] = $tel.$takim."1938";
$wp["307"] = $tel.$takim."1919";
$wp["308"] = $tel.$takim."1881";
$wp["309"] = $tel.$takim."2018";
$wp["310"] = $tel.$takim."2019";
$wp["311"] = $tel.$takim.$lakap;
$wp["312"] = $tel.$takim.$anne;
$wp["313"] = $tel.$takim.$baba;
$wp["314"] = $tel.$takim.$kardes;
$wp["315"] = $tel.$takim.$sevgili;
$wp["316"] = $tel.$takim.$sevgilisoyad;
$wp["317"] = $tel.$takim.$dogumtarihi;
$wp["318"] = $tel.$takim.$dogumyili;
$wp["319"] = $tel.$takim.$cikmayili;
$wp["320"] = $tel.$takim.$cikmatarihi;
$wp["321"] = $tel.$takim.$sehir;
$wp["322"] = $tel.$takim.$takim;
$wp["323"] = $tel.$takim.$takimtarihi;
$wp["324"] = $tel.$takim.$takimkisa;
$wp["325"] = $tel.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $tel.$takimtarihi;
$wp["327"] = $tel.$takimtarihi."123";
$wp["328"] = $tel.$takimtarihi."1905";
$wp["329"] = $tel.$takimtarihi."1907";
$wp["330"] = $tel.$takimtarihi."1903";
$wp["331"] = $tel.$takimtarihi."1938";
$wp["332"] = $tel.$takimtarihi."1919";
$wp["333"] = $tel.$takimtarihi."1881";
$wp["334"] = $tel.$takimtarihi."2018";
$wp["335"] = $tel.$takimtarihi."2019";
$wp["336"] = $tel.$takimtarihi.$lakap;
$wp["337"] = $tel.$takimtarihi.$anne;
$wp["338"] = $tel.$takimtarihi.$baba;
$wp["339"] = $tel.$takimtarihi.$kardes;
$wp["340"] = $tel.$takimtarihi.$sevgili;
$wp["341"] = $tel.$takimtarihi.$sevgilisoyad;
$wp["342"] = $tel.$takimtarihi.$dogumtarihi;
$wp["343"] = $tel.$takimtarihi.$dogumyili;
$wp["344"] = $tel.$takimtarihi.$cikmayili;
$wp["345"] = $tel.$takimtarihi.$cikmatarihi;
$wp["346"] = $tel.$takimtarihi.$sehir;
$wp["347"] = $tel.$takimtarihi.$takim;
$wp["348"] = $tel.$takimtarihi.$takimtarihi;
$wp["349"] = $tel.$takimtarihi.$takimkisa;
$wp["350"] = $tel.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $tel.$takimkisa;
$wp["352"] = $tel.$takimkisa."123";
$wp["353"] = $tel.$takimkisa."1905";
$wp["354"] = $tel.$takimkisa."1907";
$wp["355"] = $tel.$takimkisa."1903";
$wp["356"] = $tel.$takimkisa."1938";
$wp["357"] = $tel.$takimkisa."1919";
$wp["358"] = $tel.$takimkisa."1881";
$wp["359"] = $tel.$takimkisa."2018";
$wp["360"] = $tel.$takimkisa."2019";
$wp["361"] = $tel.$takimkisa.$lakap;
$wp["362"] = $tel.$takimkisa.$anne;
$wp["363"] = $tel.$takimkisa.$baba;
$wp["364"] = $tel.$takimkisa.$kardes;
$wp["365"] = $tel.$takimkisa.$sevgili;
$wp["366"] = $tel.$takimkisa.$sevgilisoyad;
$wp["367"] = $tel.$takimkisa.$dogumtarihi;
$wp["368"] = $tel.$takimkisa.$dogumyili;
$wp["369"] = $tel.$takimkisa.$cikmayili;
$wp["370"] = $tel.$takimkisa.$cikmatarihi;
$wp["371"] = $tel.$takimkisa.$sehir;
$wp["372"] = $tel.$takimkisa.$takim;
$wp["373"] = $tel.$takimkisa.$takimtarihi;
$wp["374"] = $tel.$takimkisa.$takimkisa;
$wp["375"] = $tel.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $tel.$plaka;
$wp["377"] = $tel.$plaka."123";
$wp["378"] = $tel.$plaka."1905";
$wp["379"] = $tel.$plaka."1907";
$wp["380"] = $tel.$plaka."1903";
$wp["381"] = $tel.$plaka."1938";
$wp["382"] = $tel.$plaka."1919";
$wp["383"] = $tel.$plaka."1881";
$wp["384"] = $tel.$plaka."2018";
$wp["385"] = $tel.$plaka."2019";
$wp["386"] = $tel.$plaka.$lakap;
$wp["387"] = $tel.$plaka.$anne;
$wp["388"] = $tel.$plaka.$baba;
$wp["389"] = $tel.$plaka.$kardes;
$wp["390"] = $tel.$plaka.$sevgili;
$wp["391"] = $tel.$plaka.$sevgilisoyad;
$wp["392"] = $tel.$plaka.$dogumtarihi;
$wp["393"] = $tel.$plaka.$dogumyili;
$wp["394"] = $tel.$plaka.$cikmayili;
$wp["395"] = $tel.$plaka.$cikmatarihi;
$wp["396"] = $tel.$plaka.$sehir;
$wp["397"] = $tel.$plaka.$takim;
$wp["398"] = $tel.$plaka.$takimtarihi;
$wp["399"] = $tel.$plaka.$takimkisa;
$wp["400"] = $tel.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $tel.$eskisifre;
$wp["402"] = $tel.$eskisifre."123";
$wp["403"] = $tel.$eskisifre."1905";
$wp["404"] = $tel.$eskisifre."1907";
$wp["405"] = $tel.$eskisifre."1903";
$wp["406"] = $tel.$eskisifre."1938";
$wp["407"] = $tel.$eskisifre."1919";
$wp["408"] = $tel.$eskisifre."1881";
$wp["409"] = $tel.$eskisifre."2018";
$wp["410"] = $tel.$eskisifre."2019";
$wp["411"] = $tel.$eskisifre.$lakap;
$wp["412"] = $tel.$eskisifre.$anne;
$wp["413"] = $tel.$eskisifre.$baba;
$wp["414"] = $tel.$eskisifre.$kardes;
$wp["415"] = $tel.$eskisifre.$sevgili;
$wp["416"] = $tel.$eskisifre.$sevgilisoyad;
$wp["417"] = $tel.$eskisifre.$dogumtarihi;
$wp["418"] = $tel.$eskisifre.$dogumyili;
$wp["419"] = $tel.$eskisifre.$cikmayili;
$wp["420"] = $tel.$eskisifre.$cikmatarihi;
$wp["421"] = $tel.$eskisifre.$sehir;
$wp["422"] = $tel.$eskisifre.$takim;
$wp["423"] = $tel.$eskisifre.$takimtarihi;
$wp["424"] = $tel.$eskisifre.$takimkisa;
$wp["425"] = $tel.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $tel.$tel;
$wp["427"] = $tel.$tel."123";
$wp["428"] = $tel.$tel."1905";
$wp["429"] = $tel.$tel."1907";
$wp["430"] = $tel.$tel."1903";
$wp["431"] = $tel.$tel."1938";
$wp["432"] = $tel.$tel."1919";
$wp["433"] = $tel.$tel."1881";
$wp["434"] = $tel.$tel."2018";
$wp["435"] = $tel.$tel."2019";
$wp["436"] = $tel.$tel.$lakap;
$wp["437"] = $tel.$tel.$anne;
$wp["438"] = $tel.$tel.$baba;
$wp["439"] = $tel.$tel.$kardes;
$wp["440"] = $tel.$tel.$sevgili;
$wp["441"] = $tel.$tel.$sevgilisoyad;
$wp["442"] = $tel.$tel.$dogumtarihi;
$wp["443"] = $tel.$tel.$dogumyili;
$wp["444"] = $tel.$tel.$cikmayili;
$wp["445"] = $tel.$tel.$cikmatarihi;
$wp["446"] = $tel.$tel.$sehir;
$wp["447"] = $tel.$tel.$takim;
$wp["448"] = $tel.$tel.$takimtarihi;
$wp["449"] = $tel.$tel.$takimkisa;
$wp["450"] = $tel.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $tel.$annetel;
$wp["452"] = $tel.$annetel."123";
$wp["453"] = $tel.$annetel."1905";
$wp["454"] = $tel.$annetel."1907";
$wp["455"] = $tel.$annetel."1903";
$wp["456"] = $tel.$annetel."1938";
$wp["457"] = $tel.$annetel."1919";
$wp["458"] = $tel.$annetel."1881";
$wp["459"] = $tel.$annetel."2018";
$wp["460"] = $tel.$annetel."2019";
$wp["461"] = $tel.$annetel.$lakap;
$wp["462"] = $tel.$annetel.$anne;
$wp["463"] = $tel.$annetel.$baba;
$wp["464"] = $tel.$annetel.$kardes;
$wp["465"] = $tel.$annetel.$sevgili;
$wp["466"] = $tel.$annetel.$sevgilisoyad;
$wp["467"] = $tel.$annetel.$dogumtarihi;
$wp["468"] = $tel.$annetel.$dogumyili;
$wp["469"] = $tel.$annetel.$cikmayili;
$wp["470"] = $tel.$annetel.$cikmatarihi;
$wp["471"] = $tel.$annetel.$sehir;
$wp["472"] = $tel.$annetel.$takim;
$wp["473"] = $tel.$annetel.$takimtarihi;
$wp["474"] = $tel.$annetel.$takimkisa;
$wp["475"] = $tel.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $tel.$babatel;
$wp["477"] = $tel.$babatel."123";
$wp["478"] = $tel.$babatel."1905";
$wp["479"] = $tel.$babatel."1907";
$wp["480"] = $tel.$babatel."1903";
$wp["481"] = $tel.$babatel."1938";
$wp["482"] = $tel.$babatel."1919";
$wp["483"] = $tel.$babatel."1881";
$wp["484"] = $tel.$babatel."2018";
$wp["485"] = $tel.$babatel."2019";
$wp["486"] = $tel.$babatel.$lakap;
$wp["487"] = $tel.$babatel.$anne;
$wp["488"] = $tel.$babatel.$baba;
$wp["489"] = $tel.$babatel.$kardes;
$wp["490"] = $tel.$babatel.$sevgili;
$wp["491"] = $tel.$babatel.$sevgilisoyad;
$wp["492"] = $tel.$babatel.$dogumtarihi;
$wp["493"] = $tel.$babatel.$dogumyili;
$wp["494"] = $tel.$babatel.$cikmayili;
$wp["495"] = $tel.$babatel.$cikmatarihi;
$wp["496"] = $tel.$babatel.$sehir;
$wp["497"] = $tel.$babatel.$takim;
$wp["498"] = $tel.$babatel.$takimtarihi;
$wp["499"] = $tel.$babatel.$takimkisa;
$wp["500"] = $tel.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $tel.$kardestel;
$wp["502"] = $tel.$kardestel."123";
$wp["503"] = $tel.$kardestel."1905";
$wp["504"] = $tel.$kardestel."1907";
$wp["505"] = $tel.$kardestel."1903";
$wp["506"] = $tel.$kardestel."1938";
$wp["507"] = $tel.$kardestel."1919";
$wp["508"] = $tel.$kardestel."1881";
$wp["509"] = $tel.$kardestel."2018";
$wp["510"] = $tel.$kardestel."2019";
$wp["511"] = $tel.$kardestel.$lakap;
$wp["512"] = $tel.$kardestel.$anne;
$wp["513"] = $tel.$kardestel.$baba;
$wp["514"] = $tel.$kardestel.$kardes;
$wp["515"] = $tel.$kardestel.$sevgili;
$wp["516"] = $tel.$kardestel.$sevgilisoyad;
$wp["517"] = $tel.$kardestel.$dogumtarihi;
$wp["518"] = $tel.$kardestel.$dogumyili;
$wp["519"] = $tel.$kardestel.$cikmayili;
$wp["520"] = $tel.$kardestel.$cikmatarihi;
$wp["521"] = $tel.$kardestel.$sehir;
$wp["522"] = $tel.$kardestel.$takim;
$wp["523"] = $tel.$kardestel.$takimtarihi;
$wp["524"] = $tel.$kardestel.$takimkisa;
$wp["525"] = $tel.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $tel.$sevgilitel;
$wp["527"] = $tel.$sevgilitel."123";
$wp["528"] = $tel.$sevgilitel."1905";
$wp["529"] = $tel.$sevgilitel."1907";
$wp["530"] = $tel.$sevgilitel."1903";
$wp["531"] = $tel.$sevgilitel."1938";
$wp["532"] = $tel.$sevgilitel."1919";
$wp["533"] = $tel.$sevgilitel."1881";
$wp["534"] = $tel.$sevgilitel."2018";
$wp["535"] = $tel.$sevgilitel."2019";
$wp["536"] = $tel.$sevgilitel.$lakap;
$wp["537"] = $tel.$sevgilitel.$anne;
$wp["538"] = $tel.$sevgilitel.$baba;
$wp["539"] = $tel.$sevgilitel.$kardes;
$wp["540"] = $tel.$sevgilitel.$sevgili;
$wp["541"] = $tel.$sevgilitel.$sevgilisoyad;
$wp["542"] = $tel.$sevgilitel.$dogumtarihi;
$wp["543"] = $tel.$sevgilitel.$dogumyili;
$wp["544"] = $tel.$sevgilitel.$cikmayili;
$wp["545"] = $tel.$sevgilitel.$cikmatarihi;
$wp["546"] = $tel.$sevgilitel.$sehir;
$wp["547"] = $tel.$sevgilitel.$takim;
$wp["548"] = $tel.$sevgilitel.$takimtarihi;
$wp["549"] = $tel.$sevgilitel.$takimkisa;
$wp["550"] = $tel.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $tel.$tckimlikno;
$wp["552"] = $tel.$tckimlikno."13";
$wp["553"] = $tel.$tckimlikno."1905";
$wp["554"] = $tel.$tckimlikno."1907";
$wp["555"] = $tel.$tckimlikno."1903";
$wp["556"] = $tel.$tckimlikno."1938";
$wp["557"] = $tel.$tckimlikno."1919";
$wp["558"] = $tel.$tckimlikno."1881";
$wp["559"] = $tel.$tckimlikno."2018";
$wp["560"] = $tel.$tckimlikno."2019";
$wp["561"] = $tel.$tckimlikno.$lakap;
$wp["562"] = $tel.$tckimlikno.$anne;
$wp["563"] = $tel.$tckimlikno.$baba;
$wp["564"] = $tel.$tckimlikno.$kardes;
$wp["565"] = $tel.$tckimlikno.$sevgili;
$wp["566"] = $tel.$tckimlikno.$sevgilisoyad;
$wp["567"] = $tel.$tckimlikno.$dogumtarihi;
$wp["568"] = $tel.$tckimlikno.$dogumyili;
$wp["569"] = $tel.$tckimlikno.$cikmayili;
$wp["570"] = $tel.$tckimlikno.$cikmatarihi;
$wp["571"] = $tel.$tckimlikno.$sehir;
$wp["572"] = $tel.$tckimlikno.$takim;
$wp["573"] = $tel.$tckimlikno.$takimtarihi;
$wp["574"] = $tel.$tckimlikno.$takimkisa;
$wp["575"] = $tel.$tckimlikno.$plaka;




for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);


 ?>