<?php 

error_reporting(0);

include "kayit.php";



$wp["1"] = $dogumyili;
$wp["2"] = $dogumyili.$soyadad."123";
$wp["3"] = $dogumyili.$soyadad."1905";
$wp["4"] = $dogumyili.$soyadad."1907";
$wp["5"] = $dogumyili.$soyadad."1903";
$wp["6"] = $dogumyili.$soyadad."1938";
$wp["7"] = $dogumyili.$soyadad."1919";
$wp["8"] = $dogumyili.$soyadad."1881";
$wp["9"] = $dogumyili.$soyadad."2018";
$wp["10"] = $dogumyili.$soyadad."2019";
$wp["11"] = $dogumyili.$soyadad.$lakap;
$wp["12"] = $dogumyili.$soyadad.$anne;
$wp["13"] = $dogumyili.$soyadad.$baba;
$wp["14"] = $dogumyili.$soyadad.$kardes;
$wp["15"] = $dogumyili.$soyadad.$sevgili;
$wp["16"] = $dogumyili.$soyadad.$sevgilisoyad;
$wp["17"] = $dogumyili.$soyadad.$dogumtarihi;
$wp["18"] = $dogumyili.$soyadad.$dogumyili;
$wp["19"] = $dogumyili.$soyadad.$cikmayili;
$wp["20"] = $dogumyili.$soyadad.$cikmatarihi;
$wp["21"] = $dogumyili.$soyadad.$sehir;
$wp["22"] = $dogumyili.$soyadad.$takim;
$wp["23"] = $dogumyili.$soyadad.$takimtarihi;
$wp["24"] = $dogumyili.$soyadad.$takimkisa;
$wp["25"] = $dogumyili.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $dogumyili.$lakap;
$wp["27"] = $dogumyili.$lakap."123";
$wp["28"] = $dogumyili.$lakap."1905";
$wp["29"] = $dogumyili.$lakap."1907";
$wp["30"] = $dogumyili.$lakap."1903";
$wp["31"] = $dogumyili.$lakap."1938";
$wp["32"] = $dogumyili.$lakap."1919";
$wp["33"] = $dogumyili.$lakap."1881";
$wp["34"] = $dogumyili.$lakap."2018";
$wp["35"] = $dogumyili.$lakap."2019";
$wp["36"] = $dogumyili.$lakap.$lakap;
$wp["37"] = $dogumyili.$lakap.$anne;
$wp["38"] = $dogumyili.$lakap.$baba;
$wp["39"] = $dogumyili.$lakap.$kardes;
$wp["40"] = $dogumyili.$lakap.$sevgili;
$wp["41"] = $dogumyili.$lakap.$sevgilisoyad;
$wp["42"] = $dogumyili.$lakap.$dogumtarihi;
$wp["43"] = $dogumyili.$lakap.$dogumyili;
$wp["44"] = $dogumyili.$lakap.$cikmayili;
$wp["45"] = $dogumyili.$lakap.$cikmatarihi;
$wp["46"] = $dogumyili.$lakap.$sehir;
$wp["47"] = $dogumyili.$lakap.$takim;
$wp["48"] = $dogumyili.$lakap.$takimtarihi;
$wp["49"] = $dogumyili.$lakap.$takimkisa;
$wp["50"] = $dogumyili.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $dogumyili.$anne;
$wp["52"] = $dogumyili.$anne."123";
$wp["53"] = $dogumyili.$anne."1905";
$wp["54"] = $dogumyili.$anne."1907";
$wp["55"] = $dogumyili.$anne."1903";
$wp["56"] = $dogumyili.$anne."1938";
$wp["57"] = $dogumyili.$anne."1919";
$wp["58"] = $dogumyili.$anne."1881";
$wp["59"] = $dogumyili.$anne."2018";
$wp["60"] = $dogumyili.$anne."2019";
$wp["61"] = $dogumyili.$anne.$lakap;
$wp["62"] = $dogumyili.$anne.$anne;
$wp["63"] = $dogumyili.$anne.$baba;
$wp["64"] = $dogumyili.$anne.$kardes;
$wp["65"] = $dogumyili.$anne.$sevgili;
$wp["66"] = $dogumyili.$anne.$sevgilisoyad;
$wp["67"] = $dogumyili.$anne.$dogumtarihi;
$wp["68"] = $dogumyili.$anne.$dogumyili;
$wp["69"] = $dogumyili.$anne.$cikmayili;
$wp["70"] = $dogumyili.$anne.$cikmatarihi;
$wp["71"] = $dogumyili.$anne.$sehir;
$wp["72"] = $dogumyili.$anne.$takim;
$wp["73"] = $dogumyili.$anne.$takimtarihi;
$wp["74"] = $dogumyili.$anne.$takimkisa;
$wp["75"] = $dogumyili.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $dogumyili.$baba;
$wp["77"] = $dogumyili.$baba."123";
$wp["78"] = $dogumyili.$baba."1905";
$wp["79"] = $dogumyili.$baba."1907";
$wp["80"] = $dogumyili.$baba."1903";
$wp["81"] = $dogumyili.$baba."1938";
$wp["82"] = $dogumyili.$baba."1919";
$wp["83"] = $dogumyili.$baba."1881";
$wp["84"] = $dogumyili.$baba."2018";
$wp["85"] = $dogumyili.$baba."2019";
$wp["86"] = $dogumyili.$baba.$lakap;
$wp["87"] = $dogumyili.$baba.$anne;
$wp["88"] = $dogumyili.$baba.$baba;
$wp["89"] = $dogumyili.$baba.$kardes;
$wp["90"] = $dogumyili.$baba.$sevgili;
$wp["91"] = $dogumyili.$baba.$sevgilisoyad;
$wp["92"] = $dogumyili.$baba.$dogumtarihi;
$wp["93"] = $dogumyili.$baba.$dogumyili;
$wp["94"] = $dogumyili.$baba.$cikmayili;
$wp["95"] = $dogumyili.$baba.$cikmatarihi;
$wp["96"] = $dogumyili.$baba.$sehir;
$wp["97"] = $dogumyili.$baba.$takim;
$wp["98"] = $dogumyili.$baba.$takimtarihi;
$wp["99"] = $dogumyili.$baba.$takimkisa;
$wp["100"] = $dogumyili.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $dogumyili.$kardes;
$wp["102"] = $dogumyili.$kardes."123";
$wp["103"] = $dogumyili.$kardes."1905";
$wp["104"] = $dogumyili.$kardes."1907";
$wp["105"] = $dogumyili.$kardes."1903";
$wp["106"] = $dogumyili.$kardes."1938";
$wp["107"] = $dogumyili.$kardes."1919";
$wp["108"] = $dogumyili.$kardes."1881";
$wp["109"] = $dogumyili.$kardes."2018";
$wp["110"] = $dogumyili.$kardes."2019";
$wp["111"] = $dogumyili.$kardes.$lakap;
$wp["112"] = $dogumyili.$kardes.$anne;
$wp["113"] = $dogumyili.$kardes.$baba;
$wp["114"] = $dogumyili.$kardes.$kardes;
$wp["115"] = $dogumyili.$kardes.$sevgili;
$wp["116"] = $dogumyili.$kardes.$sevgilisoyad;
$wp["117"] = $dogumyili.$kardes.$dogumtarihi;
$wp["118"] = $dogumyili.$kardes.$dogumyili;
$wp["119"] = $dogumyili.$kardes.$cikmayili;
$wp["120"] = $dogumyili.$kardes.$cikmatarihi;
$wp["121"] = $dogumyili.$kardes.$sehir;
$wp["122"] = $dogumyili.$kardes.$takim;
$wp["123"] = $dogumyili.$kardes.$takimtarihi;
$wp["124"] = $dogumyili.$kardes.$takimkisa;
$wp["125"] = $dogumyili.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $dogumyili.$sevgili;
$wp["127"] = $dogumyili.$sevgili."123";
$wp["128"] = $dogumyili.$sevgili."1905";
$wp["129"] = $dogumyili.$sevgili."1907";
$wp["130"] = $dogumyili.$sevgili."1903";
$wp["131"] = $dogumyili.$sevgili."1938";
$wp["132"] = $dogumyili.$sevgili."1919";
$wp["133"] = $dogumyili.$sevgili."1881";
$wp["134"] = $dogumyili.$sevgili."2018";
$wp["135"] = $dogumyili.$sevgili."2019";
$wp["136"] = $dogumyili.$sevgili.$lakap;
$wp["137"] = $dogumyili.$sevgili.$anne;
$wp["138"] = $dogumyili.$sevgili.$baba;
$wp["139"] = $dogumyili.$sevgili.$kardes;
$wp["140"] = $dogumyili.$sevgili.$sevgili;
$wp["141"] = $dogumyili.$sevgili.$sevgilisoyad;
$wp["142"] = $dogumyili.$sevgili.$dogumtarihi;
$wp["143"] = $dogumyili.$sevgili.$dogumyili;
$wp["144"] = $dogumyili.$sevgili.$cikmayili;
$wp["145"] = $dogumyili.$sevgili.$cikmatarihi;
$wp["146"] = $dogumyili.$sevgili.$sehir;
$wp["147"] = $dogumyili.$sevgili.$takim;
$wp["148"] = $dogumyili.$sevgili.$takimtarihi;
$wp["149"] = $dogumyili.$sevgili.$takimkisa;
$wp["150"] = $dogumyili.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $dogumyili.$sevgilisoyad;
$wp["152"] = $dogumyili.$sevgilisoyad."123";
$wp["153"] = $dogumyili.$sevgilisoyad."1905";
$wp["154"] = $dogumyili.$sevgilisoyad."1907";
$wp["155"] = $dogumyili.$sevgilisoyad."1903";
$wp["156"] = $dogumyili.$sevgilisoyad."1938";
$wp["157"] = $dogumyili.$sevgilisoyad."1919";
$wp["158"] = $dogumyili.$sevgilisoyad."1881";
$wp["159"] = $dogumyili.$sevgilisoyad."2018";
$wp["160"] = $dogumyili.$sevgilisoyad."2019";
$wp["161"] = $dogumyili.$sevgilisoyad.$lakap;
$wp["162"] = $dogumyili.$sevgilisoyad.$anne;
$wp["163"] = $dogumyili.$sevgilisoyad.$baba;
$wp["164"] = $dogumyili.$sevgilisoyad.$kardes;
$wp["165"] = $dogumyili.$sevgilisoyad.$sevgili;
$wp["166"] = $dogumyili.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $dogumyili.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $dogumyili.$sevgilisoyad.$dogumyili;
$wp["169"] = $dogumyili.$sevgilisoyad.$cikmayili;
$wp["170"] = $dogumyili.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $dogumyili.$sevgilisoyad.$sehir;
$wp["172"] = $dogumyili.$sevgilisoyad.$takim;
$wp["173"] = $dogumyili.$sevgilisoyad.$takimtarihi;
$wp["174"] = $dogumyili.$sevgilisoyad.$takimkisa;
$wp["175"] = $dogumyili.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $dogumyili.$dogumtarihi;
$wp["177"] = $dogumyili.$dogumtarihi."123";
$wp["178"] = $dogumyili.$dogumtarihi."1905";
$wp["179"] = $dogumyili.$dogumtarihi."1907";
$wp["180"] = $dogumyili.$dogumtarihi."1903";
$wp["181"] = $dogumyili.$dogumtarihi."1938";
$wp["200"] = $dogumyili.$dogumtarihi."1919";
$wp["182"] = $dogumyili.$dogumtarihi."1881";
$wp["183"] = $dogumyili.$dogumtarihi."2018";
$wp["184"] = $dogumyili.$dogumtarihi."2019";
$wp["185"] = $dogumyili.$dogumtarihi.$lakap;
$wp["186"] = $dogumyili.$dogumtarihi.$anne;
$wp["187"] = $dogumyili.$dogumtarihi.$baba;
$wp["188"] = $dogumyili.$dogumtarihi.$kardes;
$wp["189"] = $dogumyili.$dogumtarihi.$sevgili;
$wp["190"] = $dogumyili.$dogumtarihi.$dogumtarihi;
$wp["191"] = $dogumyili.$dogumtarihi.$dogumtarihi;
$wp["192"] = $dogumyili.$dogumtarihi.$dogumyili;
$wp["193"] = $dogumyili.$dogumtarihi.$cikmayili;
$wp["194"] = $dogumyili.$dogumtarihi.$cikmatarihi;
$wp["195"] = $dogumyili.$dogumtarihi.$sehir;
$wp["196"] = $dogumyili.$dogumtarihi.$takim;
$wp["197"] = $dogumyili.$dogumtarihi.$takimtarihi;
$wp["198"] = $dogumyili.$dogumtarihi.$takimkisa;
$wp["199"] = $dogumyili.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $dogumyili.$dogumyili;
$wp["202"] = $dogumyili.$dogumyili."123";
$wp["203"] = $dogumyili.$dogumyili."1905";
$wp["204"] = $dogumyili.$dogumyili."1907";
$wp["205"] = $dogumyili.$dogumyili."1903";
$wp["206"] = $dogumyili.$dogumyili."1938";
$wp["207"] = $dogumyili.$dogumyili."1919";
$wp["208"] = $dogumyili.$dogumyili."1881";
$wp["209"] = $dogumyili.$dogumyili."2018";
$wp["210"] = $dogumyili.$dogumyili."2019";
$wp["211"] = $dogumyili.$dogumyili.$lakap;
$wp["212"] = $dogumyili.$dogumyili.$anne;
$wp["213"] = $dogumyili.$dogumyili.$baba;
$wp["214"] = $dogumyili.$dogumyili.$kardes;
$wp["215"] = $dogumyili.$dogumyili.$sevgili;
$wp["216"] = $dogumyili.$dogumyili.$dogumyili;
$wp["217"] = $dogumyili.$dogumyili.$dogumyili;
$wp["218"] = $dogumyili.$dogumyili.$dogumyili;
$wp["219"] = $dogumyili.$dogumyili.$cikmayili;
$wp["220"] = $dogumyili.$dogumyili.$cikmatarihi;
$wp["221"] = $dogumyili.$dogumyili.$sehir;
$wp["222"] = $dogumyili.$dogumyili.$takim;
$wp["223"] = $dogumyili.$dogumyili.$takimtarihi;
$wp["224"] = $dogumyili.$dogumyili.$takimkisa;
$wp["225"] = $dogumyili.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $dogumyili.$cikmayili;
$wp["227"] = $dogumyili.$cikmayili."123";
$wp["228"] = $dogumyili.$cikmayili."1905";
$wp["229"] = $dogumyili.$cikmayili."1907";
$wp["230"] = $dogumyili.$cikmayili."1903";
$wp["231"] = $dogumyili.$cikmayili."1938";
$wp["232"] = $dogumyili.$cikmayili."1919";
$wp["233"] = $dogumyili.$cikmayili."1881";
$wp["234"] = $dogumyili.$cikmayili."2018";
$wp["235"] = $dogumyili.$cikmayili."2019";
$wp["236"] = $dogumyili.$cikmayili.$lakap;
$wp["237"] = $dogumyili.$cikmayili.$anne;
$wp["238"] = $dogumyili.$cikmayili.$baba;
$wp["239"] = $dogumyili.$cikmayili.$kardes;
$wp["240"] = $dogumyili.$cikmayili.$sevgili;
$wp["241"] = $dogumyili.$cikmayili.$cikmayili;
$wp["242"] = $dogumyili.$cikmayili.$dogumyili;
$wp["243"] = $dogumyili.$cikmayili.$cikmayili;
$wp["244"] = $dogumyili.$cikmayili.$cikmayili;
$wp["245"] = $dogumyili.$cikmayili.$cikmatarihi;
$wp["246"] = $dogumyili.$cikmayili.$sehir;
$wp["247"] = $dogumyili.$cikmayili.$takim;
$wp["248"] = $dogumyili.$cikmayili.$takimtarihi;
$wp["249"] = $dogumyili.$cikmayili.$takimkisa;
$wp["250"] = $dogumyili.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $dogumyili.$cikmatarihi;
$wp["252"] = $dogumyili.$cikmatarihi."123";
$wp["253"] = $dogumyili.$cikmatarihi."1905";
$wp["254"] = $dogumyili.$cikmatarihi."1907";
$wp["255"] = $dogumyili.$cikmatarihi."1903";
$wp["256"] = $dogumyili.$cikmatarihi."1938";
$wp["257"] = $dogumyili.$cikmatarihi."1919";
$wp["258"] = $dogumyili.$cikmatarihi."1881";
$wp["259"] = $dogumyili.$cikmatarihi."2018";
$wp["260"] = $dogumyili.$cikmatarihi."2019";
$wp["261"] = $dogumyili.$cikmatarihi.$lakap;
$wp["262"] = $dogumyili.$cikmatarihi.$anne;
$wp["263"] = $dogumyili.$cikmatarihi.$baba;
$wp["264"] = $dogumyili.$cikmatarihi.$kardes;
$wp["265"] = $dogumyili.$cikmatarihi.$sevgili;
$wp["267"] = $dogumyili.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $dogumyili.$cikmatarihi.$dogumtarihi;
$wp["269"] = $dogumyili.$cikmatarihi.$dogumyili;
$wp["270"] = $dogumyili.$cikmatarihi.$cikmayili;
$wp["271"] = $dogumyili.$cikmatarihi.$cikmatarihi;
$wp["272"] = $dogumyili.$cikmatarihi.$sehir;
$wp["273"] = $dogumyili.$cikmatarihi.$takim;
$wp["274"] = $dogumyili.$cikmatarihi.$takimtarihi;
$wp["275"] = $dogumyili.$cikmatarihi.$takimkisa;
$wp["266"] = $dogumyili.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $dogumyili.$sehir;
$wp["277"] = $dogumyili.$sehir."123";
$wp["278"] = $dogumyili.$sehir."1905";
$wp["279"] = $dogumyili.$sehir."1907";
$wp["280"] = $dogumyili.$sehir."1903";
$wp["281"] = $dogumyili.$sehir."1938";
$wp["282"] = $dogumyili.$sehir."1919";
$wp["283"] = $dogumyili.$sehir."1881";
$wp["284"] = $dogumyili.$sehir."2018";
$wp["285"] = $dogumyili.$sehir."2019";
$wp["286"] = $dogumyili.$sehir.$lakap;
$wp["287"] = $dogumyili.$sehir.$anne;
$wp["288"] = $dogumyili.$sehir.$baba;
$wp["289"] = $dogumyili.$sehir.$kardes;
$wp["290"] = $dogumyili.$sehir.$sevgili;
$wp["291"] = $dogumyili.$sehir.$sevgilisoyad;
$wp["292"] = $dogumyili.$sehir.$dogumtarihi;
$wp["293"] = $dogumyili.$sehir.$dogumyili;
$wp["294"] = $dogumyili.$sehir.$cikmayili;
$wp["295"] = $dogumyili.$sehir.$cikmatarihi;
$wp["296"] = $dogumyili.$sehir.$sehir;
$wp["297"] = $dogumyili.$sehir.$takim;
$wp["298"] = $dogumyili.$sehir.$takimtarihi;
$wp["299"] = $dogumyili.$sehir.$takimkisa;
$wp["300"] = $dogumyili.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $dogumyili.$takim;
$wp["302"] = $dogumyili.$takim."123";
$wp["303"] = $dogumyili.$takim."1905";
$wp["304"] = $dogumyili.$takim."1907";
$wp["305"] = $dogumyili.$takim."1903";
$wp["306"] = $dogumyili.$takim."1938";
$wp["307"] = $dogumyili.$takim."1919";
$wp["308"] = $dogumyili.$takim."1881";
$wp["309"] = $dogumyili.$takim."2018";
$wp["310"] = $dogumyili.$takim."2019";
$wp["311"] = $dogumyili.$takim.$lakap;
$wp["312"] = $dogumyili.$takim.$anne;
$wp["313"] = $dogumyili.$takim.$baba;
$wp["314"] = $dogumyili.$takim.$kardes;
$wp["315"] = $dogumyili.$takim.$sevgili;
$wp["316"] = $dogumyili.$takim.$sevgilisoyad;
$wp["317"] = $dogumyili.$takim.$dogumtarihi;
$wp["318"] = $dogumyili.$takim.$dogumyili;
$wp["319"] = $dogumyili.$takim.$cikmayili;
$wp["320"] = $dogumyili.$takim.$cikmatarihi;
$wp["321"] = $dogumyili.$takim.$sehir;
$wp["322"] = $dogumyili.$takim.$takim;
$wp["323"] = $dogumyili.$takim.$takimtarihi;
$wp["324"] = $dogumyili.$takim.$takimkisa;
$wp["325"] = $dogumyili.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $dogumyili.$takimtarihi;
$wp["327"] = $dogumyili.$takimtarihi."123";
$wp["328"] = $dogumyili.$takimtarihi."1905";
$wp["329"] = $dogumyili.$takimtarihi."1907";
$wp["330"] = $dogumyili.$takimtarihi."1903";
$wp["331"] = $dogumyili.$takimtarihi."1938";
$wp["332"] = $dogumyili.$takimtarihi."1919";
$wp["333"] = $dogumyili.$takimtarihi."1881";
$wp["334"] = $dogumyili.$takimtarihi."2018";
$wp["335"] = $dogumyili.$takimtarihi."2019";
$wp["336"] = $dogumyili.$takimtarihi.$lakap;
$wp["337"] = $dogumyili.$takimtarihi.$anne;
$wp["338"] = $dogumyili.$takimtarihi.$baba;
$wp["339"] = $dogumyili.$takimtarihi.$kardes;
$wp["340"] = $dogumyili.$takimtarihi.$sevgili;
$wp["341"] = $dogumyili.$takimtarihi.$sevgilisoyad;
$wp["342"] = $dogumyili.$takimtarihi.$dogumtarihi;
$wp["343"] = $dogumyili.$takimtarihi.$dogumyili;
$wp["344"] = $dogumyili.$takimtarihi.$cikmayili;
$wp["345"] = $dogumyili.$takimtarihi.$cikmatarihi;
$wp["346"] = $dogumyili.$takimtarihi.$sehir;
$wp["347"] = $dogumyili.$takimtarihi.$takim;
$wp["348"] = $dogumyili.$takimtarihi.$takimtarihi;
$wp["349"] = $dogumyili.$takimtarihi.$takimkisa;
$wp["350"] = $dogumyili.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $dogumyili.$takimkisa;
$wp["352"] = $dogumyili.$takimkisa."123";
$wp["353"] = $dogumyili.$takimkisa."1905";
$wp["354"] = $dogumyili.$takimkisa."1907";
$wp["355"] = $dogumyili.$takimkisa."1903";
$wp["356"] = $dogumyili.$takimkisa."1938";
$wp["357"] = $dogumyili.$takimkisa."1919";
$wp["358"] = $dogumyili.$takimkisa."1881";
$wp["359"] = $dogumyili.$takimkisa."2018";
$wp["360"] = $dogumyili.$takimkisa."2019";
$wp["361"] = $dogumyili.$takimkisa.$lakap;
$wp["362"] = $dogumyili.$takimkisa.$anne;
$wp["363"] = $dogumyili.$takimkisa.$baba;
$wp["364"] = $dogumyili.$takimkisa.$kardes;
$wp["365"] = $dogumyili.$takimkisa.$sevgili;
$wp["366"] = $dogumyili.$takimkisa.$sevgilisoyad;
$wp["367"] = $dogumyili.$takimkisa.$dogumtarihi;
$wp["368"] = $dogumyili.$takimkisa.$dogumyili;
$wp["369"] = $dogumyili.$takimkisa.$cikmayili;
$wp["370"] = $dogumyili.$takimkisa.$cikmatarihi;
$wp["371"] = $dogumyili.$takimkisa.$sehir;
$wp["372"] = $dogumyili.$takimkisa.$takim;
$wp["373"] = $dogumyili.$takimkisa.$takimtarihi;
$wp["374"] = $dogumyili.$takimkisa.$takimkisa;
$wp["375"] = $dogumyili.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $dogumyili.$plaka;
$wp["377"] = $dogumyili.$plaka."123";
$wp["378"] = $dogumyili.$plaka."1905";
$wp["379"] = $dogumyili.$plaka."1907";
$wp["380"] = $dogumyili.$plaka."1903";
$wp["381"] = $dogumyili.$plaka."1938";
$wp["382"] = $dogumyili.$plaka."1919";
$wp["383"] = $dogumyili.$plaka."1881";
$wp["384"] = $dogumyili.$plaka."2018";
$wp["385"] = $dogumyili.$plaka."2019";
$wp["386"] = $dogumyili.$plaka.$lakap;
$wp["387"] = $dogumyili.$plaka.$anne;
$wp["388"] = $dogumyili.$plaka.$baba;
$wp["389"] = $dogumyili.$plaka.$kardes;
$wp["390"] = $dogumyili.$plaka.$sevgili;
$wp["391"] = $dogumyili.$plaka.$sevgilisoyad;
$wp["392"] = $dogumyili.$plaka.$dogumtarihi;
$wp["393"] = $dogumyili.$plaka.$dogumyili;
$wp["394"] = $dogumyili.$plaka.$cikmayili;
$wp["395"] = $dogumyili.$plaka.$cikmatarihi;
$wp["396"] = $dogumyili.$plaka.$sehir;
$wp["397"] = $dogumyili.$plaka.$takim;
$wp["398"] = $dogumyili.$plaka.$takimtarihi;
$wp["399"] = $dogumyili.$plaka.$takimkisa;
$wp["400"] = $dogumyili.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $dogumyili.$eskisifre;
$wp["402"] = $dogumyili.$eskisifre."123";
$wp["403"] = $dogumyili.$eskisifre."1905";
$wp["404"] = $dogumyili.$eskisifre."1907";
$wp["405"] = $dogumyili.$eskisifre."1903";
$wp["406"] = $dogumyili.$eskisifre."1938";
$wp["407"] = $dogumyili.$eskisifre."1919";
$wp["408"] = $dogumyili.$eskisifre."1881";
$wp["409"] = $dogumyili.$eskisifre."2018";
$wp["410"] = $dogumyili.$eskisifre."2019";
$wp["411"] = $dogumyili.$eskisifre.$lakap;
$wp["412"] = $dogumyili.$eskisifre.$anne;
$wp["413"] = $dogumyili.$eskisifre.$baba;
$wp["414"] = $dogumyili.$eskisifre.$kardes;
$wp["415"] = $dogumyili.$eskisifre.$sevgili;
$wp["416"] = $dogumyili.$eskisifre.$sevgilisoyad;
$wp["417"] = $dogumyili.$eskisifre.$dogumtarihi;
$wp["418"] = $dogumyili.$eskisifre.$dogumyili;
$wp["419"] = $dogumyili.$eskisifre.$cikmayili;
$wp["420"] = $dogumyili.$eskisifre.$cikmatarihi;
$wp["421"] = $dogumyili.$eskisifre.$sehir;
$wp["422"] = $dogumyili.$eskisifre.$takim;
$wp["423"] = $dogumyili.$eskisifre.$takimtarihi;
$wp["424"] = $dogumyili.$eskisifre.$takimkisa;
$wp["425"] = $dogumyili.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $dogumyili.$tel;
$wp["427"] = $dogumyili.$tel."123";
$wp["428"] = $dogumyili.$tel."1905";
$wp["429"] = $dogumyili.$tel."1907";
$wp["430"] = $dogumyili.$tel."1903";
$wp["431"] = $dogumyili.$tel."1938";
$wp["432"] = $dogumyili.$tel."1919";
$wp["433"] = $dogumyili.$tel."1881";
$wp["434"] = $dogumyili.$tel."2018";
$wp["435"] = $dogumyili.$tel."2019";
$wp["436"] = $dogumyili.$tel.$lakap;
$wp["437"] = $dogumyili.$tel.$anne;
$wp["438"] = $dogumyili.$tel.$baba;
$wp["439"] = $dogumyili.$tel.$kardes;
$wp["440"] = $dogumyili.$tel.$sevgili;
$wp["441"] = $dogumyili.$tel.$sevgilisoyad;
$wp["442"] = $dogumyili.$tel.$dogumtarihi;
$wp["443"] = $dogumyili.$tel.$dogumyili;
$wp["444"] = $dogumyili.$tel.$cikmayili;
$wp["445"] = $dogumyili.$tel.$cikmatarihi;
$wp["446"] = $dogumyili.$tel.$sehir;
$wp["447"] = $dogumyili.$tel.$takim;
$wp["448"] = $dogumyili.$tel.$takimtarihi;
$wp["449"] = $dogumyili.$tel.$takimkisa;
$wp["450"] = $dogumyili.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $dogumyili.$annetel;
$wp["452"] = $dogumyili.$annetel."123";
$wp["453"] = $dogumyili.$annetel."1905";
$wp["454"] = $dogumyili.$annetel."1907";
$wp["455"] = $dogumyili.$annetel."1903";
$wp["456"] = $dogumyili.$annetel."1938";
$wp["457"] = $dogumyili.$annetel."1919";
$wp["458"] = $dogumyili.$annetel."1881";
$wp["459"] = $dogumyili.$annetel."2018";
$wp["460"] = $dogumyili.$annetel."2019";
$wp["461"] = $dogumyili.$annetel.$lakap;
$wp["462"] = $dogumyili.$annetel.$anne;
$wp["463"] = $dogumyili.$annetel.$baba;
$wp["464"] = $dogumyili.$annetel.$kardes;
$wp["465"] = $dogumyili.$annetel.$sevgili;
$wp["466"] = $dogumyili.$annetel.$sevgilisoyad;
$wp["467"] = $dogumyili.$annetel.$dogumtarihi;
$wp["468"] = $dogumyili.$annetel.$dogumyili;
$wp["469"] = $dogumyili.$annetel.$cikmayili;
$wp["470"] = $dogumyili.$annetel.$cikmatarihi;
$wp["471"] = $dogumyili.$annetel.$sehir;
$wp["472"] = $dogumyili.$annetel.$takim;
$wp["473"] = $dogumyili.$annetel.$takimtarihi;
$wp["474"] = $dogumyili.$annetel.$takimkisa;
$wp["475"] = $dogumyili.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $dogumyili.$babatel;
$wp["477"] = $dogumyili.$babatel."123";
$wp["478"] = $dogumyili.$babatel."1905";
$wp["479"] = $dogumyili.$babatel."1907";
$wp["480"] = $dogumyili.$babatel."1903";
$wp["481"] = $dogumyili.$babatel."1938";
$wp["482"] = $dogumyili.$babatel."1919";
$wp["483"] = $dogumyili.$babatel."1881";
$wp["484"] = $dogumyili.$babatel."2018";
$wp["485"] = $dogumyili.$babatel."2019";
$wp["486"] = $dogumyili.$babatel.$lakap;
$wp["487"] = $dogumyili.$babatel.$anne;
$wp["488"] = $dogumyili.$babatel.$baba;
$wp["489"] = $dogumyili.$babatel.$kardes;
$wp["490"] = $dogumyili.$babatel.$sevgili;
$wp["491"] = $dogumyili.$babatel.$sevgilisoyad;
$wp["492"] = $dogumyili.$babatel.$dogumtarihi;
$wp["493"] = $dogumyili.$babatel.$dogumyili;
$wp["494"] = $dogumyili.$babatel.$cikmayili;
$wp["495"] = $dogumyili.$babatel.$cikmatarihi;
$wp["496"] = $dogumyili.$babatel.$sehir;
$wp["497"] = $dogumyili.$babatel.$takim;
$wp["498"] = $dogumyili.$babatel.$takimtarihi;
$wp["499"] = $dogumyili.$babatel.$takimkisa;
$wp["500"] = $dogumyili.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $dogumyili.$kardestel;
$wp["502"] = $dogumyili.$kardestel."123";
$wp["503"] = $dogumyili.$kardestel."1905";
$wp["504"] = $dogumyili.$kardestel."1907";
$wp["505"] = $dogumyili.$kardestel."1903";
$wp["506"] = $dogumyili.$kardestel."1938";
$wp["507"] = $dogumyili.$kardestel."1919";
$wp["508"] = $dogumyili.$kardestel."1881";
$wp["509"] = $dogumyili.$kardestel."2018";
$wp["510"] = $dogumyili.$kardestel."2019";
$wp["511"] = $dogumyili.$kardestel.$lakap;
$wp["512"] = $dogumyili.$kardestel.$anne;
$wp["513"] = $dogumyili.$kardestel.$baba;
$wp["514"] = $dogumyili.$kardestel.$kardes;
$wp["515"] = $dogumyili.$kardestel.$sevgili;
$wp["516"] = $dogumyili.$kardestel.$sevgilisoyad;
$wp["517"] = $dogumyili.$kardestel.$dogumtarihi;
$wp["518"] = $dogumyili.$kardestel.$dogumyili;
$wp["519"] = $dogumyili.$kardestel.$cikmayili;
$wp["520"] = $dogumyili.$kardestel.$cikmatarihi;
$wp["521"] = $dogumyili.$kardestel.$sehir;
$wp["522"] = $dogumyili.$kardestel.$takim;
$wp["523"] = $dogumyili.$kardestel.$takimtarihi;
$wp["524"] = $dogumyili.$kardestel.$takimkisa;
$wp["525"] = $dogumyili.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $dogumyili.$sevgilitel;
$wp["527"] = $dogumyili.$sevgilitel."123";
$wp["528"] = $dogumyili.$sevgilitel."1905";
$wp["529"] = $dogumyili.$sevgilitel."1907";
$wp["530"] = $dogumyili.$sevgilitel."1903";
$wp["531"] = $dogumyili.$sevgilitel."1938";
$wp["532"] = $dogumyili.$sevgilitel."1919";
$wp["533"] = $dogumyili.$sevgilitel."1881";
$wp["534"] = $dogumyili.$sevgilitel."2018";
$wp["535"] = $dogumyili.$sevgilitel."2019";
$wp["536"] = $dogumyili.$sevgilitel.$lakap;
$wp["537"] = $dogumyili.$sevgilitel.$anne;
$wp["538"] = $dogumyili.$sevgilitel.$baba;
$wp["539"] = $dogumyili.$sevgilitel.$kardes;
$wp["540"] = $dogumyili.$sevgilitel.$sevgili;
$wp["541"] = $dogumyili.$sevgilitel.$sevgilisoyad;
$wp["542"] = $dogumyili.$sevgilitel.$dogumtarihi;
$wp["543"] = $dogumyili.$sevgilitel.$dogumyili;
$wp["544"] = $dogumyili.$sevgilitel.$cikmayili;
$wp["545"] = $dogumyili.$sevgilitel.$cikmatarihi;
$wp["546"] = $dogumyili.$sevgilitel.$sehir;
$wp["547"] = $dogumyili.$sevgilitel.$takim;
$wp["548"] = $dogumyili.$sevgilitel.$takimtarihi;
$wp["549"] = $dogumyili.$sevgilitel.$takimkisa;
$wp["550"] = $dogumyili.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $dogumyili.$tckimlikno;
$wp["552"] = $dogumyili.$tckimlikno."13";
$wp["553"] = $dogumyili.$tckimlikno."1905";
$wp["554"] = $dogumyili.$tckimlikno."1907";
$wp["555"] = $dogumyili.$tckimlikno."1903";
$wp["556"] = $dogumyili.$tckimlikno."1938";
$wp["557"] = $dogumyili.$tckimlikno."1919";
$wp["558"] = $dogumyili.$tckimlikno."1881";
$wp["559"] = $dogumyili.$tckimlikno."2018";
$wp["560"] = $dogumyili.$tckimlikno."2019";
$wp["561"] = $dogumyili.$tckimlikno.$lakap;
$wp["562"] = $dogumyili.$tckimlikno.$anne;
$wp["563"] = $dogumyili.$tckimlikno.$baba;
$wp["564"] = $dogumyili.$tckimlikno.$kardes;
$wp["565"] = $dogumyili.$tckimlikno.$sevgili;
$wp["566"] = $dogumyili.$tckimlikno.$sevgilisoyad;
$wp["567"] = $dogumyili.$tckimlikno.$dogumtarihi;
$wp["568"] = $dogumyili.$tckimlikno.$dogumyili;
$wp["569"] = $dogumyili.$tckimlikno.$cikmayili;
$wp["570"] = $dogumyili.$tckimlikno.$cikmatarihi;
$wp["571"] = $dogumyili.$tckimlikno.$sehir;
$wp["572"] = $dogumyili.$tckimlikno.$takim;
$wp["573"] = $dogumyili.$tckimlikno.$takimtarihi;
$wp["574"] = $dogumyili.$tckimlikno.$takimkisa;
$wp["575"] = $dogumyili.$tckimlikno.$plaka;






for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);


 ?>