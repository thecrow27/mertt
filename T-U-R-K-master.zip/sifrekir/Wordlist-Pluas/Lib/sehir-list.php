<?php 

error_reporting(0);

include "kayit.php";




$wp["1"] = $sehir;
$wp["2"] = $sehir.$soyadad."123";
$wp["3"] = $sehir.$soyadad."1905";
$wp["4"] = $sehir.$soyadad."1907";
$wp["5"] = $sehir.$soyadad."1903";
$wp["6"] = $sehir.$soyadad."1938";
$wp["7"] = $sehir.$soyadad."1919";
$wp["8"] = $sehir.$soyadad."1881";
$wp["9"] = $sehir.$soyadad."2018";
$wp["10"] = $sehir.$soyadad."2019";
$wp["11"] = $sehir.$soyadad.$lakap;
$wp["12"] = $sehir.$soyadad.$anne;
$wp["13"] = $sehir.$soyadad.$baba;
$wp["14"] = $sehir.$soyadad.$kardes;
$wp["15"] = $sehir.$soyadad.$sevgili;
$wp["16"] = $sehir.$soyadad.$sevgilisoyad;
$wp["17"] = $sehir.$soyadad.$dogumtarihi;
$wp["18"] = $sehir.$soyadad.$dogumyili;
$wp["19"] = $sehir.$soyadad.$cikmayili;
$wp["20"] = $sehir.$soyadad.$cikmatarihi;
$wp["21"] = $sehir.$soyadad.$sehir;
$wp["22"] = $sehir.$soyadad.$takim;
$wp["23"] = $sehir.$soyadad.$takimtarihi;
$wp["24"] = $sehir.$soyadad.$takimkisa;
$wp["25"] = $sehir.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $sehir.$lakap;
$wp["27"] = $sehir.$lakap."123";
$wp["28"] = $sehir.$lakap."1905";
$wp["29"] = $sehir.$lakap."1907";
$wp["30"] = $sehir.$lakap."1903";
$wp["31"] = $sehir.$lakap."1938";
$wp["32"] = $sehir.$lakap."1919";
$wp["33"] = $sehir.$lakap."1881";
$wp["34"] = $sehir.$lakap."2018";
$wp["35"] = $sehir.$lakap."2019";
$wp["36"] = $sehir.$lakap.$lakap;
$wp["37"] = $sehir.$lakap.$anne;
$wp["38"] = $sehir.$lakap.$baba;
$wp["39"] = $sehir.$lakap.$kardes;
$wp["40"] = $sehir.$lakap.$sevgili;
$wp["41"] = $sehir.$lakap.$sevgilisoyad;
$wp["42"] = $sehir.$lakap.$dogumtarihi;
$wp["43"] = $sehir.$lakap.$dogumyili;
$wp["44"] = $sehir.$lakap.$cikmayili;
$wp["45"] = $sehir.$lakap.$cikmatarihi;
$wp["46"] = $sehir.$lakap.$sehir;
$wp["47"] = $sehir.$lakap.$takim;
$wp["48"] = $sehir.$lakap.$takimtarihi;
$wp["49"] = $sehir.$lakap.$takimkisa;
$wp["50"] = $sehir.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $sehir.$anne;
$wp["52"] = $sehir.$anne."123";
$wp["53"] = $sehir.$anne."1905";
$wp["54"] = $sehir.$anne."1907";
$wp["55"] = $sehir.$anne."1903";
$wp["56"] = $sehir.$anne."1938";
$wp["57"] = $sehir.$anne."1919";
$wp["58"] = $sehir.$anne."1881";
$wp["59"] = $sehir.$anne."2018";
$wp["60"] = $sehir.$anne."2019";
$wp["61"] = $sehir.$anne.$lakap;
$wp["62"] = $sehir.$anne.$anne;
$wp["63"] = $sehir.$anne.$baba;
$wp["64"] = $sehir.$anne.$kardes;
$wp["65"] = $sehir.$anne.$sevgili;
$wp["66"] = $sehir.$anne.$sevgilisoyad;
$wp["67"] = $sehir.$anne.$dogumtarihi;
$wp["68"] = $sehir.$anne.$dogumyili;
$wp["69"] = $sehir.$anne.$cikmayili;
$wp["70"] = $sehir.$anne.$cikmatarihi;
$wp["71"] = $sehir.$anne.$sehir;
$wp["72"] = $sehir.$anne.$takim;
$wp["73"] = $sehir.$anne.$takimtarihi;
$wp["74"] = $sehir.$anne.$takimkisa;
$wp["75"] = $sehir.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $sehir.$baba;
$wp["77"] = $sehir.$baba."123";
$wp["78"] = $sehir.$baba."1905";
$wp["79"] = $sehir.$baba."1907";
$wp["80"] = $sehir.$baba."1903";
$wp["81"] = $sehir.$baba."1938";
$wp["82"] = $sehir.$baba."1919";
$wp["83"] = $sehir.$baba."1881";
$wp["84"] = $sehir.$baba."2018";
$wp["85"] = $sehir.$baba."2019";
$wp["86"] = $sehir.$baba.$lakap;
$wp["87"] = $sehir.$baba.$anne;
$wp["88"] = $sehir.$baba.$baba;
$wp["89"] = $sehir.$baba.$kardes;
$wp["90"] = $sehir.$baba.$sevgili;
$wp["91"] = $sehir.$baba.$sevgilisoyad;
$wp["92"] = $sehir.$baba.$dogumtarihi;
$wp["93"] = $sehir.$baba.$dogumyili;
$wp["94"] = $sehir.$baba.$cikmayili;
$wp["95"] = $sehir.$baba.$cikmatarihi;
$wp["96"] = $sehir.$baba.$sehir;
$wp["97"] = $sehir.$baba.$takim;
$wp["98"] = $sehir.$baba.$takimtarihi;
$wp["99"] = $sehir.$baba.$takimkisa;
$wp["100"] = $sehir.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $sehir.$kardes;
$wp["102"] = $sehir.$kardes."123";
$wp["103"] = $sehir.$kardes."1905";
$wp["104"] = $sehir.$kardes."1907";
$wp["105"] = $sehir.$kardes."1903";
$wp["106"] = $sehir.$kardes."1938";
$wp["107"] = $sehir.$kardes."1919";
$wp["108"] = $sehir.$kardes."1881";
$wp["109"] = $sehir.$kardes."2018";
$wp["110"] = $sehir.$kardes."2019";
$wp["111"] = $sehir.$kardes.$lakap;
$wp["112"] = $sehir.$kardes.$anne;
$wp["113"] = $sehir.$kardes.$baba;
$wp["114"] = $sehir.$kardes.$kardes;
$wp["115"] = $sehir.$kardes.$sevgili;
$wp["116"] = $sehir.$kardes.$sevgilisoyad;
$wp["117"] = $sehir.$kardes.$dogumtarihi;
$wp["118"] = $sehir.$kardes.$dogumyili;
$wp["119"] = $sehir.$kardes.$cikmayili;
$wp["120"] = $sehir.$kardes.$cikmatarihi;
$wp["121"] = $sehir.$kardes.$sehir;
$wp["122"] = $sehir.$kardes.$takim;
$wp["123"] = $sehir.$kardes.$takimtarihi;
$wp["124"] = $sehir.$kardes.$takimkisa;
$wp["125"] = $sehir.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $sehir.$sevgili;
$wp["127"] = $sehir.$sevgili."123";
$wp["128"] = $sehir.$sevgili."1905";
$wp["129"] = $sehir.$sevgili."1907";
$wp["130"] = $sehir.$sevgili."1903";
$wp["131"] = $sehir.$sevgili."1938";
$wp["132"] = $sehir.$sevgili."1919";
$wp["133"] = $sehir.$sevgili."1881";
$wp["134"] = $sehir.$sevgili."2018";
$wp["135"] = $sehir.$sevgili."2019";
$wp["136"] = $sehir.$sevgili.$lakap;
$wp["137"] = $sehir.$sevgili.$anne;
$wp["138"] = $sehir.$sevgili.$baba;
$wp["139"] = $sehir.$sevgili.$kardes;
$wp["140"] = $sehir.$sevgili.$sevgili;
$wp["141"] = $sehir.$sevgili.$sevgilisoyad;
$wp["142"] = $sehir.$sevgili.$dogumtarihi;
$wp["143"] = $sehir.$sevgili.$dogumyili;
$wp["144"] = $sehir.$sevgili.$cikmayili;
$wp["145"] = $sehir.$sevgili.$cikmatarihi;
$wp["146"] = $sehir.$sevgili.$sehir;
$wp["147"] = $sehir.$sevgili.$takim;
$wp["148"] = $sehir.$sevgili.$takimtarihi;
$wp["149"] = $sehir.$sevgili.$takimkisa;
$wp["150"] = $sehir.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $sehir.$sevgilisoyad;
$wp["152"] = $sehir.$sevgilisoyad."123";
$wp["153"] = $sehir.$sevgilisoyad."1905";
$wp["154"] = $sehir.$sevgilisoyad."1907";
$wp["155"] = $sehir.$sevgilisoyad."1903";
$wp["156"] = $sehir.$sevgilisoyad."1938";
$wp["157"] = $sehir.$sevgilisoyad."1919";
$wp["158"] = $sehir.$sevgilisoyad."1881";
$wp["159"] = $sehir.$sevgilisoyad."2018";
$wp["160"] = $sehir.$sevgilisoyad."2019";
$wp["161"] = $sehir.$sevgilisoyad.$lakap;
$wp["162"] = $sehir.$sevgilisoyad.$anne;
$wp["163"] = $sehir.$sevgilisoyad.$baba;
$wp["164"] = $sehir.$sevgilisoyad.$kardes;
$wp["165"] = $sehir.$sevgilisoyad.$sevgili;
$wp["166"] = $sehir.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $sehir.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $sehir.$sevgilisoyad.$dogumyili;
$wp["169"] = $sehir.$sevgilisoyad.$cikmayili;
$wp["170"] = $sehir.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $sehir.$sevgilisoyad.$sehir;
$wp["172"] = $sehir.$sevgilisoyad.$takim;
$wp["173"] = $sehir.$sevgilisoyad.$takimtarihi;
$wp["174"] = $sehir.$sevgilisoyad.$takimkisa;
$wp["175"] = $sehir.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $sehir.$dogumtarihi;
$wp["177"] = $sehir.$dogumtarihi."123";
$wp["178"] = $sehir.$dogumtarihi."1905";
$wp["179"] = $sehir.$dogumtarihi."1907";
$wp["180"] = $sehir.$dogumtarihi."1903";
$wp["181"] = $sehir.$dogumtarihi."1938";
$wp["200"] = $sehir.$dogumtarihi."1919";
$wp["182"] = $sehir.$dogumtarihi."1881";
$wp["183"] = $sehir.$dogumtarihi."2018";
$wp["184"] = $sehir.$dogumtarihi."2019";
$wp["185"] = $sehir.$dogumtarihi.$lakap;
$wp["186"] = $sehir.$dogumtarihi.$anne;
$wp["187"] = $sehir.$dogumtarihi.$baba;
$wp["188"] = $sehir.$dogumtarihi.$kardes;
$wp["189"] = $sehir.$dogumtarihi.$sevgili;
$wp["190"] = $sehir.$dogumtarihi.$dogumtarihi;
$wp["191"] = $sehir.$dogumtarihi.$dogumtarihi;
$wp["192"] = $sehir.$dogumtarihi.$dogumyili;
$wp["193"] = $sehir.$dogumtarihi.$cikmayili;
$wp["194"] = $sehir.$dogumtarihi.$cikmatarihi;
$wp["195"] = $sehir.$dogumtarihi.$sehir;
$wp["196"] = $sehir.$dogumtarihi.$takim;
$wp["197"] = $sehir.$dogumtarihi.$takimtarihi;
$wp["198"] = $sehir.$dogumtarihi.$takimkisa;
$wp["199"] = $sehir.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $sehir.$dogumyili;
$wp["202"] = $sehir.$dogumyili."123";
$wp["203"] = $sehir.$dogumyili."1905";
$wp["204"] = $sehir.$dogumyili."1907";
$wp["205"] = $sehir.$dogumyili."1903";
$wp["206"] = $sehir.$dogumyili."1938";
$wp["207"] = $sehir.$dogumyili."1919";
$wp["208"] = $sehir.$dogumyili."1881";
$wp["209"] = $sehir.$dogumyili."2018";
$wp["210"] = $sehir.$dogumyili."2019";
$wp["211"] = $sehir.$dogumyili.$lakap;
$wp["212"] = $sehir.$dogumyili.$anne;
$wp["213"] = $sehir.$dogumyili.$baba;
$wp["214"] = $sehir.$dogumyili.$kardes;
$wp["215"] = $sehir.$dogumyili.$sevgili;
$wp["216"] = $sehir.$dogumyili.$dogumyili;
$wp["217"] = $sehir.$dogumyili.$dogumyili;
$wp["218"] = $sehir.$dogumyili.$dogumyili;
$wp["219"] = $sehir.$dogumyili.$cikmayili;
$wp["220"] = $sehir.$dogumyili.$cikmatarihi;
$wp["221"] = $sehir.$dogumyili.$sehir;
$wp["222"] = $sehir.$dogumyili.$takim;
$wp["223"] = $sehir.$dogumyili.$takimtarihi;
$wp["224"] = $sehir.$dogumyili.$takimkisa;
$wp["225"] = $sehir.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $sehir.$cikmayili;
$wp["227"] = $sehir.$cikmayili."123";
$wp["228"] = $sehir.$cikmayili."1905";
$wp["229"] = $sehir.$cikmayili."1907";
$wp["230"] = $sehir.$cikmayili."1903";
$wp["231"] = $sehir.$cikmayili."1938";
$wp["232"] = $sehir.$cikmayili."1919";
$wp["233"] = $sehir.$cikmayili."1881";
$wp["234"] = $sehir.$cikmayili."2018";
$wp["235"] = $sehir.$cikmayili."2019";
$wp["236"] = $sehir.$cikmayili.$lakap;
$wp["237"] = $sehir.$cikmayili.$anne;
$wp["238"] = $sehir.$cikmayili.$baba;
$wp["239"] = $sehir.$cikmayili.$kardes;
$wp["240"] = $sehir.$cikmayili.$sevgili;
$wp["241"] = $sehir.$cikmayili.$cikmayili;
$wp["242"] = $sehir.$cikmayili.$dogumyili;
$wp["243"] = $sehir.$cikmayili.$cikmayili;
$wp["244"] = $sehir.$cikmayili.$cikmayili;
$wp["245"] = $sehir.$cikmayili.$cikmatarihi;
$wp["246"] = $sehir.$cikmayili.$sehir;
$wp["247"] = $sehir.$cikmayili.$takim;
$wp["248"] = $sehir.$cikmayili.$takimtarihi;
$wp["249"] = $sehir.$cikmayili.$takimkisa;
$wp["250"] = $sehir.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $sehir.$cikmatarihi;
$wp["252"] = $sehir.$cikmatarihi."123";
$wp["253"] = $sehir.$cikmatarihi."1905";
$wp["254"] = $sehir.$cikmatarihi."1907";
$wp["255"] = $sehir.$cikmatarihi."1903";
$wp["256"] = $sehir.$cikmatarihi."1938";
$wp["257"] = $sehir.$cikmatarihi."1919";
$wp["258"] = $sehir.$cikmatarihi."1881";
$wp["259"] = $sehir.$cikmatarihi."2018";
$wp["260"] = $sehir.$cikmatarihi."2019";
$wp["261"] = $sehir.$cikmatarihi.$lakap;
$wp["262"] = $sehir.$cikmatarihi.$anne;
$wp["263"] = $sehir.$cikmatarihi.$baba;
$wp["264"] = $sehir.$cikmatarihi.$kardes;
$wp["265"] = $sehir.$cikmatarihi.$sevgili;
$wp["267"] = $sehir.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $sehir.$cikmatarihi.$dogumtarihi;
$wp["269"] = $sehir.$cikmatarihi.$dogumyili;
$wp["270"] = $sehir.$cikmatarihi.$cikmayili;
$wp["271"] = $sehir.$cikmatarihi.$cikmatarihi;
$wp["272"] = $sehir.$cikmatarihi.$sehir;
$wp["273"] = $sehir.$cikmatarihi.$takim;
$wp["274"] = $sehir.$cikmatarihi.$takimtarihi;
$wp["275"] = $sehir.$cikmatarihi.$takimkisa;
$wp["266"] = $sehir.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $sehir.$sehir;
$wp["277"] = $sehir.$sehir."123";
$wp["278"] = $sehir.$sehir."1905";
$wp["279"] = $sehir.$sehir."1907";
$wp["280"] = $sehir.$sehir."1903";
$wp["281"] = $sehir.$sehir."1938";
$wp["282"] = $sehir.$sehir."1919";
$wp["283"] = $sehir.$sehir."1881";
$wp["284"] = $sehir.$sehir."2018";
$wp["285"] = $sehir.$sehir."2019";
$wp["286"] = $sehir.$sehir.$lakap;
$wp["287"] = $sehir.$sehir.$anne;
$wp["288"] = $sehir.$sehir.$baba;
$wp["289"] = $sehir.$sehir.$kardes;
$wp["290"] = $sehir.$sehir.$sevgili;
$wp["291"] = $sehir.$sehir.$sevgilisoyad;
$wp["292"] = $sehir.$sehir.$dogumtarihi;
$wp["293"] = $sehir.$sehir.$dogumyili;
$wp["294"] = $sehir.$sehir.$cikmayili;
$wp["295"] = $sehir.$sehir.$cikmatarihi;
$wp["296"] = $sehir.$sehir.$sehir;
$wp["297"] = $sehir.$sehir.$takim;
$wp["298"] = $sehir.$sehir.$takimtarihi;
$wp["299"] = $sehir.$sehir.$takimkisa;
$wp["300"] = $sehir.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $sehir.$takim;
$wp["302"] = $sehir.$takim."123";
$wp["303"] = $sehir.$takim."1905";
$wp["304"] = $sehir.$takim."1907";
$wp["305"] = $sehir.$takim."1903";
$wp["306"] = $sehir.$takim."1938";
$wp["307"] = $sehir.$takim."1919";
$wp["308"] = $sehir.$takim."1881";
$wp["309"] = $sehir.$takim."2018";
$wp["310"] = $sehir.$takim."2019";
$wp["311"] = $sehir.$takim.$lakap;
$wp["312"] = $sehir.$takim.$anne;
$wp["313"] = $sehir.$takim.$baba;
$wp["314"] = $sehir.$takim.$kardes;
$wp["315"] = $sehir.$takim.$sevgili;
$wp["316"] = $sehir.$takim.$sevgilisoyad;
$wp["317"] = $sehir.$takim.$dogumtarihi;
$wp["318"] = $sehir.$takim.$dogumyili;
$wp["319"] = $sehir.$takim.$cikmayili;
$wp["320"] = $sehir.$takim.$cikmatarihi;
$wp["321"] = $sehir.$takim.$sehir;
$wp["322"] = $sehir.$takim.$takim;
$wp["323"] = $sehir.$takim.$takimtarihi;
$wp["324"] = $sehir.$takim.$takimkisa;
$wp["325"] = $sehir.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $sehir.$takimtarihi;
$wp["327"] = $sehir.$takimtarihi."123";
$wp["328"] = $sehir.$takimtarihi."1905";
$wp["329"] = $sehir.$takimtarihi."1907";
$wp["330"] = $sehir.$takimtarihi."1903";
$wp["331"] = $sehir.$takimtarihi."1938";
$wp["332"] = $sehir.$takimtarihi."1919";
$wp["333"] = $sehir.$takimtarihi."1881";
$wp["334"] = $sehir.$takimtarihi."2018";
$wp["335"] = $sehir.$takimtarihi."2019";
$wp["336"] = $sehir.$takimtarihi.$lakap;
$wp["337"] = $sehir.$takimtarihi.$anne;
$wp["338"] = $sehir.$takimtarihi.$baba;
$wp["339"] = $sehir.$takimtarihi.$kardes;
$wp["340"] = $sehir.$takimtarihi.$sevgili;
$wp["341"] = $sehir.$takimtarihi.$sevgilisoyad;
$wp["342"] = $sehir.$takimtarihi.$dogumtarihi;
$wp["343"] = $sehir.$takimtarihi.$dogumyili;
$wp["344"] = $sehir.$takimtarihi.$cikmayili;
$wp["345"] = $sehir.$takimtarihi.$cikmatarihi;
$wp["346"] = $sehir.$takimtarihi.$sehir;
$wp["347"] = $sehir.$takimtarihi.$takim;
$wp["348"] = $sehir.$takimtarihi.$takimtarihi;
$wp["349"] = $sehir.$takimtarihi.$takimkisa;
$wp["350"] = $sehir.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $sehir.$takimkisa;
$wp["352"] = $sehir.$takimkisa."123";
$wp["353"] = $sehir.$takimkisa."1905";
$wp["354"] = $sehir.$takimkisa."1907";
$wp["355"] = $sehir.$takimkisa."1903";
$wp["356"] = $sehir.$takimkisa."1938";
$wp["357"] = $sehir.$takimkisa."1919";
$wp["358"] = $sehir.$takimkisa."1881";
$wp["359"] = $sehir.$takimkisa."2018";
$wp["360"] = $sehir.$takimkisa."2019";
$wp["361"] = $sehir.$takimkisa.$lakap;
$wp["362"] = $sehir.$takimkisa.$anne;
$wp["363"] = $sehir.$takimkisa.$baba;
$wp["364"] = $sehir.$takimkisa.$kardes;
$wp["365"] = $sehir.$takimkisa.$sevgili;
$wp["366"] = $sehir.$takimkisa.$sevgilisoyad;
$wp["367"] = $sehir.$takimkisa.$dogumtarihi;
$wp["368"] = $sehir.$takimkisa.$dogumyili;
$wp["369"] = $sehir.$takimkisa.$cikmayili;
$wp["370"] = $sehir.$takimkisa.$cikmatarihi;
$wp["371"] = $sehir.$takimkisa.$sehir;
$wp["372"] = $sehir.$takimkisa.$takim;
$wp["373"] = $sehir.$takimkisa.$takimtarihi;
$wp["374"] = $sehir.$takimkisa.$takimkisa;
$wp["375"] = $sehir.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $sehir.$plaka;
$wp["377"] = $sehir.$plaka."123";
$wp["378"] = $sehir.$plaka."1905";
$wp["379"] = $sehir.$plaka."1907";
$wp["380"] = $sehir.$plaka."1903";
$wp["381"] = $sehir.$plaka."1938";
$wp["382"] = $sehir.$plaka."1919";
$wp["383"] = $sehir.$plaka."1881";
$wp["384"] = $sehir.$plaka."2018";
$wp["385"] = $sehir.$plaka."2019";
$wp["386"] = $sehir.$plaka.$lakap;
$wp["387"] = $sehir.$plaka.$anne;
$wp["388"] = $sehir.$plaka.$baba;
$wp["389"] = $sehir.$plaka.$kardes;
$wp["390"] = $sehir.$plaka.$sevgili;
$wp["391"] = $sehir.$plaka.$sevgilisoyad;
$wp["392"] = $sehir.$plaka.$dogumtarihi;
$wp["393"] = $sehir.$plaka.$dogumyili;
$wp["394"] = $sehir.$plaka.$cikmayili;
$wp["395"] = $sehir.$plaka.$cikmatarihi;
$wp["396"] = $sehir.$plaka.$sehir;
$wp["397"] = $sehir.$plaka.$takim;
$wp["398"] = $sehir.$plaka.$takimtarihi;
$wp["399"] = $sehir.$plaka.$takimkisa;
$wp["400"] = $sehir.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $sehir.$eskisifre;
$wp["402"] = $sehir.$eskisifre."123";
$wp["403"] = $sehir.$eskisifre."1905";
$wp["404"] = $sehir.$eskisifre."1907";
$wp["405"] = $sehir.$eskisifre."1903";
$wp["406"] = $sehir.$eskisifre."1938";
$wp["407"] = $sehir.$eskisifre."1919";
$wp["408"] = $sehir.$eskisifre."1881";
$wp["409"] = $sehir.$eskisifre."2018";
$wp["410"] = $sehir.$eskisifre."2019";
$wp["411"] = $sehir.$eskisifre.$lakap;
$wp["412"] = $sehir.$eskisifre.$anne;
$wp["413"] = $sehir.$eskisifre.$baba;
$wp["414"] = $sehir.$eskisifre.$kardes;
$wp["415"] = $sehir.$eskisifre.$sevgili;
$wp["416"] = $sehir.$eskisifre.$sevgilisoyad;
$wp["417"] = $sehir.$eskisifre.$dogumtarihi;
$wp["418"] = $sehir.$eskisifre.$dogumyili;
$wp["419"] = $sehir.$eskisifre.$cikmayili;
$wp["420"] = $sehir.$eskisifre.$cikmatarihi;
$wp["421"] = $sehir.$eskisifre.$sehir;
$wp["422"] = $sehir.$eskisifre.$takim;
$wp["423"] = $sehir.$eskisifre.$takimtarihi;
$wp["424"] = $sehir.$eskisifre.$takimkisa;
$wp["425"] = $sehir.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $sehir.$tel;
$wp["427"] = $sehir.$tel."123";
$wp["428"] = $sehir.$tel."1905";
$wp["429"] = $sehir.$tel."1907";
$wp["430"] = $sehir.$tel."1903";
$wp["431"] = $sehir.$tel."1938";
$wp["432"] = $sehir.$tel."1919";
$wp["433"] = $sehir.$tel."1881";
$wp["434"] = $sehir.$tel."2018";
$wp["435"] = $sehir.$tel."2019";
$wp["436"] = $sehir.$tel.$lakap;
$wp["437"] = $sehir.$tel.$anne;
$wp["438"] = $sehir.$tel.$baba;
$wp["439"] = $sehir.$tel.$kardes;
$wp["440"] = $sehir.$tel.$sevgili;
$wp["441"] = $sehir.$tel.$sevgilisoyad;
$wp["442"] = $sehir.$tel.$dogumtarihi;
$wp["443"] = $sehir.$tel.$dogumyili;
$wp["444"] = $sehir.$tel.$cikmayili;
$wp["445"] = $sehir.$tel.$cikmatarihi;
$wp["446"] = $sehir.$tel.$sehir;
$wp["447"] = $sehir.$tel.$takim;
$wp["448"] = $sehir.$tel.$takimtarihi;
$wp["449"] = $sehir.$tel.$takimkisa;
$wp["450"] = $sehir.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $sehir.$annetel;
$wp["452"] = $sehir.$annetel."123";
$wp["453"] = $sehir.$annetel."1905";
$wp["454"] = $sehir.$annetel."1907";
$wp["455"] = $sehir.$annetel."1903";
$wp["456"] = $sehir.$annetel."1938";
$wp["457"] = $sehir.$annetel."1919";
$wp["458"] = $sehir.$annetel."1881";
$wp["459"] = $sehir.$annetel."2018";
$wp["460"] = $sehir.$annetel."2019";
$wp["461"] = $sehir.$annetel.$lakap;
$wp["462"] = $sehir.$annetel.$anne;
$wp["463"] = $sehir.$annetel.$baba;
$wp["464"] = $sehir.$annetel.$kardes;
$wp["465"] = $sehir.$annetel.$sevgili;
$wp["466"] = $sehir.$annetel.$sevgilisoyad;
$wp["467"] = $sehir.$annetel.$dogumtarihi;
$wp["468"] = $sehir.$annetel.$dogumyili;
$wp["469"] = $sehir.$annetel.$cikmayili;
$wp["470"] = $sehir.$annetel.$cikmatarihi;
$wp["471"] = $sehir.$annetel.$sehir;
$wp["472"] = $sehir.$annetel.$takim;
$wp["473"] = $sehir.$annetel.$takimtarihi;
$wp["474"] = $sehir.$annetel.$takimkisa;
$wp["475"] = $sehir.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $sehir.$babatel;
$wp["477"] = $sehir.$babatel."123";
$wp["478"] = $sehir.$babatel."1905";
$wp["479"] = $sehir.$babatel."1907";
$wp["480"] = $sehir.$babatel."1903";
$wp["481"] = $sehir.$babatel."1938";
$wp["482"] = $sehir.$babatel."1919";
$wp["483"] = $sehir.$babatel."1881";
$wp["484"] = $sehir.$babatel."2018";
$wp["485"] = $sehir.$babatel."2019";
$wp["486"] = $sehir.$babatel.$lakap;
$wp["487"] = $sehir.$babatel.$anne;
$wp["488"] = $sehir.$babatel.$baba;
$wp["489"] = $sehir.$babatel.$kardes;
$wp["490"] = $sehir.$babatel.$sevgili;
$wp["491"] = $sehir.$babatel.$sevgilisoyad;
$wp["492"] = $sehir.$babatel.$dogumtarihi;
$wp["493"] = $sehir.$babatel.$dogumyili;
$wp["494"] = $sehir.$babatel.$cikmayili;
$wp["495"] = $sehir.$babatel.$cikmatarihi;
$wp["496"] = $sehir.$babatel.$sehir;
$wp["497"] = $sehir.$babatel.$takim;
$wp["498"] = $sehir.$babatel.$takimtarihi;
$wp["499"] = $sehir.$babatel.$takimkisa;
$wp["500"] = $sehir.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $sehir.$kardestel;
$wp["502"] = $sehir.$kardestel."123";
$wp["503"] = $sehir.$kardestel."1905";
$wp["504"] = $sehir.$kardestel."1907";
$wp["505"] = $sehir.$kardestel."1903";
$wp["506"] = $sehir.$kardestel."1938";
$wp["507"] = $sehir.$kardestel."1919";
$wp["508"] = $sehir.$kardestel."1881";
$wp["509"] = $sehir.$kardestel."2018";
$wp["510"] = $sehir.$kardestel."2019";
$wp["511"] = $sehir.$kardestel.$lakap;
$wp["512"] = $sehir.$kardestel.$anne;
$wp["513"] = $sehir.$kardestel.$baba;
$wp["514"] = $sehir.$kardestel.$kardes;
$wp["515"] = $sehir.$kardestel.$sevgili;
$wp["516"] = $sehir.$kardestel.$sevgilisoyad;
$wp["517"] = $sehir.$kardestel.$dogumtarihi;
$wp["518"] = $sehir.$kardestel.$dogumyili;
$wp["519"] = $sehir.$kardestel.$cikmayili;
$wp["520"] = $sehir.$kardestel.$cikmatarihi;
$wp["521"] = $sehir.$kardestel.$sehir;
$wp["522"] = $sehir.$kardestel.$takim;
$wp["523"] = $sehir.$kardestel.$takimtarihi;
$wp["524"] = $sehir.$kardestel.$takimkisa;
$wp["525"] = $sehir.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $sehir.$sevgilitel;
$wp["527"] = $sehir.$sevgilitel."123";
$wp["528"] = $sehir.$sevgilitel."1905";
$wp["529"] = $sehir.$sevgilitel."1907";
$wp["530"] = $sehir.$sevgilitel."1903";
$wp["531"] = $sehir.$sevgilitel."1938";
$wp["532"] = $sehir.$sevgilitel."1919";
$wp["533"] = $sehir.$sevgilitel."1881";
$wp["534"] = $sehir.$sevgilitel."2018";
$wp["535"] = $sehir.$sevgilitel."2019";
$wp["536"] = $sehir.$sevgilitel.$lakap;
$wp["537"] = $sehir.$sevgilitel.$anne;
$wp["538"] = $sehir.$sevgilitel.$baba;
$wp["539"] = $sehir.$sevgilitel.$kardes;
$wp["540"] = $sehir.$sevgilitel.$sevgili;
$wp["541"] = $sehir.$sevgilitel.$sevgilisoyad;
$wp["542"] = $sehir.$sevgilitel.$dogumtarihi;
$wp["543"] = $sehir.$sevgilitel.$dogumyili;
$wp["544"] = $sehir.$sevgilitel.$cikmayili;
$wp["545"] = $sehir.$sevgilitel.$cikmatarihi;
$wp["546"] = $sehir.$sevgilitel.$sehir;
$wp["547"] = $sehir.$sevgilitel.$takim;
$wp["548"] = $sehir.$sevgilitel.$takimtarihi;
$wp["549"] = $sehir.$sevgilitel.$takimkisa;
$wp["550"] = $sehir.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $sehir.$tckimlikno;
$wp["552"] = $sehir.$tckimlikno."13";
$wp["553"] = $sehir.$tckimlikno."1905";
$wp["554"] = $sehir.$tckimlikno."1907";
$wp["555"] = $sehir.$tckimlikno."1903";
$wp["556"] = $sehir.$tckimlikno."1938";
$wp["557"] = $sehir.$tckimlikno."1919";
$wp["558"] = $sehir.$tckimlikno."1881";
$wp["559"] = $sehir.$tckimlikno."2018";
$wp["560"] = $sehir.$tckimlikno."2019";
$wp["561"] = $sehir.$tckimlikno.$lakap;
$wp["562"] = $sehir.$tckimlikno.$anne;
$wp["563"] = $sehir.$tckimlikno.$baba;
$wp["564"] = $sehir.$tckimlikno.$kardes;
$wp["565"] = $sehir.$tckimlikno.$sevgili;
$wp["566"] = $sehir.$tckimlikno.$sevgilisoyad;
$wp["567"] = $sehir.$tckimlikno.$dogumtarihi;
$wp["568"] = $sehir.$tckimlikno.$dogumyili;
$wp["569"] = $sehir.$tckimlikno.$cikmayili;
$wp["570"] = $sehir.$tckimlikno.$cikmatarihi;
$wp["571"] = $sehir.$tckimlikno.$sehir;
$wp["572"] = $sehir.$tckimlikno.$takim;
$wp["573"] = $sehir.$tckimlikno.$takimtarihi;
$wp["574"] = $sehir.$tckimlikno.$takimkisa;
$wp["575"] = $sehir.$tckimlikno.$plaka;





for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);


 ?>