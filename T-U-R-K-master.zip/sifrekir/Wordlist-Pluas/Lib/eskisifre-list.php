<?php 

error_reporting(0);

include "kayit.php";



$wp["1"] = $eskisifre;
$wp["2"] = $eskisifre.$soyadad."123";
$wp["3"] = $eskisifre.$soyadad."1905";
$wp["4"] = $eskisifre.$soyadad."1907";
$wp["5"] = $eskisifre.$soyadad."1903";
$wp["6"] = $eskisifre.$soyadad."1938";
$wp["7"] = $eskisifre.$soyadad."1919";
$wp["8"] = $eskisifre.$soyadad."1881";
$wp["9"] = $eskisifre.$soyadad."2018";
$wp["10"] = $eskisifre.$soyadad."2019";
$wp["11"] = $eskisifre.$soyadad.$lakap;
$wp["12"] = $eskisifre.$soyadad.$anne;
$wp["13"] = $eskisifre.$soyadad.$baba;
$wp["14"] = $eskisifre.$soyadad.$kardes;
$wp["15"] = $eskisifre.$soyadad.$sevgili;
$wp["16"] = $eskisifre.$soyadad.$sevgilisoyad;
$wp["17"] = $eskisifre.$soyadad.$dogumtarihi;
$wp["18"] = $eskisifre.$soyadad.$dogumyili;
$wp["19"] = $eskisifre.$soyadad.$cikmayili;
$wp["20"] = $eskisifre.$soyadad.$cikmatarihi;
$wp["21"] = $eskisifre.$soyadad.$sehir;
$wp["22"] = $eskisifre.$soyadad.$takim;
$wp["23"] = $eskisifre.$soyadad.$takimtarihi;
$wp["24"] = $eskisifre.$soyadad.$takimkisa;
$wp["25"] = $eskisifre.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $eskisifre.$lakap;
$wp["27"] = $eskisifre.$lakap."123";
$wp["28"] = $eskisifre.$lakap."1905";
$wp["29"] = $eskisifre.$lakap."1907";
$wp["30"] = $eskisifre.$lakap."1903";
$wp["31"] = $eskisifre.$lakap."1938";
$wp["32"] = $eskisifre.$lakap."1919";
$wp["33"] = $eskisifre.$lakap."1881";
$wp["34"] = $eskisifre.$lakap."2018";
$wp["35"] = $eskisifre.$lakap."2019";
$wp["36"] = $eskisifre.$lakap.$lakap;
$wp["37"] = $eskisifre.$lakap.$anne;
$wp["38"] = $eskisifre.$lakap.$baba;
$wp["39"] = $eskisifre.$lakap.$kardes;
$wp["40"] = $eskisifre.$lakap.$sevgili;
$wp["41"] = $eskisifre.$lakap.$sevgilisoyad;
$wp["42"] = $eskisifre.$lakap.$dogumtarihi;
$wp["43"] = $eskisifre.$lakap.$dogumyili;
$wp["44"] = $eskisifre.$lakap.$cikmayili;
$wp["45"] = $eskisifre.$lakap.$cikmatarihi;
$wp["46"] = $eskisifre.$lakap.$sehir;
$wp["47"] = $eskisifre.$lakap.$takim;
$wp["48"] = $eskisifre.$lakap.$takimtarihi;
$wp["49"] = $eskisifre.$lakap.$takimkisa;
$wp["50"] = $eskisifre.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $eskisifre.$anne;
$wp["52"] = $eskisifre.$anne."123";
$wp["53"] = $eskisifre.$anne."1905";
$wp["54"] = $eskisifre.$anne."1907";
$wp["55"] = $eskisifre.$anne."1903";
$wp["56"] = $eskisifre.$anne."1938";
$wp["57"] = $eskisifre.$anne."1919";
$wp["58"] = $eskisifre.$anne."1881";
$wp["59"] = $eskisifre.$anne."2018";
$wp["60"] = $eskisifre.$anne."2019";
$wp["61"] = $eskisifre.$anne.$lakap;
$wp["62"] = $eskisifre.$anne.$anne;
$wp["63"] = $eskisifre.$anne.$baba;
$wp["64"] = $eskisifre.$anne.$kardes;
$wp["65"] = $eskisifre.$anne.$sevgili;
$wp["66"] = $eskisifre.$anne.$sevgilisoyad;
$wp["67"] = $eskisifre.$anne.$dogumtarihi;
$wp["68"] = $eskisifre.$anne.$dogumyili;
$wp["69"] = $eskisifre.$anne.$cikmayili;
$wp["70"] = $eskisifre.$anne.$cikmatarihi;
$wp["71"] = $eskisifre.$anne.$sehir;
$wp["72"] = $eskisifre.$anne.$takim;
$wp["73"] = $eskisifre.$anne.$takimtarihi;
$wp["74"] = $eskisifre.$anne.$takimkisa;
$wp["75"] = $eskisifre.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $eskisifre.$baba;
$wp["77"] = $eskisifre.$baba."123";
$wp["78"] = $eskisifre.$baba."1905";
$wp["79"] = $eskisifre.$baba."1907";
$wp["80"] = $eskisifre.$baba."1903";
$wp["81"] = $eskisifre.$baba."1938";
$wp["82"] = $eskisifre.$baba."1919";
$wp["83"] = $eskisifre.$baba."1881";
$wp["84"] = $eskisifre.$baba."2018";
$wp["85"] = $eskisifre.$baba."2019";
$wp["86"] = $eskisifre.$baba.$lakap;
$wp["87"] = $eskisifre.$baba.$anne;
$wp["88"] = $eskisifre.$baba.$baba;
$wp["89"] = $eskisifre.$baba.$kardes;
$wp["90"] = $eskisifre.$baba.$sevgili;
$wp["91"] = $eskisifre.$baba.$sevgilisoyad;
$wp["92"] = $eskisifre.$baba.$dogumtarihi;
$wp["93"] = $eskisifre.$baba.$dogumyili;
$wp["94"] = $eskisifre.$baba.$cikmayili;
$wp["95"] = $eskisifre.$baba.$cikmatarihi;
$wp["96"] = $eskisifre.$baba.$sehir;
$wp["97"] = $eskisifre.$baba.$takim;
$wp["98"] = $eskisifre.$baba.$takimtarihi;
$wp["99"] = $eskisifre.$baba.$takimkisa;
$wp["100"] = $eskisifre.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $eskisifre.$kardes;
$wp["102"] = $eskisifre.$kardes."123";
$wp["103"] = $eskisifre.$kardes."1905";
$wp["104"] = $eskisifre.$kardes."1907";
$wp["105"] = $eskisifre.$kardes."1903";
$wp["106"] = $eskisifre.$kardes."1938";
$wp["107"] = $eskisifre.$kardes."1919";
$wp["108"] = $eskisifre.$kardes."1881";
$wp["109"] = $eskisifre.$kardes."2018";
$wp["110"] = $eskisifre.$kardes."2019";
$wp["111"] = $eskisifre.$kardes.$lakap;
$wp["112"] = $eskisifre.$kardes.$anne;
$wp["113"] = $eskisifre.$kardes.$baba;
$wp["114"] = $eskisifre.$kardes.$kardes;
$wp["115"] = $eskisifre.$kardes.$sevgili;
$wp["116"] = $eskisifre.$kardes.$sevgilisoyad;
$wp["117"] = $eskisifre.$kardes.$dogumtarihi;
$wp["118"] = $eskisifre.$kardes.$dogumyili;
$wp["119"] = $eskisifre.$kardes.$cikmayili;
$wp["120"] = $eskisifre.$kardes.$cikmatarihi;
$wp["121"] = $eskisifre.$kardes.$sehir;
$wp["122"] = $eskisifre.$kardes.$takim;
$wp["123"] = $eskisifre.$kardes.$takimtarihi;
$wp["124"] = $eskisifre.$kardes.$takimkisa;
$wp["125"] = $eskisifre.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $eskisifre.$sevgili;
$wp["127"] = $eskisifre.$sevgili."123";
$wp["128"] = $eskisifre.$sevgili."1905";
$wp["129"] = $eskisifre.$sevgili."1907";
$wp["130"] = $eskisifre.$sevgili."1903";
$wp["131"] = $eskisifre.$sevgili."1938";
$wp["132"] = $eskisifre.$sevgili."1919";
$wp["133"] = $eskisifre.$sevgili."1881";
$wp["134"] = $eskisifre.$sevgili."2018";
$wp["135"] = $eskisifre.$sevgili."2019";
$wp["136"] = $eskisifre.$sevgili.$lakap;
$wp["137"] = $eskisifre.$sevgili.$anne;
$wp["138"] = $eskisifre.$sevgili.$baba;
$wp["139"] = $eskisifre.$sevgili.$kardes;
$wp["140"] = $eskisifre.$sevgili.$sevgili;
$wp["141"] = $eskisifre.$sevgili.$sevgilisoyad;
$wp["142"] = $eskisifre.$sevgili.$dogumtarihi;
$wp["143"] = $eskisifre.$sevgili.$dogumyili;
$wp["144"] = $eskisifre.$sevgili.$cikmayili;
$wp["145"] = $eskisifre.$sevgili.$cikmatarihi;
$wp["146"] = $eskisifre.$sevgili.$sehir;
$wp["147"] = $eskisifre.$sevgili.$takim;
$wp["148"] = $eskisifre.$sevgili.$takimtarihi;
$wp["149"] = $eskisifre.$sevgili.$takimkisa;
$wp["150"] = $eskisifre.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $eskisifre.$sevgilisoyad;
$wp["152"] = $eskisifre.$sevgilisoyad."123";
$wp["153"] = $eskisifre.$sevgilisoyad."1905";
$wp["154"] = $eskisifre.$sevgilisoyad."1907";
$wp["155"] = $eskisifre.$sevgilisoyad."1903";
$wp["156"] = $eskisifre.$sevgilisoyad."1938";
$wp["157"] = $eskisifre.$sevgilisoyad."1919";
$wp["158"] = $eskisifre.$sevgilisoyad."1881";
$wp["159"] = $eskisifre.$sevgilisoyad."2018";
$wp["160"] = $eskisifre.$sevgilisoyad."2019";
$wp["161"] = $eskisifre.$sevgilisoyad.$lakap;
$wp["162"] = $eskisifre.$sevgilisoyad.$anne;
$wp["163"] = $eskisifre.$sevgilisoyad.$baba;
$wp["164"] = $eskisifre.$sevgilisoyad.$kardes;
$wp["165"] = $eskisifre.$sevgilisoyad.$sevgili;
$wp["166"] = $eskisifre.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $eskisifre.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $eskisifre.$sevgilisoyad.$dogumyili;
$wp["169"] = $eskisifre.$sevgilisoyad.$cikmayili;
$wp["170"] = $eskisifre.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $eskisifre.$sevgilisoyad.$sehir;
$wp["172"] = $eskisifre.$sevgilisoyad.$takim;
$wp["173"] = $eskisifre.$sevgilisoyad.$takimtarihi;
$wp["174"] = $eskisifre.$sevgilisoyad.$takimkisa;
$wp["175"] = $eskisifre.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $eskisifre.$dogumtarihi;
$wp["177"] = $eskisifre.$dogumtarihi."123";
$wp["178"] = $eskisifre.$dogumtarihi."1905";
$wp["179"] = $eskisifre.$dogumtarihi."1907";
$wp["180"] = $eskisifre.$dogumtarihi."1903";
$wp["181"] = $eskisifre.$dogumtarihi."1938";
$wp["200"] = $eskisifre.$dogumtarihi."1919";
$wp["182"] = $eskisifre.$dogumtarihi."1881";
$wp["183"] = $eskisifre.$dogumtarihi."2018";
$wp["184"] = $eskisifre.$dogumtarihi."2019";
$wp["185"] = $eskisifre.$dogumtarihi.$lakap;
$wp["186"] = $eskisifre.$dogumtarihi.$anne;
$wp["187"] = $eskisifre.$dogumtarihi.$baba;
$wp["188"] = $eskisifre.$dogumtarihi.$kardes;
$wp["189"] = $eskisifre.$dogumtarihi.$sevgili;
$wp["190"] = $eskisifre.$dogumtarihi.$dogumtarihi;
$wp["191"] = $eskisifre.$dogumtarihi.$dogumtarihi;
$wp["192"] = $eskisifre.$dogumtarihi.$dogumyili;
$wp["193"] = $eskisifre.$dogumtarihi.$cikmayili;
$wp["194"] = $eskisifre.$dogumtarihi.$cikmatarihi;
$wp["195"] = $eskisifre.$dogumtarihi.$sehir;
$wp["196"] = $eskisifre.$dogumtarihi.$takim;
$wp["197"] = $eskisifre.$dogumtarihi.$takimtarihi;
$wp["198"] = $eskisifre.$dogumtarihi.$takimkisa;
$wp["199"] = $eskisifre.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $eskisifre.$dogumyili;
$wp["202"] = $eskisifre.$dogumyili."123";
$wp["203"] = $eskisifre.$dogumyili."1905";
$wp["204"] = $eskisifre.$dogumyili."1907";
$wp["205"] = $eskisifre.$dogumyili."1903";
$wp["206"] = $eskisifre.$dogumyili."1938";
$wp["207"] = $eskisifre.$dogumyili."1919";
$wp["208"] = $eskisifre.$dogumyili."1881";
$wp["209"] = $eskisifre.$dogumyili."2018";
$wp["210"] = $eskisifre.$dogumyili."2019";
$wp["211"] = $eskisifre.$dogumyili.$lakap;
$wp["212"] = $eskisifre.$dogumyili.$anne;
$wp["213"] = $eskisifre.$dogumyili.$baba;
$wp["214"] = $eskisifre.$dogumyili.$kardes;
$wp["215"] = $eskisifre.$dogumyili.$sevgili;
$wp["216"] = $eskisifre.$dogumyili.$dogumyili;
$wp["217"] = $eskisifre.$dogumyili.$dogumyili;
$wp["218"] = $eskisifre.$dogumyili.$dogumyili;
$wp["219"] = $eskisifre.$dogumyili.$cikmayili;
$wp["220"] = $eskisifre.$dogumyili.$cikmatarihi;
$wp["221"] = $eskisifre.$dogumyili.$sehir;
$wp["222"] = $eskisifre.$dogumyili.$takim;
$wp["223"] = $eskisifre.$dogumyili.$takimtarihi;
$wp["224"] = $eskisifre.$dogumyili.$takimkisa;
$wp["225"] = $eskisifre.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $eskisifre.$cikmayili;
$wp["227"] = $eskisifre.$cikmayili."123";
$wp["228"] = $eskisifre.$cikmayili."1905";
$wp["229"] = $eskisifre.$cikmayili."1907";
$wp["230"] = $eskisifre.$cikmayili."1903";
$wp["231"] = $eskisifre.$cikmayili."1938";
$wp["232"] = $eskisifre.$cikmayili."1919";
$wp["233"] = $eskisifre.$cikmayili."1881";
$wp["234"] = $eskisifre.$cikmayili."2018";
$wp["235"] = $eskisifre.$cikmayili."2019";
$wp["236"] = $eskisifre.$cikmayili.$lakap;
$wp["237"] = $eskisifre.$cikmayili.$anne;
$wp["238"] = $eskisifre.$cikmayili.$baba;
$wp["239"] = $eskisifre.$cikmayili.$kardes;
$wp["240"] = $eskisifre.$cikmayili.$sevgili;
$wp["241"] = $eskisifre.$cikmayili.$cikmayili;
$wp["242"] = $eskisifre.$cikmayili.$dogumyili;
$wp["243"] = $eskisifre.$cikmayili.$cikmayili;
$wp["244"] = $eskisifre.$cikmayili.$cikmayili;
$wp["245"] = $eskisifre.$cikmayili.$cikmatarihi;
$wp["246"] = $eskisifre.$cikmayili.$sehir;
$wp["247"] = $eskisifre.$cikmayili.$takim;
$wp["248"] = $eskisifre.$cikmayili.$takimtarihi;
$wp["249"] = $eskisifre.$cikmayili.$takimkisa;
$wp["250"] = $eskisifre.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $eskisifre.$cikmatarihi;
$wp["252"] = $eskisifre.$cikmatarihi."123";
$wp["253"] = $eskisifre.$cikmatarihi."1905";
$wp["254"] = $eskisifre.$cikmatarihi."1907";
$wp["255"] = $eskisifre.$cikmatarihi."1903";
$wp["256"] = $eskisifre.$cikmatarihi."1938";
$wp["257"] = $eskisifre.$cikmatarihi."1919";
$wp["258"] = $eskisifre.$cikmatarihi."1881";
$wp["259"] = $eskisifre.$cikmatarihi."2018";
$wp["260"] = $eskisifre.$cikmatarihi."2019";
$wp["261"] = $eskisifre.$cikmatarihi.$lakap;
$wp["262"] = $eskisifre.$cikmatarihi.$anne;
$wp["263"] = $eskisifre.$cikmatarihi.$baba;
$wp["264"] = $eskisifre.$cikmatarihi.$kardes;
$wp["265"] = $eskisifre.$cikmatarihi.$sevgili;
$wp["267"] = $eskisifre.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $eskisifre.$cikmatarihi.$dogumtarihi;
$wp["269"] = $eskisifre.$cikmatarihi.$dogumyili;
$wp["270"] = $eskisifre.$cikmatarihi.$cikmayili;
$wp["271"] = $eskisifre.$cikmatarihi.$cikmatarihi;
$wp["272"] = $eskisifre.$cikmatarihi.$sehir;
$wp["273"] = $eskisifre.$cikmatarihi.$takim;
$wp["274"] = $eskisifre.$cikmatarihi.$takimtarihi;
$wp["275"] = $eskisifre.$cikmatarihi.$takimkisa;
$wp["266"] = $eskisifre.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $eskisifre.$sehir;
$wp["277"] = $eskisifre.$sehir."123";
$wp["278"] = $eskisifre.$sehir."1905";
$wp["279"] = $eskisifre.$sehir."1907";
$wp["280"] = $eskisifre.$sehir."1903";
$wp["281"] = $eskisifre.$sehir."1938";
$wp["282"] = $eskisifre.$sehir."1919";
$wp["283"] = $eskisifre.$sehir."1881";
$wp["284"] = $eskisifre.$sehir."2018";
$wp["285"] = $eskisifre.$sehir."2019";
$wp["286"] = $eskisifre.$sehir.$lakap;
$wp["287"] = $eskisifre.$sehir.$anne;
$wp["288"] = $eskisifre.$sehir.$baba;
$wp["289"] = $eskisifre.$sehir.$kardes;
$wp["290"] = $eskisifre.$sehir.$sevgili;
$wp["291"] = $eskisifre.$sehir.$sevgilisoyad;
$wp["292"] = $eskisifre.$sehir.$dogumtarihi;
$wp["293"] = $eskisifre.$sehir.$dogumyili;
$wp["294"] = $eskisifre.$sehir.$cikmayili;
$wp["295"] = $eskisifre.$sehir.$cikmatarihi;
$wp["296"] = $eskisifre.$sehir.$sehir;
$wp["297"] = $eskisifre.$sehir.$takim;
$wp["298"] = $eskisifre.$sehir.$takimtarihi;
$wp["299"] = $eskisifre.$sehir.$takimkisa;
$wp["300"] = $eskisifre.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $eskisifre.$takim;
$wp["302"] = $eskisifre.$takim."123";
$wp["303"] = $eskisifre.$takim."1905";
$wp["304"] = $eskisifre.$takim."1907";
$wp["305"] = $eskisifre.$takim."1903";
$wp["306"] = $eskisifre.$takim."1938";
$wp["307"] = $eskisifre.$takim."1919";
$wp["308"] = $eskisifre.$takim."1881";
$wp["309"] = $eskisifre.$takim."2018";
$wp["310"] = $eskisifre.$takim."2019";
$wp["311"] = $eskisifre.$takim.$lakap;
$wp["312"] = $eskisifre.$takim.$anne;
$wp["313"] = $eskisifre.$takim.$baba;
$wp["314"] = $eskisifre.$takim.$kardes;
$wp["315"] = $eskisifre.$takim.$sevgili;
$wp["316"] = $eskisifre.$takim.$sevgilisoyad;
$wp["317"] = $eskisifre.$takim.$dogumtarihi;
$wp["318"] = $eskisifre.$takim.$dogumyili;
$wp["319"] = $eskisifre.$takim.$cikmayili;
$wp["320"] = $eskisifre.$takim.$cikmatarihi;
$wp["321"] = $eskisifre.$takim.$sehir;
$wp["322"] = $eskisifre.$takim.$takim;
$wp["323"] = $eskisifre.$takim.$takimtarihi;
$wp["324"] = $eskisifre.$takim.$takimkisa;
$wp["325"] = $eskisifre.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $eskisifre.$takimtarihi;
$wp["327"] = $eskisifre.$takimtarihi."123";
$wp["328"] = $eskisifre.$takimtarihi."1905";
$wp["329"] = $eskisifre.$takimtarihi."1907";
$wp["330"] = $eskisifre.$takimtarihi."1903";
$wp["331"] = $eskisifre.$takimtarihi."1938";
$wp["332"] = $eskisifre.$takimtarihi."1919";
$wp["333"] = $eskisifre.$takimtarihi."1881";
$wp["334"] = $eskisifre.$takimtarihi."2018";
$wp["335"] = $eskisifre.$takimtarihi."2019";
$wp["336"] = $eskisifre.$takimtarihi.$lakap;
$wp["337"] = $eskisifre.$takimtarihi.$anne;
$wp["338"] = $eskisifre.$takimtarihi.$baba;
$wp["339"] = $eskisifre.$takimtarihi.$kardes;
$wp["340"] = $eskisifre.$takimtarihi.$sevgili;
$wp["341"] = $eskisifre.$takimtarihi.$sevgilisoyad;
$wp["342"] = $eskisifre.$takimtarihi.$dogumtarihi;
$wp["343"] = $eskisifre.$takimtarihi.$dogumyili;
$wp["344"] = $eskisifre.$takimtarihi.$cikmayili;
$wp["345"] = $eskisifre.$takimtarihi.$cikmatarihi;
$wp["346"] = $eskisifre.$takimtarihi.$sehir;
$wp["347"] = $eskisifre.$takimtarihi.$takim;
$wp["348"] = $eskisifre.$takimtarihi.$takimtarihi;
$wp["349"] = $eskisifre.$takimtarihi.$takimkisa;
$wp["350"] = $eskisifre.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $eskisifre.$takimkisa;
$wp["352"] = $eskisifre.$takimkisa."123";
$wp["353"] = $eskisifre.$takimkisa."1905";
$wp["354"] = $eskisifre.$takimkisa."1907";
$wp["355"] = $eskisifre.$takimkisa."1903";
$wp["356"] = $eskisifre.$takimkisa."1938";
$wp["357"] = $eskisifre.$takimkisa."1919";
$wp["358"] = $eskisifre.$takimkisa."1881";
$wp["359"] = $eskisifre.$takimkisa."2018";
$wp["360"] = $eskisifre.$takimkisa."2019";
$wp["361"] = $eskisifre.$takimkisa.$lakap;
$wp["362"] = $eskisifre.$takimkisa.$anne;
$wp["363"] = $eskisifre.$takimkisa.$baba;
$wp["364"] = $eskisifre.$takimkisa.$kardes;
$wp["365"] = $eskisifre.$takimkisa.$sevgili;
$wp["366"] = $eskisifre.$takimkisa.$sevgilisoyad;
$wp["367"] = $eskisifre.$takimkisa.$dogumtarihi;
$wp["368"] = $eskisifre.$takimkisa.$dogumyili;
$wp["369"] = $eskisifre.$takimkisa.$cikmayili;
$wp["370"] = $eskisifre.$takimkisa.$cikmatarihi;
$wp["371"] = $eskisifre.$takimkisa.$sehir;
$wp["372"] = $eskisifre.$takimkisa.$takim;
$wp["373"] = $eskisifre.$takimkisa.$takimtarihi;
$wp["374"] = $eskisifre.$takimkisa.$takimkisa;
$wp["375"] = $eskisifre.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $eskisifre.$plaka;
$wp["377"] = $eskisifre.$plaka."123";
$wp["378"] = $eskisifre.$plaka."1905";
$wp["379"] = $eskisifre.$plaka."1907";
$wp["380"] = $eskisifre.$plaka."1903";
$wp["381"] = $eskisifre.$plaka."1938";
$wp["382"] = $eskisifre.$plaka."1919";
$wp["383"] = $eskisifre.$plaka."1881";
$wp["384"] = $eskisifre.$plaka."2018";
$wp["385"] = $eskisifre.$plaka."2019";
$wp["386"] = $eskisifre.$plaka.$lakap;
$wp["387"] = $eskisifre.$plaka.$anne;
$wp["388"] = $eskisifre.$plaka.$baba;
$wp["389"] = $eskisifre.$plaka.$kardes;
$wp["390"] = $eskisifre.$plaka.$sevgili;
$wp["391"] = $eskisifre.$plaka.$sevgilisoyad;
$wp["392"] = $eskisifre.$plaka.$dogumtarihi;
$wp["393"] = $eskisifre.$plaka.$dogumyili;
$wp["394"] = $eskisifre.$plaka.$cikmayili;
$wp["395"] = $eskisifre.$plaka.$cikmatarihi;
$wp["396"] = $eskisifre.$plaka.$sehir;
$wp["397"] = $eskisifre.$plaka.$takim;
$wp["398"] = $eskisifre.$plaka.$takimtarihi;
$wp["399"] = $eskisifre.$plaka.$takimkisa;
$wp["400"] = $eskisifre.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $eskisifre.$eskisifre;
$wp["402"] = $eskisifre.$eskisifre."123";
$wp["403"] = $eskisifre.$eskisifre."1905";
$wp["404"] = $eskisifre.$eskisifre."1907";
$wp["405"] = $eskisifre.$eskisifre."1903";
$wp["406"] = $eskisifre.$eskisifre."1938";
$wp["407"] = $eskisifre.$eskisifre."1919";
$wp["408"] = $eskisifre.$eskisifre."1881";
$wp["409"] = $eskisifre.$eskisifre."2018";
$wp["410"] = $eskisifre.$eskisifre."2019";
$wp["411"] = $eskisifre.$eskisifre.$lakap;
$wp["412"] = $eskisifre.$eskisifre.$anne;
$wp["413"] = $eskisifre.$eskisifre.$baba;
$wp["414"] = $eskisifre.$eskisifre.$kardes;
$wp["415"] = $eskisifre.$eskisifre.$sevgili;
$wp["416"] = $eskisifre.$eskisifre.$sevgilisoyad;
$wp["417"] = $eskisifre.$eskisifre.$dogumtarihi;
$wp["418"] = $eskisifre.$eskisifre.$dogumyili;
$wp["419"] = $eskisifre.$eskisifre.$cikmayili;
$wp["420"] = $eskisifre.$eskisifre.$cikmatarihi;
$wp["421"] = $eskisifre.$eskisifre.$sehir;
$wp["422"] = $eskisifre.$eskisifre.$takim;
$wp["423"] = $eskisifre.$eskisifre.$takimtarihi;
$wp["424"] = $eskisifre.$eskisifre.$takimkisa;
$wp["425"] = $eskisifre.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $eskisifre.$tel;
$wp["427"] = $eskisifre.$tel."123";
$wp["428"] = $eskisifre.$tel."1905";
$wp["429"] = $eskisifre.$tel."1907";
$wp["430"] = $eskisifre.$tel."1903";
$wp["431"] = $eskisifre.$tel."1938";
$wp["432"] = $eskisifre.$tel."1919";
$wp["433"] = $eskisifre.$tel."1881";
$wp["434"] = $eskisifre.$tel."2018";
$wp["435"] = $eskisifre.$tel."2019";
$wp["436"] = $eskisifre.$tel.$lakap;
$wp["437"] = $eskisifre.$tel.$anne;
$wp["438"] = $eskisifre.$tel.$baba;
$wp["439"] = $eskisifre.$tel.$kardes;
$wp["440"] = $eskisifre.$tel.$sevgili;
$wp["441"] = $eskisifre.$tel.$sevgilisoyad;
$wp["442"] = $eskisifre.$tel.$dogumtarihi;
$wp["443"] = $eskisifre.$tel.$dogumyili;
$wp["444"] = $eskisifre.$tel.$cikmayili;
$wp["445"] = $eskisifre.$tel.$cikmatarihi;
$wp["446"] = $eskisifre.$tel.$sehir;
$wp["447"] = $eskisifre.$tel.$takim;
$wp["448"] = $eskisifre.$tel.$takimtarihi;
$wp["449"] = $eskisifre.$tel.$takimkisa;
$wp["450"] = $eskisifre.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $eskisifre.$annetel;
$wp["452"] = $eskisifre.$annetel."123";
$wp["453"] = $eskisifre.$annetel."1905";
$wp["454"] = $eskisifre.$annetel."1907";
$wp["455"] = $eskisifre.$annetel."1903";
$wp["456"] = $eskisifre.$annetel."1938";
$wp["457"] = $eskisifre.$annetel."1919";
$wp["458"] = $eskisifre.$annetel."1881";
$wp["459"] = $eskisifre.$annetel."2018";
$wp["460"] = $eskisifre.$annetel."2019";
$wp["461"] = $eskisifre.$annetel.$lakap;
$wp["462"] = $eskisifre.$annetel.$anne;
$wp["463"] = $eskisifre.$annetel.$baba;
$wp["464"] = $eskisifre.$annetel.$kardes;
$wp["465"] = $eskisifre.$annetel.$sevgili;
$wp["466"] = $eskisifre.$annetel.$sevgilisoyad;
$wp["467"] = $eskisifre.$annetel.$dogumtarihi;
$wp["468"] = $eskisifre.$annetel.$dogumyili;
$wp["469"] = $eskisifre.$annetel.$cikmayili;
$wp["470"] = $eskisifre.$annetel.$cikmatarihi;
$wp["471"] = $eskisifre.$annetel.$sehir;
$wp["472"] = $eskisifre.$annetel.$takim;
$wp["473"] = $eskisifre.$annetel.$takimtarihi;
$wp["474"] = $eskisifre.$annetel.$takimkisa;
$wp["475"] = $eskisifre.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $eskisifre.$babatel;
$wp["477"] = $eskisifre.$babatel."123";
$wp["478"] = $eskisifre.$babatel."1905";
$wp["479"] = $eskisifre.$babatel."1907";
$wp["480"] = $eskisifre.$babatel."1903";
$wp["481"] = $eskisifre.$babatel."1938";
$wp["482"] = $eskisifre.$babatel."1919";
$wp["483"] = $eskisifre.$babatel."1881";
$wp["484"] = $eskisifre.$babatel."2018";
$wp["485"] = $eskisifre.$babatel."2019";
$wp["486"] = $eskisifre.$babatel.$lakap;
$wp["487"] = $eskisifre.$babatel.$anne;
$wp["488"] = $eskisifre.$babatel.$baba;
$wp["489"] = $eskisifre.$babatel.$kardes;
$wp["490"] = $eskisifre.$babatel.$sevgili;
$wp["491"] = $eskisifre.$babatel.$sevgilisoyad;
$wp["492"] = $eskisifre.$babatel.$dogumtarihi;
$wp["493"] = $eskisifre.$babatel.$dogumyili;
$wp["494"] = $eskisifre.$babatel.$cikmayili;
$wp["495"] = $eskisifre.$babatel.$cikmatarihi;
$wp["496"] = $eskisifre.$babatel.$sehir;
$wp["497"] = $eskisifre.$babatel.$takim;
$wp["498"] = $eskisifre.$babatel.$takimtarihi;
$wp["499"] = $eskisifre.$babatel.$takimkisa;
$wp["500"] = $eskisifre.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $eskisifre.$kardestel;
$wp["502"] = $eskisifre.$kardestel."123";
$wp["503"] = $eskisifre.$kardestel."1905";
$wp["504"] = $eskisifre.$kardestel."1907";
$wp["505"] = $eskisifre.$kardestel."1903";
$wp["506"] = $eskisifre.$kardestel."1938";
$wp["507"] = $eskisifre.$kardestel."1919";
$wp["508"] = $eskisifre.$kardestel."1881";
$wp["509"] = $eskisifre.$kardestel."2018";
$wp["510"] = $eskisifre.$kardestel."2019";
$wp["511"] = $eskisifre.$kardestel.$lakap;
$wp["512"] = $eskisifre.$kardestel.$anne;
$wp["513"] = $eskisifre.$kardestel.$baba;
$wp["514"] = $eskisifre.$kardestel.$kardes;
$wp["515"] = $eskisifre.$kardestel.$sevgili;
$wp["516"] = $eskisifre.$kardestel.$sevgilisoyad;
$wp["517"] = $eskisifre.$kardestel.$dogumtarihi;
$wp["518"] = $eskisifre.$kardestel.$dogumyili;
$wp["519"] = $eskisifre.$kardestel.$cikmayili;
$wp["520"] = $eskisifre.$kardestel.$cikmatarihi;
$wp["521"] = $eskisifre.$kardestel.$sehir;
$wp["522"] = $eskisifre.$kardestel.$takim;
$wp["523"] = $eskisifre.$kardestel.$takimtarihi;
$wp["524"] = $eskisifre.$kardestel.$takimkisa;
$wp["525"] = $eskisifre.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $eskisifre.$sevgilitel;
$wp["527"] = $eskisifre.$sevgilitel."123";
$wp["528"] = $eskisifre.$sevgilitel."1905";
$wp["529"] = $eskisifre.$sevgilitel."1907";
$wp["530"] = $eskisifre.$sevgilitel."1903";
$wp["531"] = $eskisifre.$sevgilitel."1938";
$wp["532"] = $eskisifre.$sevgilitel."1919";
$wp["533"] = $eskisifre.$sevgilitel."1881";
$wp["534"] = $eskisifre.$sevgilitel."2018";
$wp["535"] = $eskisifre.$sevgilitel."2019";
$wp["536"] = $eskisifre.$sevgilitel.$lakap;
$wp["537"] = $eskisifre.$sevgilitel.$anne;
$wp["538"] = $eskisifre.$sevgilitel.$baba;
$wp["539"] = $eskisifre.$sevgilitel.$kardes;
$wp["540"] = $eskisifre.$sevgilitel.$sevgili;
$wp["541"] = $eskisifre.$sevgilitel.$sevgilisoyad;
$wp["542"] = $eskisifre.$sevgilitel.$dogumtarihi;
$wp["543"] = $eskisifre.$sevgilitel.$dogumyili;
$wp["544"] = $eskisifre.$sevgilitel.$cikmayili;
$wp["545"] = $eskisifre.$sevgilitel.$cikmatarihi;
$wp["546"] = $eskisifre.$sevgilitel.$sehir;
$wp["547"] = $eskisifre.$sevgilitel.$takim;
$wp["548"] = $eskisifre.$sevgilitel.$takimtarihi;
$wp["549"] = $eskisifre.$sevgilitel.$takimkisa;
$wp["550"] = $eskisifre.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $eskisifre.$tckimlikno;
$wp["552"] = $eskisifre.$tckimlikno."13";
$wp["553"] = $eskisifre.$tckimlikno."1905";
$wp["554"] = $eskisifre.$tckimlikno."1907";
$wp["555"] = $eskisifre.$tckimlikno."1903";
$wp["556"] = $eskisifre.$tckimlikno."1938";
$wp["557"] = $eskisifre.$tckimlikno."1919";
$wp["558"] = $eskisifre.$tckimlikno."1881";
$wp["559"] = $eskisifre.$tckimlikno."2018";
$wp["560"] = $eskisifre.$tckimlikno."2019";
$wp["561"] = $eskisifre.$tckimlikno.$lakap;
$wp["562"] = $eskisifre.$tckimlikno.$anne;
$wp["563"] = $eskisifre.$tckimlikno.$baba;
$wp["564"] = $eskisifre.$tckimlikno.$kardes;
$wp["565"] = $eskisifre.$tckimlikno.$sevgili;
$wp["566"] = $eskisifre.$tckimlikno.$sevgilisoyad;
$wp["567"] = $eskisifre.$tckimlikno.$dogumtarihi;
$wp["568"] = $eskisifre.$tckimlikno.$dogumyili;
$wp["569"] = $eskisifre.$tckimlikno.$cikmayili;
$wp["570"] = $eskisifre.$tckimlikno.$cikmatarihi;
$wp["571"] = $eskisifre.$tckimlikno.$sehir;
$wp["572"] = $eskisifre.$tckimlikno.$takim;
$wp["573"] = $eskisifre.$tckimlikno.$takimtarihi;
$wp["574"] = $eskisifre.$tckimlikno.$takimkisa;
$wp["575"] = $eskisifre.$tckimlikno.$plaka;






for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);


 ?>