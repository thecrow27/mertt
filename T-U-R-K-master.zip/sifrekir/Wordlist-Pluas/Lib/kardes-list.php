<?php 

error_reporting(0);

include "kayit.php";



$wp["1"] = $kardes;
$wp["2"] = $kardes.$soyadad."123";
$wp["3"] = $kardes.$soyadad."1905";
$wp["4"] = $kardes.$soyadad."1907";
$wp["5"] = $kardes.$soyadad."1903";
$wp["6"] = $kardes.$soyadad."1938";
$wp["7"] = $kardes.$soyadad."1919";
$wp["8"] = $kardes.$soyadad."1881";
$wp["9"] = $kardes.$soyadad."2018";
$wp["10"] = $kardes.$soyadad."2019";
$wp["11"] = $kardes.$soyadad.$lakap;
$wp["12"] = $kardes.$soyadad.$anne;
$wp["13"] = $kardes.$soyadad.$baba;
$wp["14"] = $kardes.$soyadad.$kardes;
$wp["15"] = $kardes.$soyadad.$sevgili;
$wp["16"] = $kardes.$soyadad.$sevgilisoyad;
$wp["17"] = $kardes.$soyadad.$dogumtarihi;
$wp["18"] = $kardes.$soyadad.$dogumyili;
$wp["19"] = $kardes.$soyadad.$cikmayili;
$wp["20"] = $kardes.$soyadad.$cikmatarihi;
$wp["21"] = $kardes.$soyadad.$sehir;
$wp["22"] = $kardes.$soyadad.$takim;
$wp["23"] = $kardes.$soyadad.$takimtarihi;
$wp["24"] = $kardes.$soyadad.$takimkisa;
$wp["25"] = $kardes.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $kardes.$lakap;
$wp["27"] = $kardes.$lakap."123";
$wp["28"] = $kardes.$lakap."1905";
$wp["29"] = $kardes.$lakap."1907";
$wp["30"] = $kardes.$lakap."1903";
$wp["31"] = $kardes.$lakap."1938";
$wp["32"] = $kardes.$lakap."1919";
$wp["33"] = $kardes.$lakap."1881";
$wp["34"] = $kardes.$lakap."2018";
$wp["35"] = $kardes.$lakap."2019";
$wp["36"] = $kardes.$lakap.$lakap;
$wp["37"] = $kardes.$lakap.$anne;
$wp["38"] = $kardes.$lakap.$baba;
$wp["39"] = $kardes.$lakap.$kardes;
$wp["40"] = $kardes.$lakap.$sevgili;
$wp["41"] = $kardes.$lakap.$sevgilisoyad;
$wp["42"] = $kardes.$lakap.$dogumtarihi;
$wp["43"] = $kardes.$lakap.$dogumyili;
$wp["44"] = $kardes.$lakap.$cikmayili;
$wp["45"] = $kardes.$lakap.$cikmatarihi;
$wp["46"] = $kardes.$lakap.$sehir;
$wp["47"] = $kardes.$lakap.$takim;
$wp["48"] = $kardes.$lakap.$takimtarihi;
$wp["49"] = $kardes.$lakap.$takimkisa;
$wp["50"] = $kardes.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $kardes.$anne;
$wp["52"] = $kardes.$anne."123";
$wp["53"] = $kardes.$anne."1905";
$wp["54"] = $kardes.$anne."1907";
$wp["55"] = $kardes.$anne."1903";
$wp["56"] = $kardes.$anne."1938";
$wp["57"] = $kardes.$anne."1919";
$wp["58"] = $kardes.$anne."1881";
$wp["59"] = $kardes.$anne."2018";
$wp["60"] = $kardes.$anne."2019";
$wp["61"] = $kardes.$anne.$lakap;
$wp["62"] = $kardes.$anne.$anne;
$wp["63"] = $kardes.$anne.$baba;
$wp["64"] = $kardes.$anne.$kardes;
$wp["65"] = $kardes.$anne.$sevgili;
$wp["66"] = $kardes.$anne.$sevgilisoyad;
$wp["67"] = $kardes.$anne.$dogumtarihi;
$wp["68"] = $kardes.$anne.$dogumyili;
$wp["69"] = $kardes.$anne.$cikmayili;
$wp["70"] = $kardes.$anne.$cikmatarihi;
$wp["71"] = $kardes.$anne.$sehir;
$wp["72"] = $kardes.$anne.$takim;
$wp["73"] = $kardes.$anne.$takimtarihi;
$wp["74"] = $kardes.$anne.$takimkisa;
$wp["75"] = $kardes.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $kardes.$baba;
$wp["77"] = $kardes.$baba."123";
$wp["78"] = $kardes.$baba."1905";
$wp["79"] = $kardes.$baba."1907";
$wp["80"] = $kardes.$baba."1903";
$wp["81"] = $kardes.$baba."1938";
$wp["82"] = $kardes.$baba."1919";
$wp["83"] = $kardes.$baba."1881";
$wp["84"] = $kardes.$baba."2018";
$wp["85"] = $kardes.$baba."2019";
$wp["86"] = $kardes.$baba.$lakap;
$wp["87"] = $kardes.$baba.$anne;
$wp["88"] = $kardes.$baba.$baba;
$wp["89"] = $kardes.$baba.$kardes;
$wp["90"] = $kardes.$baba.$sevgili;
$wp["91"] = $kardes.$baba.$sevgilisoyad;
$wp["92"] = $kardes.$baba.$dogumtarihi;
$wp["93"] = $kardes.$baba.$dogumyili;
$wp["94"] = $kardes.$baba.$cikmayili;
$wp["95"] = $kardes.$baba.$cikmatarihi;
$wp["96"] = $kardes.$baba.$sehir;
$wp["97"] = $kardes.$baba.$takim;
$wp["98"] = $kardes.$baba.$takimtarihi;
$wp["99"] = $kardes.$baba.$takimkisa;
$wp["100"] = $kardes.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $kardes.$kardes;
$wp["102"] = $kardes.$kardes."123";
$wp["103"] = $kardes.$kardes."1905";
$wp["104"] = $kardes.$kardes."1907";
$wp["105"] = $kardes.$kardes."1903";
$wp["106"] = $kardes.$kardes."1938";
$wp["107"] = $kardes.$kardes."1919";
$wp["108"] = $kardes.$kardes."1881";
$wp["109"] = $kardes.$kardes."2018";
$wp["110"] = $kardes.$kardes."2019";
$wp["111"] = $kardes.$kardes.$lakap;
$wp["112"] = $kardes.$kardes.$anne;
$wp["113"] = $kardes.$kardes.$baba;
$wp["114"] = $kardes.$kardes.$kardes;
$wp["115"] = $kardes.$kardes.$sevgili;
$wp["116"] = $kardes.$kardes.$sevgilisoyad;
$wp["117"] = $kardes.$kardes.$dogumtarihi;
$wp["118"] = $kardes.$kardes.$dogumyili;
$wp["119"] = $kardes.$kardes.$cikmayili;
$wp["120"] = $kardes.$kardes.$cikmatarihi;
$wp["121"] = $kardes.$kardes.$sehir;
$wp["122"] = $kardes.$kardes.$takim;
$wp["123"] = $kardes.$kardes.$takimtarihi;
$wp["124"] = $kardes.$kardes.$takimkisa;
$wp["125"] = $kardes.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $kardes.$sevgili;
$wp["127"] = $kardes.$sevgili."123";
$wp["128"] = $kardes.$sevgili."1905";
$wp["129"] = $kardes.$sevgili."1907";
$wp["130"] = $kardes.$sevgili."1903";
$wp["131"] = $kardes.$sevgili."1938";
$wp["132"] = $kardes.$sevgili."1919";
$wp["133"] = $kardes.$sevgili."1881";
$wp["134"] = $kardes.$sevgili."2018";
$wp["135"] = $kardes.$sevgili."2019";
$wp["136"] = $kardes.$sevgili.$lakap;
$wp["137"] = $kardes.$sevgili.$anne;
$wp["138"] = $kardes.$sevgili.$baba;
$wp["139"] = $kardes.$sevgili.$kardes;
$wp["140"] = $kardes.$sevgili.$sevgili;
$wp["141"] = $kardes.$sevgili.$sevgilisoyad;
$wp["142"] = $kardes.$sevgili.$dogumtarihi;
$wp["143"] = $kardes.$sevgili.$dogumyili;
$wp["144"] = $kardes.$sevgili.$cikmayili;
$wp["145"] = $kardes.$sevgili.$cikmatarihi;
$wp["146"] = $kardes.$sevgili.$sehir;
$wp["147"] = $kardes.$sevgili.$takim;
$wp["148"] = $kardes.$sevgili.$takimtarihi;
$wp["149"] = $kardes.$sevgili.$takimkisa;
$wp["150"] = $kardes.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $kardes.$sevgilisoyad;
$wp["152"] = $kardes.$sevgilisoyad."123";
$wp["153"] = $kardes.$sevgilisoyad."1905";
$wp["154"] = $kardes.$sevgilisoyad."1907";
$wp["155"] = $kardes.$sevgilisoyad."1903";
$wp["156"] = $kardes.$sevgilisoyad."1938";
$wp["157"] = $kardes.$sevgilisoyad."1919";
$wp["158"] = $kardes.$sevgilisoyad."1881";
$wp["159"] = $kardes.$sevgilisoyad."2018";
$wp["160"] = $kardes.$sevgilisoyad."2019";
$wp["161"] = $kardes.$sevgilisoyad.$lakap;
$wp["162"] = $kardes.$sevgilisoyad.$anne;
$wp["163"] = $kardes.$sevgilisoyad.$baba;
$wp["164"] = $kardes.$sevgilisoyad.$kardes;
$wp["165"] = $kardes.$sevgilisoyad.$sevgili;
$wp["166"] = $kardes.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $kardes.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $kardes.$sevgilisoyad.$dogumyili;
$wp["169"] = $kardes.$sevgilisoyad.$cikmayili;
$wp["170"] = $kardes.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $kardes.$sevgilisoyad.$sehir;
$wp["172"] = $kardes.$sevgilisoyad.$takim;
$wp["173"] = $kardes.$sevgilisoyad.$takimtarihi;
$wp["174"] = $kardes.$sevgilisoyad.$takimkisa;
$wp["175"] = $kardes.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $kardes.$dogumtarihi;
$wp["177"] = $kardes.$dogumtarihi."123";
$wp["178"] = $kardes.$dogumtarihi."1905";
$wp["179"] = $kardes.$dogumtarihi."1907";
$wp["180"] = $kardes.$dogumtarihi."1903";
$wp["181"] = $kardes.$dogumtarihi."1938";
$wp["200"] = $kardes.$dogumtarihi."1919";
$wp["182"] = $kardes.$dogumtarihi."1881";
$wp["183"] = $kardes.$dogumtarihi."2018";
$wp["184"] = $kardes.$dogumtarihi."2019";
$wp["185"] = $kardes.$dogumtarihi.$lakap;
$wp["186"] = $kardes.$dogumtarihi.$anne;
$wp["187"] = $kardes.$dogumtarihi.$baba;
$wp["188"] = $kardes.$dogumtarihi.$kardes;
$wp["189"] = $kardes.$dogumtarihi.$sevgili;
$wp["190"] = $kardes.$dogumtarihi.$dogumtarihi;
$wp["191"] = $kardes.$dogumtarihi.$dogumtarihi;
$wp["192"] = $kardes.$dogumtarihi.$dogumyili;
$wp["193"] = $kardes.$dogumtarihi.$cikmayili;
$wp["194"] = $kardes.$dogumtarihi.$cikmatarihi;
$wp["195"] = $kardes.$dogumtarihi.$sehir;
$wp["196"] = $kardes.$dogumtarihi.$takim;
$wp["197"] = $kardes.$dogumtarihi.$takimtarihi;
$wp["198"] = $kardes.$dogumtarihi.$takimkisa;
$wp["199"] = $kardes.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $kardes.$dogumyili;
$wp["202"] = $kardes.$dogumyili."123";
$wp["203"] = $kardes.$dogumyili."1905";
$wp["204"] = $kardes.$dogumyili."1907";
$wp["205"] = $kardes.$dogumyili."1903";
$wp["206"] = $kardes.$dogumyili."1938";
$wp["207"] = $kardes.$dogumyili."1919";
$wp["208"] = $kardes.$dogumyili."1881";
$wp["209"] = $kardes.$dogumyili."2018";
$wp["210"] = $kardes.$dogumyili."2019";
$wp["211"] = $kardes.$dogumyili.$lakap;
$wp["212"] = $kardes.$dogumyili.$anne;
$wp["213"] = $kardes.$dogumyili.$baba;
$wp["214"] = $kardes.$dogumyili.$kardes;
$wp["215"] = $kardes.$dogumyili.$sevgili;
$wp["216"] = $kardes.$dogumyili.$dogumyili;
$wp["217"] = $kardes.$dogumyili.$dogumyili;
$wp["218"] = $kardes.$dogumyili.$dogumyili;
$wp["219"] = $kardes.$dogumyili.$cikmayili;
$wp["220"] = $kardes.$dogumyili.$cikmatarihi;
$wp["221"] = $kardes.$dogumyili.$sehir;
$wp["222"] = $kardes.$dogumyili.$takim;
$wp["223"] = $kardes.$dogumyili.$takimtarihi;
$wp["224"] = $kardes.$dogumyili.$takimkisa;
$wp["225"] = $kardes.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $kardes.$cikmayili;
$wp["227"] = $kardes.$cikmayili."123";
$wp["228"] = $kardes.$cikmayili."1905";
$wp["229"] = $kardes.$cikmayili."1907";
$wp["230"] = $kardes.$cikmayili."1903";
$wp["231"] = $kardes.$cikmayili."1938";
$wp["232"] = $kardes.$cikmayili."1919";
$wp["233"] = $kardes.$cikmayili."1881";
$wp["234"] = $kardes.$cikmayili."2018";
$wp["235"] = $kardes.$cikmayili."2019";
$wp["236"] = $kardes.$cikmayili.$lakap;
$wp["237"] = $kardes.$cikmayili.$anne;
$wp["238"] = $kardes.$cikmayili.$baba;
$wp["239"] = $kardes.$cikmayili.$kardes;
$wp["240"] = $kardes.$cikmayili.$sevgili;
$wp["241"] = $kardes.$cikmayili.$cikmayili;
$wp["242"] = $kardes.$cikmayili.$dogumyili;
$wp["243"] = $kardes.$cikmayili.$cikmayili;
$wp["244"] = $kardes.$cikmayili.$cikmayili;
$wp["245"] = $kardes.$cikmayili.$cikmatarihi;
$wp["246"] = $kardes.$cikmayili.$sehir;
$wp["247"] = $kardes.$cikmayili.$takim;
$wp["248"] = $kardes.$cikmayili.$takimtarihi;
$wp["249"] = $kardes.$cikmayili.$takimkisa;
$wp["250"] = $kardes.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $kardes.$cikmatarihi;
$wp["252"] = $kardes.$cikmatarihi."123";
$wp["253"] = $kardes.$cikmatarihi."1905";
$wp["254"] = $kardes.$cikmatarihi."1907";
$wp["255"] = $kardes.$cikmatarihi."1903";
$wp["256"] = $kardes.$cikmatarihi."1938";
$wp["257"] = $kardes.$cikmatarihi."1919";
$wp["258"] = $kardes.$cikmatarihi."1881";
$wp["259"] = $kardes.$cikmatarihi."2018";
$wp["260"] = $kardes.$cikmatarihi."2019";
$wp["261"] = $kardes.$cikmatarihi.$lakap;
$wp["262"] = $kardes.$cikmatarihi.$anne;
$wp["263"] = $kardes.$cikmatarihi.$baba;
$wp["264"] = $kardes.$cikmatarihi.$kardes;
$wp["265"] = $kardes.$cikmatarihi.$sevgili;
$wp["267"] = $kardes.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $kardes.$cikmatarihi.$dogumtarihi;
$wp["269"] = $kardes.$cikmatarihi.$dogumyili;
$wp["270"] = $kardes.$cikmatarihi.$cikmayili;
$wp["271"] = $kardes.$cikmatarihi.$cikmatarihi;
$wp["272"] = $kardes.$cikmatarihi.$sehir;
$wp["273"] = $kardes.$cikmatarihi.$takim;
$wp["274"] = $kardes.$cikmatarihi.$takimtarihi;
$wp["275"] = $kardes.$cikmatarihi.$takimkisa;
$wp["266"] = $kardes.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $kardes.$sehir;
$wp["277"] = $kardes.$sehir."123";
$wp["278"] = $kardes.$sehir."1905";
$wp["279"] = $kardes.$sehir."1907";
$wp["280"] = $kardes.$sehir."1903";
$wp["281"] = $kardes.$sehir."1938";
$wp["282"] = $kardes.$sehir."1919";
$wp["283"] = $kardes.$sehir."1881";
$wp["284"] = $kardes.$sehir."2018";
$wp["285"] = $kardes.$sehir."2019";
$wp["286"] = $kardes.$sehir.$lakap;
$wp["287"] = $kardes.$sehir.$anne;
$wp["288"] = $kardes.$sehir.$baba;
$wp["289"] = $kardes.$sehir.$kardes;
$wp["290"] = $kardes.$sehir.$sevgili;
$wp["291"] = $kardes.$sehir.$sevgilisoyad;
$wp["292"] = $kardes.$sehir.$dogumtarihi;
$wp["293"] = $kardes.$sehir.$dogumyili;
$wp["294"] = $kardes.$sehir.$cikmayili;
$wp["295"] = $kardes.$sehir.$cikmatarihi;
$wp["296"] = $kardes.$sehir.$sehir;
$wp["297"] = $kardes.$sehir.$takim;
$wp["298"] = $kardes.$sehir.$takimtarihi;
$wp["299"] = $kardes.$sehir.$takimkisa;
$wp["300"] = $kardes.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $kardes.$takim;
$wp["302"] = $kardes.$takim."123";
$wp["303"] = $kardes.$takim."1905";
$wp["304"] = $kardes.$takim."1907";
$wp["305"] = $kardes.$takim."1903";
$wp["306"] = $kardes.$takim."1938";
$wp["307"] = $kardes.$takim."1919";
$wp["308"] = $kardes.$takim."1881";
$wp["309"] = $kardes.$takim."2018";
$wp["310"] = $kardes.$takim."2019";
$wp["311"] = $kardes.$takim.$lakap;
$wp["312"] = $kardes.$takim.$anne;
$wp["313"] = $kardes.$takim.$baba;
$wp["314"] = $kardes.$takim.$kardes;
$wp["315"] = $kardes.$takim.$sevgili;
$wp["316"] = $kardes.$takim.$sevgilisoyad;
$wp["317"] = $kardes.$takim.$dogumtarihi;
$wp["318"] = $kardes.$takim.$dogumyili;
$wp["319"] = $kardes.$takim.$cikmayili;
$wp["320"] = $kardes.$takim.$cikmatarihi;
$wp["321"] = $kardes.$takim.$sehir;
$wp["322"] = $kardes.$takim.$takim;
$wp["323"] = $kardes.$takim.$takimtarihi;
$wp["324"] = $kardes.$takim.$takimkisa;
$wp["325"] = $kardes.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $kardes.$takimtarihi;
$wp["327"] = $kardes.$takimtarihi."123";
$wp["328"] = $kardes.$takimtarihi."1905";
$wp["329"] = $kardes.$takimtarihi."1907";
$wp["330"] = $kardes.$takimtarihi."1903";
$wp["331"] = $kardes.$takimtarihi."1938";
$wp["332"] = $kardes.$takimtarihi."1919";
$wp["333"] = $kardes.$takimtarihi."1881";
$wp["334"] = $kardes.$takimtarihi."2018";
$wp["335"] = $kardes.$takimtarihi."2019";
$wp["336"] = $kardes.$takimtarihi.$lakap;
$wp["337"] = $kardes.$takimtarihi.$anne;
$wp["338"] = $kardes.$takimtarihi.$baba;
$wp["339"] = $kardes.$takimtarihi.$kardes;
$wp["340"] = $kardes.$takimtarihi.$sevgili;
$wp["341"] = $kardes.$takimtarihi.$sevgilisoyad;
$wp["342"] = $kardes.$takimtarihi.$dogumtarihi;
$wp["343"] = $kardes.$takimtarihi.$dogumyili;
$wp["344"] = $kardes.$takimtarihi.$cikmayili;
$wp["345"] = $kardes.$takimtarihi.$cikmatarihi;
$wp["346"] = $kardes.$takimtarihi.$sehir;
$wp["347"] = $kardes.$takimtarihi.$takim;
$wp["348"] = $kardes.$takimtarihi.$takimtarihi;
$wp["349"] = $kardes.$takimtarihi.$takimkisa;
$wp["350"] = $kardes.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $kardes.$takimkisa;
$wp["352"] = $kardes.$takimkisa."123";
$wp["353"] = $kardes.$takimkisa."1905";
$wp["354"] = $kardes.$takimkisa."1907";
$wp["355"] = $kardes.$takimkisa."1903";
$wp["356"] = $kardes.$takimkisa."1938";
$wp["357"] = $kardes.$takimkisa."1919";
$wp["358"] = $kardes.$takimkisa."1881";
$wp["359"] = $kardes.$takimkisa."2018";
$wp["360"] = $kardes.$takimkisa."2019";
$wp["361"] = $kardes.$takimkisa.$lakap;
$wp["362"] = $kardes.$takimkisa.$anne;
$wp["363"] = $kardes.$takimkisa.$baba;
$wp["364"] = $kardes.$takimkisa.$kardes;
$wp["365"] = $kardes.$takimkisa.$sevgili;
$wp["366"] = $kardes.$takimkisa.$sevgilisoyad;
$wp["367"] = $kardes.$takimkisa.$dogumtarihi;
$wp["368"] = $kardes.$takimkisa.$dogumyili;
$wp["369"] = $kardes.$takimkisa.$cikmayili;
$wp["370"] = $kardes.$takimkisa.$cikmatarihi;
$wp["371"] = $kardes.$takimkisa.$sehir;
$wp["372"] = $kardes.$takimkisa.$takim;
$wp["373"] = $kardes.$takimkisa.$takimtarihi;
$wp["374"] = $kardes.$takimkisa.$takimkisa;
$wp["375"] = $kardes.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $kardes.$plaka;
$wp["377"] = $kardes.$plaka."123";
$wp["378"] = $kardes.$plaka."1905";
$wp["379"] = $kardes.$plaka."1907";
$wp["380"] = $kardes.$plaka."1903";
$wp["381"] = $kardes.$plaka."1938";
$wp["382"] = $kardes.$plaka."1919";
$wp["383"] = $kardes.$plaka."1881";
$wp["384"] = $kardes.$plaka."2018";
$wp["385"] = $kardes.$plaka."2019";
$wp["386"] = $kardes.$plaka.$lakap;
$wp["387"] = $kardes.$plaka.$anne;
$wp["388"] = $kardes.$plaka.$baba;
$wp["389"] = $kardes.$plaka.$kardes;
$wp["390"] = $kardes.$plaka.$sevgili;
$wp["391"] = $kardes.$plaka.$sevgilisoyad;
$wp["392"] = $kardes.$plaka.$dogumtarihi;
$wp["393"] = $kardes.$plaka.$dogumyili;
$wp["394"] = $kardes.$plaka.$cikmayili;
$wp["395"] = $kardes.$plaka.$cikmatarihi;
$wp["396"] = $kardes.$plaka.$sehir;
$wp["397"] = $kardes.$plaka.$takim;
$wp["398"] = $kardes.$plaka.$takimtarihi;
$wp["399"] = $kardes.$plaka.$takimkisa;
$wp["400"] = $kardes.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $kardes.$eskisifre;
$wp["402"] = $kardes.$eskisifre."123";
$wp["403"] = $kardes.$eskisifre."1905";
$wp["404"] = $kardes.$eskisifre."1907";
$wp["405"] = $kardes.$eskisifre."1903";
$wp["406"] = $kardes.$eskisifre."1938";
$wp["407"] = $kardes.$eskisifre."1919";
$wp["408"] = $kardes.$eskisifre."1881";
$wp["409"] = $kardes.$eskisifre."2018";
$wp["410"] = $kardes.$eskisifre."2019";
$wp["411"] = $kardes.$eskisifre.$lakap;
$wp["412"] = $kardes.$eskisifre.$anne;
$wp["413"] = $kardes.$eskisifre.$baba;
$wp["414"] = $kardes.$eskisifre.$kardes;
$wp["415"] = $kardes.$eskisifre.$sevgili;
$wp["416"] = $kardes.$eskisifre.$sevgilisoyad;
$wp["417"] = $kardes.$eskisifre.$dogumtarihi;
$wp["418"] = $kardes.$eskisifre.$dogumyili;
$wp["419"] = $kardes.$eskisifre.$cikmayili;
$wp["420"] = $kardes.$eskisifre.$cikmatarihi;
$wp["421"] = $kardes.$eskisifre.$sehir;
$wp["422"] = $kardes.$eskisifre.$takim;
$wp["423"] = $kardes.$eskisifre.$takimtarihi;
$wp["424"] = $kardes.$eskisifre.$takimkisa;
$wp["425"] = $kardes.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $kardes.$tel;
$wp["427"] = $kardes.$tel."123";
$wp["428"] = $kardes.$tel."1905";
$wp["429"] = $kardes.$tel."1907";
$wp["430"] = $kardes.$tel."1903";
$wp["431"] = $kardes.$tel."1938";
$wp["432"] = $kardes.$tel."1919";
$wp["433"] = $kardes.$tel."1881";
$wp["434"] = $kardes.$tel."2018";
$wp["435"] = $kardes.$tel."2019";
$wp["436"] = $kardes.$tel.$lakap;
$wp["437"] = $kardes.$tel.$anne;
$wp["438"] = $kardes.$tel.$baba;
$wp["439"] = $kardes.$tel.$kardes;
$wp["440"] = $kardes.$tel.$sevgili;
$wp["441"] = $kardes.$tel.$sevgilisoyad;
$wp["442"] = $kardes.$tel.$dogumtarihi;
$wp["443"] = $kardes.$tel.$dogumyili;
$wp["444"] = $kardes.$tel.$cikmayili;
$wp["445"] = $kardes.$tel.$cikmatarihi;
$wp["446"] = $kardes.$tel.$sehir;
$wp["447"] = $kardes.$tel.$takim;
$wp["448"] = $kardes.$tel.$takimtarihi;
$wp["449"] = $kardes.$tel.$takimkisa;
$wp["450"] = $kardes.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $kardes.$annetel;
$wp["452"] = $kardes.$annetel."123";
$wp["453"] = $kardes.$annetel."1905";
$wp["454"] = $kardes.$annetel."1907";
$wp["455"] = $kardes.$annetel."1903";
$wp["456"] = $kardes.$annetel."1938";
$wp["457"] = $kardes.$annetel."1919";
$wp["458"] = $kardes.$annetel."1881";
$wp["459"] = $kardes.$annetel."2018";
$wp["460"] = $kardes.$annetel."2019";
$wp["461"] = $kardes.$annetel.$lakap;
$wp["462"] = $kardes.$annetel.$anne;
$wp["463"] = $kardes.$annetel.$baba;
$wp["464"] = $kardes.$annetel.$kardes;
$wp["465"] = $kardes.$annetel.$sevgili;
$wp["466"] = $kardes.$annetel.$sevgilisoyad;
$wp["467"] = $kardes.$annetel.$dogumtarihi;
$wp["468"] = $kardes.$annetel.$dogumyili;
$wp["469"] = $kardes.$annetel.$cikmayili;
$wp["470"] = $kardes.$annetel.$cikmatarihi;
$wp["471"] = $kardes.$annetel.$sehir;
$wp["472"] = $kardes.$annetel.$takim;
$wp["473"] = $kardes.$annetel.$takimtarihi;
$wp["474"] = $kardes.$annetel.$takimkisa;
$wp["475"] = $kardes.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $kardes.$babatel;
$wp["477"] = $kardes.$babatel."123";
$wp["478"] = $kardes.$babatel."1905";
$wp["479"] = $kardes.$babatel."1907";
$wp["480"] = $kardes.$babatel."1903";
$wp["481"] = $kardes.$babatel."1938";
$wp["482"] = $kardes.$babatel."1919";
$wp["483"] = $kardes.$babatel."1881";
$wp["484"] = $kardes.$babatel."2018";
$wp["485"] = $kardes.$babatel."2019";
$wp["486"] = $kardes.$babatel.$lakap;
$wp["487"] = $kardes.$babatel.$anne;
$wp["488"] = $kardes.$babatel.$baba;
$wp["489"] = $kardes.$babatel.$kardes;
$wp["490"] = $kardes.$babatel.$sevgili;
$wp["491"] = $kardes.$babatel.$sevgilisoyad;
$wp["492"] = $kardes.$babatel.$dogumtarihi;
$wp["493"] = $kardes.$babatel.$dogumyili;
$wp["494"] = $kardes.$babatel.$cikmayili;
$wp["495"] = $kardes.$babatel.$cikmatarihi;
$wp["496"] = $kardes.$babatel.$sehir;
$wp["497"] = $kardes.$babatel.$takim;
$wp["498"] = $kardes.$babatel.$takimtarihi;
$wp["499"] = $kardes.$babatel.$takimkisa;
$wp["500"] = $kardes.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $kardes.$kardestel;
$wp["502"] = $kardes.$kardestel."123";
$wp["503"] = $kardes.$kardestel."1905";
$wp["504"] = $kardes.$kardestel."1907";
$wp["505"] = $kardes.$kardestel."1903";
$wp["506"] = $kardes.$kardestel."1938";
$wp["507"] = $kardes.$kardestel."1919";
$wp["508"] = $kardes.$kardestel."1881";
$wp["509"] = $kardes.$kardestel."2018";
$wp["510"] = $kardes.$kardestel."2019";
$wp["511"] = $kardes.$kardestel.$lakap;
$wp["512"] = $kardes.$kardestel.$anne;
$wp["513"] = $kardes.$kardestel.$baba;
$wp["514"] = $kardes.$kardestel.$kardes;
$wp["515"] = $kardes.$kardestel.$sevgili;
$wp["516"] = $kardes.$kardestel.$sevgilisoyad;
$wp["517"] = $kardes.$kardestel.$dogumtarihi;
$wp["518"] = $kardes.$kardestel.$dogumyili;
$wp["519"] = $kardes.$kardestel.$cikmayili;
$wp["520"] = $kardes.$kardestel.$cikmatarihi;
$wp["521"] = $kardes.$kardestel.$sehir;
$wp["522"] = $kardes.$kardestel.$takim;
$wp["523"] = $kardes.$kardestel.$takimtarihi;
$wp["524"] = $kardes.$kardestel.$takimkisa;
$wp["525"] = $kardes.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $kardes.$sevgilitel;
$wp["527"] = $kardes.$sevgilitel."123";
$wp["528"] = $kardes.$sevgilitel."1905";
$wp["529"] = $kardes.$sevgilitel."1907";
$wp["530"] = $kardes.$sevgilitel."1903";
$wp["531"] = $kardes.$sevgilitel."1938";
$wp["532"] = $kardes.$sevgilitel."1919";
$wp["533"] = $kardes.$sevgilitel."1881";
$wp["534"] = $kardes.$sevgilitel."2018";
$wp["535"] = $kardes.$sevgilitel."2019";
$wp["536"] = $kardes.$sevgilitel.$lakap;
$wp["537"] = $kardes.$sevgilitel.$anne;
$wp["538"] = $kardes.$sevgilitel.$baba;
$wp["539"] = $kardes.$sevgilitel.$kardes;
$wp["540"] = $kardes.$sevgilitel.$sevgili;
$wp["541"] = $kardes.$sevgilitel.$sevgilisoyad;
$wp["542"] = $kardes.$sevgilitel.$dogumtarihi;
$wp["543"] = $kardes.$sevgilitel.$dogumyili;
$wp["544"] = $kardes.$sevgilitel.$cikmayili;
$wp["545"] = $kardes.$sevgilitel.$cikmatarihi;
$wp["546"] = $kardes.$sevgilitel.$sehir;
$wp["547"] = $kardes.$sevgilitel.$takim;
$wp["548"] = $kardes.$sevgilitel.$takimtarihi;
$wp["549"] = $kardes.$sevgilitel.$takimkisa;
$wp["550"] = $kardes.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $kardes.$tckimlikno;
$wp["552"] = $kardes.$tckimlikno."13";
$wp["553"] = $kardes.$tckimlikno."1905";
$wp["554"] = $kardes.$tckimlikno."1907";
$wp["555"] = $kardes.$tckimlikno."1903";
$wp["556"] = $kardes.$tckimlikno."1938";
$wp["557"] = $kardes.$tckimlikno."1919";
$wp["558"] = $kardes.$tckimlikno."1881";
$wp["559"] = $kardes.$tckimlikno."2018";
$wp["560"] = $kardes.$tckimlikno."2019";
$wp["561"] = $kardes.$tckimlikno.$lakap;
$wp["562"] = $kardes.$tckimlikno.$anne;
$wp["563"] = $kardes.$tckimlikno.$baba;
$wp["564"] = $kardes.$tckimlikno.$kardes;
$wp["565"] = $kardes.$tckimlikno.$sevgili;
$wp["566"] = $kardes.$tckimlikno.$sevgilisoyad;
$wp["567"] = $kardes.$tckimlikno.$dogumtarihi;
$wp["568"] = $kardes.$tckimlikno.$dogumyili;
$wp["569"] = $kardes.$tckimlikno.$cikmayili;
$wp["570"] = $kardes.$tckimlikno.$cikmatarihi;
$wp["571"] = $kardes.$tckimlikno.$sehir;
$wp["572"] = $kardes.$tckimlikno.$takim;
$wp["573"] = $kardes.$tckimlikno.$takimtarihi;
$wp["574"] = $kardes.$tckimlikno.$takimkisa;
$wp["575"] = $kardes.$tckimlikno.$plaka;






for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);


 ?>