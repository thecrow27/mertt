<?php 

error_reporting(0);

include "kayit.php";




$wp["1"] = $dogumtarihi;
$wp["2"] = $dogumtarihi.$soyadad."123";
$wp["3"] = $dogumtarihi.$soyadad."1905";
$wp["4"] = $dogumtarihi.$soyadad."1907";
$wp["5"] = $dogumtarihi.$soyadad."1903";
$wp["6"] = $dogumtarihi.$soyadad."1938";
$wp["7"] = $dogumtarihi.$soyadad."1919";
$wp["8"] = $dogumtarihi.$soyadad."1881";
$wp["9"] = $dogumtarihi.$soyadad."2018";
$wp["10"] = $dogumtarihi.$soyadad."2019";
$wp["11"] = $dogumtarihi.$soyadad.$lakap;
$wp["12"] = $dogumtarihi.$soyadad.$anne;
$wp["13"] = $dogumtarihi.$soyadad.$baba;
$wp["14"] = $dogumtarihi.$soyadad.$kardes;
$wp["15"] = $dogumtarihi.$soyadad.$sevgili;
$wp["16"] = $dogumtarihi.$soyadad.$sevgilisoyad;
$wp["17"] = $dogumtarihi.$soyadad.$dogumtarihi;
$wp["18"] = $dogumtarihi.$soyadad.$dogumyili;
$wp["19"] = $dogumtarihi.$soyadad.$cikmayili;
$wp["20"] = $dogumtarihi.$soyadad.$cikmatarihi;
$wp["21"] = $dogumtarihi.$soyadad.$sehir;
$wp["22"] = $dogumtarihi.$soyadad.$takim;
$wp["23"] = $dogumtarihi.$soyadad.$takimtarihi;
$wp["24"] = $dogumtarihi.$soyadad.$takimkisa;
$wp["25"] = $dogumtarihi.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $dogumtarihi.$lakap;
$wp["27"] = $dogumtarihi.$lakap."123";
$wp["28"] = $dogumtarihi.$lakap."1905";
$wp["29"] = $dogumtarihi.$lakap."1907";
$wp["30"] = $dogumtarihi.$lakap."1903";
$wp["31"] = $dogumtarihi.$lakap."1938";
$wp["32"] = $dogumtarihi.$lakap."1919";
$wp["33"] = $dogumtarihi.$lakap."1881";
$wp["34"] = $dogumtarihi.$lakap."2018";
$wp["35"] = $dogumtarihi.$lakap."2019";
$wp["36"] = $dogumtarihi.$lakap.$lakap;
$wp["37"] = $dogumtarihi.$lakap.$anne;
$wp["38"] = $dogumtarihi.$lakap.$baba;
$wp["39"] = $dogumtarihi.$lakap.$kardes;
$wp["40"] = $dogumtarihi.$lakap.$sevgili;
$wp["41"] = $dogumtarihi.$lakap.$sevgilisoyad;
$wp["42"] = $dogumtarihi.$lakap.$dogumtarihi;
$wp["43"] = $dogumtarihi.$lakap.$dogumyili;
$wp["44"] = $dogumtarihi.$lakap.$cikmayili;
$wp["45"] = $dogumtarihi.$lakap.$cikmatarihi;
$wp["46"] = $dogumtarihi.$lakap.$sehir;
$wp["47"] = $dogumtarihi.$lakap.$takim;
$wp["48"] = $dogumtarihi.$lakap.$takimtarihi;
$wp["49"] = $dogumtarihi.$lakap.$takimkisa;
$wp["50"] = $dogumtarihi.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $dogumtarihi.$anne;
$wp["52"] = $dogumtarihi.$anne."123";
$wp["53"] = $dogumtarihi.$anne."1905";
$wp["54"] = $dogumtarihi.$anne."1907";
$wp["55"] = $dogumtarihi.$anne."1903";
$wp["56"] = $dogumtarihi.$anne."1938";
$wp["57"] = $dogumtarihi.$anne."1919";
$wp["58"] = $dogumtarihi.$anne."1881";
$wp["59"] = $dogumtarihi.$anne."2018";
$wp["60"] = $dogumtarihi.$anne."2019";
$wp["61"] = $dogumtarihi.$anne.$lakap;
$wp["62"] = $dogumtarihi.$anne.$anne;
$wp["63"] = $dogumtarihi.$anne.$baba;
$wp["64"] = $dogumtarihi.$anne.$kardes;
$wp["65"] = $dogumtarihi.$anne.$sevgili;
$wp["66"] = $dogumtarihi.$anne.$sevgilisoyad;
$wp["67"] = $dogumtarihi.$anne.$dogumtarihi;
$wp["68"] = $dogumtarihi.$anne.$dogumyili;
$wp["69"] = $dogumtarihi.$anne.$cikmayili;
$wp["70"] = $dogumtarihi.$anne.$cikmatarihi;
$wp["71"] = $dogumtarihi.$anne.$sehir;
$wp["72"] = $dogumtarihi.$anne.$takim;
$wp["73"] = $dogumtarihi.$anne.$takimtarihi;
$wp["74"] = $dogumtarihi.$anne.$takimkisa;
$wp["75"] = $dogumtarihi.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $dogumtarihi.$baba;
$wp["77"] = $dogumtarihi.$baba."123";
$wp["78"] = $dogumtarihi.$baba."1905";
$wp["79"] = $dogumtarihi.$baba."1907";
$wp["80"] = $dogumtarihi.$baba."1903";
$wp["81"] = $dogumtarihi.$baba."1938";
$wp["82"] = $dogumtarihi.$baba."1919";
$wp["83"] = $dogumtarihi.$baba."1881";
$wp["84"] = $dogumtarihi.$baba."2018";
$wp["85"] = $dogumtarihi.$baba."2019";
$wp["86"] = $dogumtarihi.$baba.$lakap;
$wp["87"] = $dogumtarihi.$baba.$anne;
$wp["88"] = $dogumtarihi.$baba.$baba;
$wp["89"] = $dogumtarihi.$baba.$kardes;
$wp["90"] = $dogumtarihi.$baba.$sevgili;
$wp["91"] = $dogumtarihi.$baba.$sevgilisoyad;
$wp["92"] = $dogumtarihi.$baba.$dogumtarihi;
$wp["93"] = $dogumtarihi.$baba.$dogumyili;
$wp["94"] = $dogumtarihi.$baba.$cikmayili;
$wp["95"] = $dogumtarihi.$baba.$cikmatarihi;
$wp["96"] = $dogumtarihi.$baba.$sehir;
$wp["97"] = $dogumtarihi.$baba.$takim;
$wp["98"] = $dogumtarihi.$baba.$takimtarihi;
$wp["99"] = $dogumtarihi.$baba.$takimkisa;
$wp["100"] = $dogumtarihi.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $dogumtarihi.$kardes;
$wp["102"] = $dogumtarihi.$kardes."123";
$wp["103"] = $dogumtarihi.$kardes."1905";
$wp["104"] = $dogumtarihi.$kardes."1907";
$wp["105"] = $dogumtarihi.$kardes."1903";
$wp["106"] = $dogumtarihi.$kardes."1938";
$wp["107"] = $dogumtarihi.$kardes."1919";
$wp["108"] = $dogumtarihi.$kardes."1881";
$wp["109"] = $dogumtarihi.$kardes."2018";
$wp["110"] = $dogumtarihi.$kardes."2019";
$wp["111"] = $dogumtarihi.$kardes.$lakap;
$wp["112"] = $dogumtarihi.$kardes.$anne;
$wp["113"] = $dogumtarihi.$kardes.$baba;
$wp["114"] = $dogumtarihi.$kardes.$kardes;
$wp["115"] = $dogumtarihi.$kardes.$sevgili;
$wp["116"] = $dogumtarihi.$kardes.$sevgilisoyad;
$wp["117"] = $dogumtarihi.$kardes.$dogumtarihi;
$wp["118"] = $dogumtarihi.$kardes.$dogumyili;
$wp["119"] = $dogumtarihi.$kardes.$cikmayili;
$wp["120"] = $dogumtarihi.$kardes.$cikmatarihi;
$wp["121"] = $dogumtarihi.$kardes.$sehir;
$wp["122"] = $dogumtarihi.$kardes.$takim;
$wp["123"] = $dogumtarihi.$kardes.$takimtarihi;
$wp["124"] = $dogumtarihi.$kardes.$takimkisa;
$wp["125"] = $dogumtarihi.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $dogumtarihi.$sevgili;
$wp["127"] = $dogumtarihi.$sevgili."123";
$wp["128"] = $dogumtarihi.$sevgili."1905";
$wp["129"] = $dogumtarihi.$sevgili."1907";
$wp["130"] = $dogumtarihi.$sevgili."1903";
$wp["131"] = $dogumtarihi.$sevgili."1938";
$wp["132"] = $dogumtarihi.$sevgili."1919";
$wp["133"] = $dogumtarihi.$sevgili."1881";
$wp["134"] = $dogumtarihi.$sevgili."2018";
$wp["135"] = $dogumtarihi.$sevgili."2019";
$wp["136"] = $dogumtarihi.$sevgili.$lakap;
$wp["137"] = $dogumtarihi.$sevgili.$anne;
$wp["138"] = $dogumtarihi.$sevgili.$baba;
$wp["139"] = $dogumtarihi.$sevgili.$kardes;
$wp["140"] = $dogumtarihi.$sevgili.$sevgili;
$wp["141"] = $dogumtarihi.$sevgili.$sevgilisoyad;
$wp["142"] = $dogumtarihi.$sevgili.$dogumtarihi;
$wp["143"] = $dogumtarihi.$sevgili.$dogumyili;
$wp["144"] = $dogumtarihi.$sevgili.$cikmayili;
$wp["145"] = $dogumtarihi.$sevgili.$cikmatarihi;
$wp["146"] = $dogumtarihi.$sevgili.$sehir;
$wp["147"] = $dogumtarihi.$sevgili.$takim;
$wp["148"] = $dogumtarihi.$sevgili.$takimtarihi;
$wp["149"] = $dogumtarihi.$sevgili.$takimkisa;
$wp["150"] = $dogumtarihi.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $dogumtarihi.$sevgilisoyad;
$wp["152"] = $dogumtarihi.$sevgilisoyad."123";
$wp["153"] = $dogumtarihi.$sevgilisoyad."1905";
$wp["154"] = $dogumtarihi.$sevgilisoyad."1907";
$wp["155"] = $dogumtarihi.$sevgilisoyad."1903";
$wp["156"] = $dogumtarihi.$sevgilisoyad."1938";
$wp["157"] = $dogumtarihi.$sevgilisoyad."1919";
$wp["158"] = $dogumtarihi.$sevgilisoyad."1881";
$wp["159"] = $dogumtarihi.$sevgilisoyad."2018";
$wp["160"] = $dogumtarihi.$sevgilisoyad."2019";
$wp["161"] = $dogumtarihi.$sevgilisoyad.$lakap;
$wp["162"] = $dogumtarihi.$sevgilisoyad.$anne;
$wp["163"] = $dogumtarihi.$sevgilisoyad.$baba;
$wp["164"] = $dogumtarihi.$sevgilisoyad.$kardes;
$wp["165"] = $dogumtarihi.$sevgilisoyad.$sevgili;
$wp["166"] = $dogumtarihi.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $dogumtarihi.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $dogumtarihi.$sevgilisoyad.$dogumyili;
$wp["169"] = $dogumtarihi.$sevgilisoyad.$cikmayili;
$wp["170"] = $dogumtarihi.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $dogumtarihi.$sevgilisoyad.$sehir;
$wp["172"] = $dogumtarihi.$sevgilisoyad.$takim;
$wp["173"] = $dogumtarihi.$sevgilisoyad.$takimtarihi;
$wp["174"] = $dogumtarihi.$sevgilisoyad.$takimkisa;
$wp["175"] = $dogumtarihi.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $dogumtarihi.$dogumtarihi;
$wp["177"] = $dogumtarihi.$dogumtarihi."123";
$wp["178"] = $dogumtarihi.$dogumtarihi."1905";
$wp["179"] = $dogumtarihi.$dogumtarihi."1907";
$wp["180"] = $dogumtarihi.$dogumtarihi."1903";
$wp["181"] = $dogumtarihi.$dogumtarihi."1938";
$wp["200"] = $dogumtarihi.$dogumtarihi."1919";
$wp["182"] = $dogumtarihi.$dogumtarihi."1881";
$wp["183"] = $dogumtarihi.$dogumtarihi."2018";
$wp["184"] = $dogumtarihi.$dogumtarihi."2019";
$wp["185"] = $dogumtarihi.$dogumtarihi.$lakap;
$wp["186"] = $dogumtarihi.$dogumtarihi.$anne;
$wp["187"] = $dogumtarihi.$dogumtarihi.$baba;
$wp["188"] = $dogumtarihi.$dogumtarihi.$kardes;
$wp["189"] = $dogumtarihi.$dogumtarihi.$sevgili;
$wp["190"] = $dogumtarihi.$dogumtarihi.$dogumtarihi;
$wp["191"] = $dogumtarihi.$dogumtarihi.$dogumtarihi;
$wp["192"] = $dogumtarihi.$dogumtarihi.$dogumyili;
$wp["193"] = $dogumtarihi.$dogumtarihi.$cikmayili;
$wp["194"] = $dogumtarihi.$dogumtarihi.$cikmatarihi;
$wp["195"] = $dogumtarihi.$dogumtarihi.$sehir;
$wp["196"] = $dogumtarihi.$dogumtarihi.$takim;
$wp["197"] = $dogumtarihi.$dogumtarihi.$takimtarihi;
$wp["198"] = $dogumtarihi.$dogumtarihi.$takimkisa;
$wp["199"] = $dogumtarihi.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $dogumtarihi.$dogumyili;
$wp["202"] = $dogumtarihi.$dogumyili."123";
$wp["203"] = $dogumtarihi.$dogumyili."1905";
$wp["204"] = $dogumtarihi.$dogumyili."1907";
$wp["205"] = $dogumtarihi.$dogumyili."1903";
$wp["206"] = $dogumtarihi.$dogumyili."1938";
$wp["207"] = $dogumtarihi.$dogumyili."1919";
$wp["208"] = $dogumtarihi.$dogumyili."1881";
$wp["209"] = $dogumtarihi.$dogumyili."2018";
$wp["210"] = $dogumtarihi.$dogumyili."2019";
$wp["211"] = $dogumtarihi.$dogumyili.$lakap;
$wp["212"] = $dogumtarihi.$dogumyili.$anne;
$wp["213"] = $dogumtarihi.$dogumyili.$baba;
$wp["214"] = $dogumtarihi.$dogumyili.$kardes;
$wp["215"] = $dogumtarihi.$dogumyili.$sevgili;
$wp["216"] = $dogumtarihi.$dogumyili.$dogumyili;
$wp["217"] = $dogumtarihi.$dogumyili.$dogumyili;
$wp["218"] = $dogumtarihi.$dogumyili.$dogumyili;
$wp["219"] = $dogumtarihi.$dogumyili.$cikmayili;
$wp["220"] = $dogumtarihi.$dogumyili.$cikmatarihi;
$wp["221"] = $dogumtarihi.$dogumyili.$sehir;
$wp["222"] = $dogumtarihi.$dogumyili.$takim;
$wp["223"] = $dogumtarihi.$dogumyili.$takimtarihi;
$wp["224"] = $dogumtarihi.$dogumyili.$takimkisa;
$wp["225"] = $dogumtarihi.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $dogumtarihi.$cikmayili;
$wp["227"] = $dogumtarihi.$cikmayili."123";
$wp["228"] = $dogumtarihi.$cikmayili."1905";
$wp["229"] = $dogumtarihi.$cikmayili."1907";
$wp["230"] = $dogumtarihi.$cikmayili."1903";
$wp["231"] = $dogumtarihi.$cikmayili."1938";
$wp["232"] = $dogumtarihi.$cikmayili."1919";
$wp["233"] = $dogumtarihi.$cikmayili."1881";
$wp["234"] = $dogumtarihi.$cikmayili."2018";
$wp["235"] = $dogumtarihi.$cikmayili."2019";
$wp["236"] = $dogumtarihi.$cikmayili.$lakap;
$wp["237"] = $dogumtarihi.$cikmayili.$anne;
$wp["238"] = $dogumtarihi.$cikmayili.$baba;
$wp["239"] = $dogumtarihi.$cikmayili.$kardes;
$wp["240"] = $dogumtarihi.$cikmayili.$sevgili;
$wp["241"] = $dogumtarihi.$cikmayili.$cikmayili;
$wp["242"] = $dogumtarihi.$cikmayili.$dogumyili;
$wp["243"] = $dogumtarihi.$cikmayili.$cikmayili;
$wp["244"] = $dogumtarihi.$cikmayili.$cikmayili;
$wp["245"] = $dogumtarihi.$cikmayili.$cikmatarihi;
$wp["246"] = $dogumtarihi.$cikmayili.$sehir;
$wp["247"] = $dogumtarihi.$cikmayili.$takim;
$wp["248"] = $dogumtarihi.$cikmayili.$takimtarihi;
$wp["249"] = $dogumtarihi.$cikmayili.$takimkisa;
$wp["250"] = $dogumtarihi.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $dogumtarihi.$cikmatarihi;
$wp["252"] = $dogumtarihi.$cikmatarihi."123";
$wp["253"] = $dogumtarihi.$cikmatarihi."1905";
$wp["254"] = $dogumtarihi.$cikmatarihi."1907";
$wp["255"] = $dogumtarihi.$cikmatarihi."1903";
$wp["256"] = $dogumtarihi.$cikmatarihi."1938";
$wp["257"] = $dogumtarihi.$cikmatarihi."1919";
$wp["258"] = $dogumtarihi.$cikmatarihi."1881";
$wp["259"] = $dogumtarihi.$cikmatarihi."2018";
$wp["260"] = $dogumtarihi.$cikmatarihi."2019";
$wp["261"] = $dogumtarihi.$cikmatarihi.$lakap;
$wp["262"] = $dogumtarihi.$cikmatarihi.$anne;
$wp["263"] = $dogumtarihi.$cikmatarihi.$baba;
$wp["264"] = $dogumtarihi.$cikmatarihi.$kardes;
$wp["265"] = $dogumtarihi.$cikmatarihi.$sevgili;
$wp["267"] = $dogumtarihi.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $dogumtarihi.$cikmatarihi.$dogumtarihi;
$wp["269"] = $dogumtarihi.$cikmatarihi.$dogumyili;
$wp["270"] = $dogumtarihi.$cikmatarihi.$cikmayili;
$wp["271"] = $dogumtarihi.$cikmatarihi.$cikmatarihi;
$wp["272"] = $dogumtarihi.$cikmatarihi.$sehir;
$wp["273"] = $dogumtarihi.$cikmatarihi.$takim;
$wp["274"] = $dogumtarihi.$cikmatarihi.$takimtarihi;
$wp["275"] = $dogumtarihi.$cikmatarihi.$takimkisa;
$wp["266"] = $dogumtarihi.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $dogumtarihi.$sehir;
$wp["277"] = $dogumtarihi.$sehir."123";
$wp["278"] = $dogumtarihi.$sehir."1905";
$wp["279"] = $dogumtarihi.$sehir."1907";
$wp["280"] = $dogumtarihi.$sehir."1903";
$wp["281"] = $dogumtarihi.$sehir."1938";
$wp["282"] = $dogumtarihi.$sehir."1919";
$wp["283"] = $dogumtarihi.$sehir."1881";
$wp["284"] = $dogumtarihi.$sehir."2018";
$wp["285"] = $dogumtarihi.$sehir."2019";
$wp["286"] = $dogumtarihi.$sehir.$lakap;
$wp["287"] = $dogumtarihi.$sehir.$anne;
$wp["288"] = $dogumtarihi.$sehir.$baba;
$wp["289"] = $dogumtarihi.$sehir.$kardes;
$wp["290"] = $dogumtarihi.$sehir.$sevgili;
$wp["291"] = $dogumtarihi.$sehir.$sevgilisoyad;
$wp["292"] = $dogumtarihi.$sehir.$dogumtarihi;
$wp["293"] = $dogumtarihi.$sehir.$dogumyili;
$wp["294"] = $dogumtarihi.$sehir.$cikmayili;
$wp["295"] = $dogumtarihi.$sehir.$cikmatarihi;
$wp["296"] = $dogumtarihi.$sehir.$sehir;
$wp["297"] = $dogumtarihi.$sehir.$takim;
$wp["298"] = $dogumtarihi.$sehir.$takimtarihi;
$wp["299"] = $dogumtarihi.$sehir.$takimkisa;
$wp["300"] = $dogumtarihi.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $dogumtarihi.$takim;
$wp["302"] = $dogumtarihi.$takim."123";
$wp["303"] = $dogumtarihi.$takim."1905";
$wp["304"] = $dogumtarihi.$takim."1907";
$wp["305"] = $dogumtarihi.$takim."1903";
$wp["306"] = $dogumtarihi.$takim."1938";
$wp["307"] = $dogumtarihi.$takim."1919";
$wp["308"] = $dogumtarihi.$takim."1881";
$wp["309"] = $dogumtarihi.$takim."2018";
$wp["310"] = $dogumtarihi.$takim."2019";
$wp["311"] = $dogumtarihi.$takim.$lakap;
$wp["312"] = $dogumtarihi.$takim.$anne;
$wp["313"] = $dogumtarihi.$takim.$baba;
$wp["314"] = $dogumtarihi.$takim.$kardes;
$wp["315"] = $dogumtarihi.$takim.$sevgili;
$wp["316"] = $dogumtarihi.$takim.$sevgilisoyad;
$wp["317"] = $dogumtarihi.$takim.$dogumtarihi;
$wp["318"] = $dogumtarihi.$takim.$dogumyili;
$wp["319"] = $dogumtarihi.$takim.$cikmayili;
$wp["320"] = $dogumtarihi.$takim.$cikmatarihi;
$wp["321"] = $dogumtarihi.$takim.$sehir;
$wp["322"] = $dogumtarihi.$takim.$takim;
$wp["323"] = $dogumtarihi.$takim.$takimtarihi;
$wp["324"] = $dogumtarihi.$takim.$takimkisa;
$wp["325"] = $dogumtarihi.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $dogumtarihi.$takimtarihi;
$wp["327"] = $dogumtarihi.$takimtarihi."123";
$wp["328"] = $dogumtarihi.$takimtarihi."1905";
$wp["329"] = $dogumtarihi.$takimtarihi."1907";
$wp["330"] = $dogumtarihi.$takimtarihi."1903";
$wp["331"] = $dogumtarihi.$takimtarihi."1938";
$wp["332"] = $dogumtarihi.$takimtarihi."1919";
$wp["333"] = $dogumtarihi.$takimtarihi."1881";
$wp["334"] = $dogumtarihi.$takimtarihi."2018";
$wp["335"] = $dogumtarihi.$takimtarihi."2019";
$wp["336"] = $dogumtarihi.$takimtarihi.$lakap;
$wp["337"] = $dogumtarihi.$takimtarihi.$anne;
$wp["338"] = $dogumtarihi.$takimtarihi.$baba;
$wp["339"] = $dogumtarihi.$takimtarihi.$kardes;
$wp["340"] = $dogumtarihi.$takimtarihi.$sevgili;
$wp["341"] = $dogumtarihi.$takimtarihi.$sevgilisoyad;
$wp["342"] = $dogumtarihi.$takimtarihi.$dogumtarihi;
$wp["343"] = $dogumtarihi.$takimtarihi.$dogumyili;
$wp["344"] = $dogumtarihi.$takimtarihi.$cikmayili;
$wp["345"] = $dogumtarihi.$takimtarihi.$cikmatarihi;
$wp["346"] = $dogumtarihi.$takimtarihi.$sehir;
$wp["347"] = $dogumtarihi.$takimtarihi.$takim;
$wp["348"] = $dogumtarihi.$takimtarihi.$takimtarihi;
$wp["349"] = $dogumtarihi.$takimtarihi.$takimkisa;
$wp["350"] = $dogumtarihi.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $dogumtarihi.$takimkisa;
$wp["352"] = $dogumtarihi.$takimkisa."123";
$wp["353"] = $dogumtarihi.$takimkisa."1905";
$wp["354"] = $dogumtarihi.$takimkisa."1907";
$wp["355"] = $dogumtarihi.$takimkisa."1903";
$wp["356"] = $dogumtarihi.$takimkisa."1938";
$wp["357"] = $dogumtarihi.$takimkisa."1919";
$wp["358"] = $dogumtarihi.$takimkisa."1881";
$wp["359"] = $dogumtarihi.$takimkisa."2018";
$wp["360"] = $dogumtarihi.$takimkisa."2019";
$wp["361"] = $dogumtarihi.$takimkisa.$lakap;
$wp["362"] = $dogumtarihi.$takimkisa.$anne;
$wp["363"] = $dogumtarihi.$takimkisa.$baba;
$wp["364"] = $dogumtarihi.$takimkisa.$kardes;
$wp["365"] = $dogumtarihi.$takimkisa.$sevgili;
$wp["366"] = $dogumtarihi.$takimkisa.$sevgilisoyad;
$wp["367"] = $dogumtarihi.$takimkisa.$dogumtarihi;
$wp["368"] = $dogumtarihi.$takimkisa.$dogumyili;
$wp["369"] = $dogumtarihi.$takimkisa.$cikmayili;
$wp["370"] = $dogumtarihi.$takimkisa.$cikmatarihi;
$wp["371"] = $dogumtarihi.$takimkisa.$sehir;
$wp["372"] = $dogumtarihi.$takimkisa.$takim;
$wp["373"] = $dogumtarihi.$takimkisa.$takimtarihi;
$wp["374"] = $dogumtarihi.$takimkisa.$takimkisa;
$wp["375"] = $dogumtarihi.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $dogumtarihi.$plaka;
$wp["377"] = $dogumtarihi.$plaka."123";
$wp["378"] = $dogumtarihi.$plaka."1905";
$wp["379"] = $dogumtarihi.$plaka."1907";
$wp["380"] = $dogumtarihi.$plaka."1903";
$wp["381"] = $dogumtarihi.$plaka."1938";
$wp["382"] = $dogumtarihi.$plaka."1919";
$wp["383"] = $dogumtarihi.$plaka."1881";
$wp["384"] = $dogumtarihi.$plaka."2018";
$wp["385"] = $dogumtarihi.$plaka."2019";
$wp["386"] = $dogumtarihi.$plaka.$lakap;
$wp["387"] = $dogumtarihi.$plaka.$anne;
$wp["388"] = $dogumtarihi.$plaka.$baba;
$wp["389"] = $dogumtarihi.$plaka.$kardes;
$wp["390"] = $dogumtarihi.$plaka.$sevgili;
$wp["391"] = $dogumtarihi.$plaka.$sevgilisoyad;
$wp["392"] = $dogumtarihi.$plaka.$dogumtarihi;
$wp["393"] = $dogumtarihi.$plaka.$dogumyili;
$wp["394"] = $dogumtarihi.$plaka.$cikmayili;
$wp["395"] = $dogumtarihi.$plaka.$cikmatarihi;
$wp["396"] = $dogumtarihi.$plaka.$sehir;
$wp["397"] = $dogumtarihi.$plaka.$takim;
$wp["398"] = $dogumtarihi.$plaka.$takimtarihi;
$wp["399"] = $dogumtarihi.$plaka.$takimkisa;
$wp["400"] = $dogumtarihi.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $dogumtarihi.$eskisifre;
$wp["402"] = $dogumtarihi.$eskisifre."123";
$wp["403"] = $dogumtarihi.$eskisifre."1905";
$wp["404"] = $dogumtarihi.$eskisifre."1907";
$wp["405"] = $dogumtarihi.$eskisifre."1903";
$wp["406"] = $dogumtarihi.$eskisifre."1938";
$wp["407"] = $dogumtarihi.$eskisifre."1919";
$wp["408"] = $dogumtarihi.$eskisifre."1881";
$wp["409"] = $dogumtarihi.$eskisifre."2018";
$wp["410"] = $dogumtarihi.$eskisifre."2019";
$wp["411"] = $dogumtarihi.$eskisifre.$lakap;
$wp["412"] = $dogumtarihi.$eskisifre.$anne;
$wp["413"] = $dogumtarihi.$eskisifre.$baba;
$wp["414"] = $dogumtarihi.$eskisifre.$kardes;
$wp["415"] = $dogumtarihi.$eskisifre.$sevgili;
$wp["416"] = $dogumtarihi.$eskisifre.$sevgilisoyad;
$wp["417"] = $dogumtarihi.$eskisifre.$dogumtarihi;
$wp["418"] = $dogumtarihi.$eskisifre.$dogumyili;
$wp["419"] = $dogumtarihi.$eskisifre.$cikmayili;
$wp["420"] = $dogumtarihi.$eskisifre.$cikmatarihi;
$wp["421"] = $dogumtarihi.$eskisifre.$sehir;
$wp["422"] = $dogumtarihi.$eskisifre.$takim;
$wp["423"] = $dogumtarihi.$eskisifre.$takimtarihi;
$wp["424"] = $dogumtarihi.$eskisifre.$takimkisa;
$wp["425"] = $dogumtarihi.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $dogumtarihi.$tel;
$wp["427"] = $dogumtarihi.$tel."123";
$wp["428"] = $dogumtarihi.$tel."1905";
$wp["429"] = $dogumtarihi.$tel."1907";
$wp["430"] = $dogumtarihi.$tel."1903";
$wp["431"] = $dogumtarihi.$tel."1938";
$wp["432"] = $dogumtarihi.$tel."1919";
$wp["433"] = $dogumtarihi.$tel."1881";
$wp["434"] = $dogumtarihi.$tel."2018";
$wp["435"] = $dogumtarihi.$tel."2019";
$wp["436"] = $dogumtarihi.$tel.$lakap;
$wp["437"] = $dogumtarihi.$tel.$anne;
$wp["438"] = $dogumtarihi.$tel.$baba;
$wp["439"] = $dogumtarihi.$tel.$kardes;
$wp["440"] = $dogumtarihi.$tel.$sevgili;
$wp["441"] = $dogumtarihi.$tel.$sevgilisoyad;
$wp["442"] = $dogumtarihi.$tel.$dogumtarihi;
$wp["443"] = $dogumtarihi.$tel.$dogumyili;
$wp["444"] = $dogumtarihi.$tel.$cikmayili;
$wp["445"] = $dogumtarihi.$tel.$cikmatarihi;
$wp["446"] = $dogumtarihi.$tel.$sehir;
$wp["447"] = $dogumtarihi.$tel.$takim;
$wp["448"] = $dogumtarihi.$tel.$takimtarihi;
$wp["449"] = $dogumtarihi.$tel.$takimkisa;
$wp["450"] = $dogumtarihi.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $dogumtarihi.$annetel;
$wp["452"] = $dogumtarihi.$annetel."123";
$wp["453"] = $dogumtarihi.$annetel."1905";
$wp["454"] = $dogumtarihi.$annetel."1907";
$wp["455"] = $dogumtarihi.$annetel."1903";
$wp["456"] = $dogumtarihi.$annetel."1938";
$wp["457"] = $dogumtarihi.$annetel."1919";
$wp["458"] = $dogumtarihi.$annetel."1881";
$wp["459"] = $dogumtarihi.$annetel."2018";
$wp["460"] = $dogumtarihi.$annetel."2019";
$wp["461"] = $dogumtarihi.$annetel.$lakap;
$wp["462"] = $dogumtarihi.$annetel.$anne;
$wp["463"] = $dogumtarihi.$annetel.$baba;
$wp["464"] = $dogumtarihi.$annetel.$kardes;
$wp["465"] = $dogumtarihi.$annetel.$sevgili;
$wp["466"] = $dogumtarihi.$annetel.$sevgilisoyad;
$wp["467"] = $dogumtarihi.$annetel.$dogumtarihi;
$wp["468"] = $dogumtarihi.$annetel.$dogumyili;
$wp["469"] = $dogumtarihi.$annetel.$cikmayili;
$wp["470"] = $dogumtarihi.$annetel.$cikmatarihi;
$wp["471"] = $dogumtarihi.$annetel.$sehir;
$wp["472"] = $dogumtarihi.$annetel.$takim;
$wp["473"] = $dogumtarihi.$annetel.$takimtarihi;
$wp["474"] = $dogumtarihi.$annetel.$takimkisa;
$wp["475"] = $dogumtarihi.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $dogumtarihi.$babatel;
$wp["477"] = $dogumtarihi.$babatel."123";
$wp["478"] = $dogumtarihi.$babatel."1905";
$wp["479"] = $dogumtarihi.$babatel."1907";
$wp["480"] = $dogumtarihi.$babatel."1903";
$wp["481"] = $dogumtarihi.$babatel."1938";
$wp["482"] = $dogumtarihi.$babatel."1919";
$wp["483"] = $dogumtarihi.$babatel."1881";
$wp["484"] = $dogumtarihi.$babatel."2018";
$wp["485"] = $dogumtarihi.$babatel."2019";
$wp["486"] = $dogumtarihi.$babatel.$lakap;
$wp["487"] = $dogumtarihi.$babatel.$anne;
$wp["488"] = $dogumtarihi.$babatel.$baba;
$wp["489"] = $dogumtarihi.$babatel.$kardes;
$wp["490"] = $dogumtarihi.$babatel.$sevgili;
$wp["491"] = $dogumtarihi.$babatel.$sevgilisoyad;
$wp["492"] = $dogumtarihi.$babatel.$dogumtarihi;
$wp["493"] = $dogumtarihi.$babatel.$dogumyili;
$wp["494"] = $dogumtarihi.$babatel.$cikmayili;
$wp["495"] = $dogumtarihi.$babatel.$cikmatarihi;
$wp["496"] = $dogumtarihi.$babatel.$sehir;
$wp["497"] = $dogumtarihi.$babatel.$takim;
$wp["498"] = $dogumtarihi.$babatel.$takimtarihi;
$wp["499"] = $dogumtarihi.$babatel.$takimkisa;
$wp["500"] = $dogumtarihi.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $dogumtarihi.$kardestel;
$wp["502"] = $dogumtarihi.$kardestel."123";
$wp["503"] = $dogumtarihi.$kardestel."1905";
$wp["504"] = $dogumtarihi.$kardestel."1907";
$wp["505"] = $dogumtarihi.$kardestel."1903";
$wp["506"] = $dogumtarihi.$kardestel."1938";
$wp["507"] = $dogumtarihi.$kardestel."1919";
$wp["508"] = $dogumtarihi.$kardestel."1881";
$wp["509"] = $dogumtarihi.$kardestel."2018";
$wp["510"] = $dogumtarihi.$kardestel."2019";
$wp["511"] = $dogumtarihi.$kardestel.$lakap;
$wp["512"] = $dogumtarihi.$kardestel.$anne;
$wp["513"] = $dogumtarihi.$kardestel.$baba;
$wp["514"] = $dogumtarihi.$kardestel.$kardes;
$wp["515"] = $dogumtarihi.$kardestel.$sevgili;
$wp["516"] = $dogumtarihi.$kardestel.$sevgilisoyad;
$wp["517"] = $dogumtarihi.$kardestel.$dogumtarihi;
$wp["518"] = $dogumtarihi.$kardestel.$dogumyili;
$wp["519"] = $dogumtarihi.$kardestel.$cikmayili;
$wp["520"] = $dogumtarihi.$kardestel.$cikmatarihi;
$wp["521"] = $dogumtarihi.$kardestel.$sehir;
$wp["522"] = $dogumtarihi.$kardestel.$takim;
$wp["523"] = $dogumtarihi.$kardestel.$takimtarihi;
$wp["524"] = $dogumtarihi.$kardestel.$takimkisa;
$wp["525"] = $dogumtarihi.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $dogumtarihi.$sevgilitel;
$wp["527"] = $dogumtarihi.$sevgilitel."123";
$wp["528"] = $dogumtarihi.$sevgilitel."1905";
$wp["529"] = $dogumtarihi.$sevgilitel."1907";
$wp["530"] = $dogumtarihi.$sevgilitel."1903";
$wp["531"] = $dogumtarihi.$sevgilitel."1938";
$wp["532"] = $dogumtarihi.$sevgilitel."1919";
$wp["533"] = $dogumtarihi.$sevgilitel."1881";
$wp["534"] = $dogumtarihi.$sevgilitel."2018";
$wp["535"] = $dogumtarihi.$sevgilitel."2019";
$wp["536"] = $dogumtarihi.$sevgilitel.$lakap;
$wp["537"] = $dogumtarihi.$sevgilitel.$anne;
$wp["538"] = $dogumtarihi.$sevgilitel.$baba;
$wp["539"] = $dogumtarihi.$sevgilitel.$kardes;
$wp["540"] = $dogumtarihi.$sevgilitel.$sevgili;
$wp["541"] = $dogumtarihi.$sevgilitel.$sevgilisoyad;
$wp["542"] = $dogumtarihi.$sevgilitel.$dogumtarihi;
$wp["543"] = $dogumtarihi.$sevgilitel.$dogumyili;
$wp["544"] = $dogumtarihi.$sevgilitel.$cikmayili;
$wp["545"] = $dogumtarihi.$sevgilitel.$cikmatarihi;
$wp["546"] = $dogumtarihi.$sevgilitel.$sehir;
$wp["547"] = $dogumtarihi.$sevgilitel.$takim;
$wp["548"] = $dogumtarihi.$sevgilitel.$takimtarihi;
$wp["549"] = $dogumtarihi.$sevgilitel.$takimkisa;
$wp["550"] = $dogumtarihi.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $dogumtarihi.$tckimlikno;
$wp["552"] = $dogumtarihi.$tckimlikno."13";
$wp["553"] = $dogumtarihi.$tckimlikno."1905";
$wp["554"] = $dogumtarihi.$tckimlikno."1907";
$wp["555"] = $dogumtarihi.$tckimlikno."1903";
$wp["556"] = $dogumtarihi.$tckimlikno."1938";
$wp["557"] = $dogumtarihi.$tckimlikno."1919";
$wp["558"] = $dogumtarihi.$tckimlikno."1881";
$wp["559"] = $dogumtarihi.$tckimlikno."2018";
$wp["560"] = $dogumtarihi.$tckimlikno."2019";
$wp["561"] = $dogumtarihi.$tckimlikno.$lakap;
$wp["562"] = $dogumtarihi.$tckimlikno.$anne;
$wp["563"] = $dogumtarihi.$tckimlikno.$baba;
$wp["564"] = $dogumtarihi.$tckimlikno.$kardes;
$wp["565"] = $dogumtarihi.$tckimlikno.$sevgili;
$wp["566"] = $dogumtarihi.$tckimlikno.$sevgilisoyad;
$wp["567"] = $dogumtarihi.$tckimlikno.$dogumtarihi;
$wp["568"] = $dogumtarihi.$tckimlikno.$dogumyili;
$wp["569"] = $dogumtarihi.$tckimlikno.$cikmayili;
$wp["570"] = $dogumtarihi.$tckimlikno.$cikmatarihi;
$wp["571"] = $dogumtarihi.$tckimlikno.$sehir;
$wp["572"] = $dogumtarihi.$tckimlikno.$takim;
$wp["573"] = $dogumtarihi.$tckimlikno.$takimtarihi;
$wp["574"] = $dogumtarihi.$tckimlikno.$takimkisa;
$wp["575"] = $dogumtarihi.$tckimlikno.$plaka;





for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);


 ?>