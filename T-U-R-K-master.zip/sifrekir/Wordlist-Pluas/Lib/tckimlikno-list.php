<?php 

error_reporting(0);

include "kayit.php";




$wp["1"] = $tckimlikno;
$wp["2"] = $tckimlikno.$soyadad."123";
$wp["3"] = $tckimlikno.$soyadad."1905";
$wp["4"] = $tckimlikno.$soyadad."1907";
$wp["5"] = $tckimlikno.$soyadad."1903";
$wp["6"] = $tckimlikno.$soyadad."1938";
$wp["7"] = $tckimlikno.$soyadad."1919";
$wp["8"] = $tckimlikno.$soyadad."1881";
$wp["9"] = $tckimlikno.$soyadad."2018";
$wp["10"] = $tckimlikno.$soyadad."2019";
$wp["11"] = $tckimlikno.$soyadad.$lakap;
$wp["12"] = $tckimlikno.$soyadad.$anne;
$wp["13"] = $tckimlikno.$soyadad.$baba;
$wp["14"] = $tckimlikno.$soyadad.$kardes;
$wp["15"] = $tckimlikno.$soyadad.$sevgili;
$wp["16"] = $tckimlikno.$soyadad.$sevgilisoyad;
$wp["17"] = $tckimlikno.$soyadad.$dogumtarihi;
$wp["18"] = $tckimlikno.$soyadad.$dogumyili;
$wp["19"] = $tckimlikno.$soyadad.$cikmayili;
$wp["20"] = $tckimlikno.$soyadad.$cikmatarihi;
$wp["21"] = $tckimlikno.$soyadad.$sehir;
$wp["22"] = $tckimlikno.$soyadad.$takim;
$wp["23"] = $tckimlikno.$soyadad.$takimtarihi;
$wp["24"] = $tckimlikno.$soyadad.$takimkisa;
$wp["25"] = $tckimlikno.$soyadad.$plaka;



////////////////////////////////////////////////


$wp["26"] = $tckimlikno.$lakap;
$wp["27"] = $tckimlikno.$lakap."123";
$wp["28"] = $tckimlikno.$lakap."1905";
$wp["29"] = $tckimlikno.$lakap."1907";
$wp["30"] = $tckimlikno.$lakap."1903";
$wp["31"] = $tckimlikno.$lakap."1938";
$wp["32"] = $tckimlikno.$lakap."1919";
$wp["33"] = $tckimlikno.$lakap."1881";
$wp["34"] = $tckimlikno.$lakap."2018";
$wp["35"] = $tckimlikno.$lakap."2019";
$wp["36"] = $tckimlikno.$lakap.$lakap;
$wp["37"] = $tckimlikno.$lakap.$anne;
$wp["38"] = $tckimlikno.$lakap.$baba;
$wp["39"] = $tckimlikno.$lakap.$kardes;
$wp["40"] = $tckimlikno.$lakap.$sevgili;
$wp["41"] = $tckimlikno.$lakap.$sevgilisoyad;
$wp["42"] = $tckimlikno.$lakap.$dogumtarihi;
$wp["43"] = $tckimlikno.$lakap.$dogumyili;
$wp["44"] = $tckimlikno.$lakap.$cikmayili;
$wp["45"] = $tckimlikno.$lakap.$cikmatarihi;
$wp["46"] = $tckimlikno.$lakap.$sehir;
$wp["47"] = $tckimlikno.$lakap.$takim;
$wp["48"] = $tckimlikno.$lakap.$takimtarihi;
$wp["49"] = $tckimlikno.$lakap.$takimkisa;
$wp["50"] = $tckimlikno.$lakap.$plaka;



///////////////////////////////////////////////



$wp["51"] = $tckimlikno.$anne;
$wp["52"] = $tckimlikno.$anne."123";
$wp["53"] = $tckimlikno.$anne."1905";
$wp["54"] = $tckimlikno.$anne."1907";
$wp["55"] = $tckimlikno.$anne."1903";
$wp["56"] = $tckimlikno.$anne."1938";
$wp["57"] = $tckimlikno.$anne."1919";
$wp["58"] = $tckimlikno.$anne."1881";
$wp["59"] = $tckimlikno.$anne."2018";
$wp["60"] = $tckimlikno.$anne."2019";
$wp["61"] = $tckimlikno.$anne.$lakap;
$wp["62"] = $tckimlikno.$anne.$anne;
$wp["63"] = $tckimlikno.$anne.$baba;
$wp["64"] = $tckimlikno.$anne.$kardes;
$wp["65"] = $tckimlikno.$anne.$sevgili;
$wp["66"] = $tckimlikno.$anne.$sevgilisoyad;
$wp["67"] = $tckimlikno.$anne.$dogumtarihi;
$wp["68"] = $tckimlikno.$anne.$dogumyili;
$wp["69"] = $tckimlikno.$anne.$cikmayili;
$wp["70"] = $tckimlikno.$anne.$cikmatarihi;
$wp["71"] = $tckimlikno.$anne.$sehir;
$wp["72"] = $tckimlikno.$anne.$takim;
$wp["73"] = $tckimlikno.$anne.$takimtarihi;
$wp["74"] = $tckimlikno.$anne.$takimkisa;
$wp["75"] = $tckimlikno.$anne.$plaka;



//////////////////////////////////////////////////////



$wp["76"] = $tckimlikno.$baba;
$wp["77"] = $tckimlikno.$baba."123";
$wp["78"] = $tckimlikno.$baba."1905";
$wp["79"] = $tckimlikno.$baba."1907";
$wp["80"] = $tckimlikno.$baba."1903";
$wp["81"] = $tckimlikno.$baba."1938";
$wp["82"] = $tckimlikno.$baba."1919";
$wp["83"] = $tckimlikno.$baba."1881";
$wp["84"] = $tckimlikno.$baba."2018";
$wp["85"] = $tckimlikno.$baba."2019";
$wp["86"] = $tckimlikno.$baba.$lakap;
$wp["87"] = $tckimlikno.$baba.$anne;
$wp["88"] = $tckimlikno.$baba.$baba;
$wp["89"] = $tckimlikno.$baba.$kardes;
$wp["90"] = $tckimlikno.$baba.$sevgili;
$wp["91"] = $tckimlikno.$baba.$sevgilisoyad;
$wp["92"] = $tckimlikno.$baba.$dogumtarihi;
$wp["93"] = $tckimlikno.$baba.$dogumyili;
$wp["94"] = $tckimlikno.$baba.$cikmayili;
$wp["95"] = $tckimlikno.$baba.$cikmatarihi;
$wp["96"] = $tckimlikno.$baba.$sehir;
$wp["97"] = $tckimlikno.$baba.$takim;
$wp["98"] = $tckimlikno.$baba.$takimtarihi;
$wp["99"] = $tckimlikno.$baba.$takimkisa;
$wp["100"] = $tckimlikno.$baba.$plaka;



/////////////////////////////////////////////////////



$wp["101"] = $tckimlikno.$kardes;
$wp["102"] = $tckimlikno.$kardes."123";
$wp["103"] = $tckimlikno.$kardes."1905";
$wp["104"] = $tckimlikno.$kardes."1907";
$wp["105"] = $tckimlikno.$kardes."1903";
$wp["106"] = $tckimlikno.$kardes."1938";
$wp["107"] = $tckimlikno.$kardes."1919";
$wp["108"] = $tckimlikno.$kardes."1881";
$wp["109"] = $tckimlikno.$kardes."2018";
$wp["110"] = $tckimlikno.$kardes."2019";
$wp["111"] = $tckimlikno.$kardes.$lakap;
$wp["112"] = $tckimlikno.$kardes.$anne;
$wp["113"] = $tckimlikno.$kardes.$baba;
$wp["114"] = $tckimlikno.$kardes.$kardes;
$wp["115"] = $tckimlikno.$kardes.$sevgili;
$wp["116"] = $tckimlikno.$kardes.$sevgilisoyad;
$wp["117"] = $tckimlikno.$kardes.$dogumtarihi;
$wp["118"] = $tckimlikno.$kardes.$dogumyili;
$wp["119"] = $tckimlikno.$kardes.$cikmayili;
$wp["120"] = $tckimlikno.$kardes.$cikmatarihi;
$wp["121"] = $tckimlikno.$kardes.$sehir;
$wp["122"] = $tckimlikno.$kardes.$takim;
$wp["123"] = $tckimlikno.$kardes.$takimtarihi;
$wp["124"] = $tckimlikno.$kardes.$takimkisa;
$wp["125"] = $tckimlikno.$kardes.$plaka;



/////////////////////////////////////////////


$wp["126"] = $tckimlikno.$sevgili;
$wp["127"] = $tckimlikno.$sevgili."123";
$wp["128"] = $tckimlikno.$sevgili."1905";
$wp["129"] = $tckimlikno.$sevgili."1907";
$wp["130"] = $tckimlikno.$sevgili."1903";
$wp["131"] = $tckimlikno.$sevgili."1938";
$wp["132"] = $tckimlikno.$sevgili."1919";
$wp["133"] = $tckimlikno.$sevgili."1881";
$wp["134"] = $tckimlikno.$sevgili."2018";
$wp["135"] = $tckimlikno.$sevgili."2019";
$wp["136"] = $tckimlikno.$sevgili.$lakap;
$wp["137"] = $tckimlikno.$sevgili.$anne;
$wp["138"] = $tckimlikno.$sevgili.$baba;
$wp["139"] = $tckimlikno.$sevgili.$kardes;
$wp["140"] = $tckimlikno.$sevgili.$sevgili;
$wp["141"] = $tckimlikno.$sevgili.$sevgilisoyad;
$wp["142"] = $tckimlikno.$sevgili.$dogumtarihi;
$wp["143"] = $tckimlikno.$sevgili.$dogumyili;
$wp["144"] = $tckimlikno.$sevgili.$cikmayili;
$wp["145"] = $tckimlikno.$sevgili.$cikmatarihi;
$wp["146"] = $tckimlikno.$sevgili.$sehir;
$wp["147"] = $tckimlikno.$sevgili.$takim;
$wp["148"] = $tckimlikno.$sevgili.$takimtarihi;
$wp["149"] = $tckimlikno.$sevgili.$takimkisa;
$wp["150"] = $tckimlikno.$sevgili.$plaka;



/////////////////////////////////////////////


$wp["151"] = $tckimlikno.$sevgilisoyad;
$wp["152"] = $tckimlikno.$sevgilisoyad."123";
$wp["153"] = $tckimlikno.$sevgilisoyad."1905";
$wp["154"] = $tckimlikno.$sevgilisoyad."1907";
$wp["155"] = $tckimlikno.$sevgilisoyad."1903";
$wp["156"] = $tckimlikno.$sevgilisoyad."1938";
$wp["157"] = $tckimlikno.$sevgilisoyad."1919";
$wp["158"] = $tckimlikno.$sevgilisoyad."1881";
$wp["159"] = $tckimlikno.$sevgilisoyad."2018";
$wp["160"] = $tckimlikno.$sevgilisoyad."2019";
$wp["161"] = $tckimlikno.$sevgilisoyad.$lakap;
$wp["162"] = $tckimlikno.$sevgilisoyad.$anne;
$wp["163"] = $tckimlikno.$sevgilisoyad.$baba;
$wp["164"] = $tckimlikno.$sevgilisoyad.$kardes;
$wp["165"] = $tckimlikno.$sevgilisoyad.$sevgili;
$wp["166"] = $tckimlikno.$sevgilisoyad.$sevgilisoyad;
$wp["167"] = $tckimlikno.$sevgilisoyad.$dogumtarihi;
$wp["168"] = $tckimlikno.$sevgilisoyad.$dogumyili;
$wp["169"] = $tckimlikno.$sevgilisoyad.$cikmayili;
$wp["170"] = $tckimlikno.$sevgilisoyad.$cikmatarihi;
$wp["171"] = $tckimlikno.$sevgilisoyad.$sehir;
$wp["172"] = $tckimlikno.$sevgilisoyad.$takim;
$wp["173"] = $tckimlikno.$sevgilisoyad.$takimtarihi;
$wp["174"] = $tckimlikno.$sevgilisoyad.$takimkisa;
$wp["175"] = $tckimlikno.$sevgilisoyad.$plaka;


///////////////////////////////////////////


$wp["176"] = $tckimlikno.$dogumtarihi;
$wp["177"] = $tckimlikno.$dogumtarihi."123";
$wp["178"] = $tckimlikno.$dogumtarihi."1905";
$wp["179"] = $tckimlikno.$dogumtarihi."1907";
$wp["180"] = $tckimlikno.$dogumtarihi."1903";
$wp["181"] = $tckimlikno.$dogumtarihi."1938";
$wp["200"] = $tckimlikno.$dogumtarihi."1919";
$wp["182"] = $tckimlikno.$dogumtarihi."1881";
$wp["183"] = $tckimlikno.$dogumtarihi."2018";
$wp["184"] = $tckimlikno.$dogumtarihi."2019";
$wp["185"] = $tckimlikno.$dogumtarihi.$lakap;
$wp["186"] = $tckimlikno.$dogumtarihi.$anne;
$wp["187"] = $tckimlikno.$dogumtarihi.$baba;
$wp["188"] = $tckimlikno.$dogumtarihi.$kardes;
$wp["189"] = $tckimlikno.$dogumtarihi.$sevgili;
$wp["190"] = $tckimlikno.$dogumtarihi.$dogumtarihi;
$wp["191"] = $tckimlikno.$dogumtarihi.$dogumtarihi;
$wp["192"] = $tckimlikno.$dogumtarihi.$dogumyili;
$wp["193"] = $tckimlikno.$dogumtarihi.$cikmayili;
$wp["194"] = $tckimlikno.$dogumtarihi.$cikmatarihi;
$wp["195"] = $tckimlikno.$dogumtarihi.$sehir;
$wp["196"] = $tckimlikno.$dogumtarihi.$takim;
$wp["197"] = $tckimlikno.$dogumtarihi.$takimtarihi;
$wp["198"] = $tckimlikno.$dogumtarihi.$takimkisa;
$wp["199"] = $tckimlikno.$dogumtarihi.$plaka;


///////////////////////////////////////////



$wp["201"] = $tckimlikno.$dogumyili;
$wp["202"] = $tckimlikno.$dogumyili."123";
$wp["203"] = $tckimlikno.$dogumyili."1905";
$wp["204"] = $tckimlikno.$dogumyili."1907";
$wp["205"] = $tckimlikno.$dogumyili."1903";
$wp["206"] = $tckimlikno.$dogumyili."1938";
$wp["207"] = $tckimlikno.$dogumyili."1919";
$wp["208"] = $tckimlikno.$dogumyili."1881";
$wp["209"] = $tckimlikno.$dogumyili."2018";
$wp["210"] = $tckimlikno.$dogumyili."2019";
$wp["211"] = $tckimlikno.$dogumyili.$lakap;
$wp["212"] = $tckimlikno.$dogumyili.$anne;
$wp["213"] = $tckimlikno.$dogumyili.$baba;
$wp["214"] = $tckimlikno.$dogumyili.$kardes;
$wp["215"] = $tckimlikno.$dogumyili.$sevgili;
$wp["216"] = $tckimlikno.$dogumyili.$dogumyili;
$wp["217"] = $tckimlikno.$dogumyili.$dogumyili;
$wp["218"] = $tckimlikno.$dogumyili.$dogumyili;
$wp["219"] = $tckimlikno.$dogumyili.$cikmayili;
$wp["220"] = $tckimlikno.$dogumyili.$cikmatarihi;
$wp["221"] = $tckimlikno.$dogumyili.$sehir;
$wp["222"] = $tckimlikno.$dogumyili.$takim;
$wp["223"] = $tckimlikno.$dogumyili.$takimtarihi;
$wp["224"] = $tckimlikno.$dogumyili.$takimkisa;
$wp["225"] = $tckimlikno.$dogumyili.$plaka;

////////////////////////////////////////

$wp["226"] = $tckimlikno.$cikmayili;
$wp["227"] = $tckimlikno.$cikmayili."123";
$wp["228"] = $tckimlikno.$cikmayili."1905";
$wp["229"] = $tckimlikno.$cikmayili."1907";
$wp["230"] = $tckimlikno.$cikmayili."1903";
$wp["231"] = $tckimlikno.$cikmayili."1938";
$wp["232"] = $tckimlikno.$cikmayili."1919";
$wp["233"] = $tckimlikno.$cikmayili."1881";
$wp["234"] = $tckimlikno.$cikmayili."2018";
$wp["235"] = $tckimlikno.$cikmayili."2019";
$wp["236"] = $tckimlikno.$cikmayili.$lakap;
$wp["237"] = $tckimlikno.$cikmayili.$anne;
$wp["238"] = $tckimlikno.$cikmayili.$baba;
$wp["239"] = $tckimlikno.$cikmayili.$kardes;
$wp["240"] = $tckimlikno.$cikmayili.$sevgili;
$wp["241"] = $tckimlikno.$cikmayili.$cikmayili;
$wp["242"] = $tckimlikno.$cikmayili.$dogumyili;
$wp["243"] = $tckimlikno.$cikmayili.$cikmayili;
$wp["244"] = $tckimlikno.$cikmayili.$cikmayili;
$wp["245"] = $tckimlikno.$cikmayili.$cikmatarihi;
$wp["246"] = $tckimlikno.$cikmayili.$sehir;
$wp["247"] = $tckimlikno.$cikmayili.$takim;
$wp["248"] = $tckimlikno.$cikmayili.$takimtarihi;
$wp["249"] = $tckimlikno.$cikmayili.$takimkisa;
$wp["250"] = $tckimlikno.$cikmayili.$plaka;


///////////////////////////////////////////////


$wp["251"] = $tckimlikno.$cikmatarihi;
$wp["252"] = $tckimlikno.$cikmatarihi."123";
$wp["253"] = $tckimlikno.$cikmatarihi."1905";
$wp["254"] = $tckimlikno.$cikmatarihi."1907";
$wp["255"] = $tckimlikno.$cikmatarihi."1903";
$wp["256"] = $tckimlikno.$cikmatarihi."1938";
$wp["257"] = $tckimlikno.$cikmatarihi."1919";
$wp["258"] = $tckimlikno.$cikmatarihi."1881";
$wp["259"] = $tckimlikno.$cikmatarihi."2018";
$wp["260"] = $tckimlikno.$cikmatarihi."2019";
$wp["261"] = $tckimlikno.$cikmatarihi.$lakap;
$wp["262"] = $tckimlikno.$cikmatarihi.$anne;
$wp["263"] = $tckimlikno.$cikmatarihi.$baba;
$wp["264"] = $tckimlikno.$cikmatarihi.$kardes;
$wp["265"] = $tckimlikno.$cikmatarihi.$sevgili;
$wp["267"] = $tckimlikno.$cikmatarihi.$sevgilisoyad;
$wp["268"] = $tckimlikno.$cikmatarihi.$dogumtarihi;
$wp["269"] = $tckimlikno.$cikmatarihi.$dogumyili;
$wp["270"] = $tckimlikno.$cikmatarihi.$cikmayili;
$wp["271"] = $tckimlikno.$cikmatarihi.$cikmatarihi;
$wp["272"] = $tckimlikno.$cikmatarihi.$sehir;
$wp["273"] = $tckimlikno.$cikmatarihi.$takim;
$wp["274"] = $tckimlikno.$cikmatarihi.$takimtarihi;
$wp["275"] = $tckimlikno.$cikmatarihi.$takimkisa;
$wp["266"] = $tckimlikno.$cikmatarihi.$plaka;

/////////////////////////////////////////

$wp["276"] = $tckimlikno.$sehir;
$wp["277"] = $tckimlikno.$sehir."123";
$wp["278"] = $tckimlikno.$sehir."1905";
$wp["279"] = $tckimlikno.$sehir."1907";
$wp["280"] = $tckimlikno.$sehir."1903";
$wp["281"] = $tckimlikno.$sehir."1938";
$wp["282"] = $tckimlikno.$sehir."1919";
$wp["283"] = $tckimlikno.$sehir."1881";
$wp["284"] = $tckimlikno.$sehir."2018";
$wp["285"] = $tckimlikno.$sehir."2019";
$wp["286"] = $tckimlikno.$sehir.$lakap;
$wp["287"] = $tckimlikno.$sehir.$anne;
$wp["288"] = $tckimlikno.$sehir.$baba;
$wp["289"] = $tckimlikno.$sehir.$kardes;
$wp["290"] = $tckimlikno.$sehir.$sevgili;
$wp["291"] = $tckimlikno.$sehir.$sevgilisoyad;
$wp["292"] = $tckimlikno.$sehir.$dogumtarihi;
$wp["293"] = $tckimlikno.$sehir.$dogumyili;
$wp["294"] = $tckimlikno.$sehir.$cikmayili;
$wp["295"] = $tckimlikno.$sehir.$cikmatarihi;
$wp["296"] = $tckimlikno.$sehir.$sehir;
$wp["297"] = $tckimlikno.$sehir.$takim;
$wp["298"] = $tckimlikno.$sehir.$takimtarihi;
$wp["299"] = $tckimlikno.$sehir.$takimkisa;
$wp["300"] = $tckimlikno.$sehir.$plaka;

/////////////////////////////////////////

$wp["301"] = $tckimlikno.$takim;
$wp["302"] = $tckimlikno.$takim."123";
$wp["303"] = $tckimlikno.$takim."1905";
$wp["304"] = $tckimlikno.$takim."1907";
$wp["305"] = $tckimlikno.$takim."1903";
$wp["306"] = $tckimlikno.$takim."1938";
$wp["307"] = $tckimlikno.$takim."1919";
$wp["308"] = $tckimlikno.$takim."1881";
$wp["309"] = $tckimlikno.$takim."2018";
$wp["310"] = $tckimlikno.$takim."2019";
$wp["311"] = $tckimlikno.$takim.$lakap;
$wp["312"] = $tckimlikno.$takim.$anne;
$wp["313"] = $tckimlikno.$takim.$baba;
$wp["314"] = $tckimlikno.$takim.$kardes;
$wp["315"] = $tckimlikno.$takim.$sevgili;
$wp["316"] = $tckimlikno.$takim.$sevgilisoyad;
$wp["317"] = $tckimlikno.$takim.$dogumtarihi;
$wp["318"] = $tckimlikno.$takim.$dogumyili;
$wp["319"] = $tckimlikno.$takim.$cikmayili;
$wp["320"] = $tckimlikno.$takim.$cikmatarihi;
$wp["321"] = $tckimlikno.$takim.$sehir;
$wp["322"] = $tckimlikno.$takim.$takim;
$wp["323"] = $tckimlikno.$takim.$takimtarihi;
$wp["324"] = $tckimlikno.$takim.$takimkisa;
$wp["325"] = $tckimlikno.$takim.$plaka;

/////////////////////////////////////////


$wp["326"] = $tckimlikno.$takimtarihi;
$wp["327"] = $tckimlikno.$takimtarihi."123";
$wp["328"] = $tckimlikno.$takimtarihi."1905";
$wp["329"] = $tckimlikno.$takimtarihi."1907";
$wp["330"] = $tckimlikno.$takimtarihi."1903";
$wp["331"] = $tckimlikno.$takimtarihi."1938";
$wp["332"] = $tckimlikno.$takimtarihi."1919";
$wp["333"] = $tckimlikno.$takimtarihi."1881";
$wp["334"] = $tckimlikno.$takimtarihi."2018";
$wp["335"] = $tckimlikno.$takimtarihi."2019";
$wp["336"] = $tckimlikno.$takimtarihi.$lakap;
$wp["337"] = $tckimlikno.$takimtarihi.$anne;
$wp["338"] = $tckimlikno.$takimtarihi.$baba;
$wp["339"] = $tckimlikno.$takimtarihi.$kardes;
$wp["340"] = $tckimlikno.$takimtarihi.$sevgili;
$wp["341"] = $tckimlikno.$takimtarihi.$sevgilisoyad;
$wp["342"] = $tckimlikno.$takimtarihi.$dogumtarihi;
$wp["343"] = $tckimlikno.$takimtarihi.$dogumyili;
$wp["344"] = $tckimlikno.$takimtarihi.$cikmayili;
$wp["345"] = $tckimlikno.$takimtarihi.$cikmatarihi;
$wp["346"] = $tckimlikno.$takimtarihi.$sehir;
$wp["347"] = $tckimlikno.$takimtarihi.$takim;
$wp["348"] = $tckimlikno.$takimtarihi.$takimtarihi;
$wp["349"] = $tckimlikno.$takimtarihi.$takimkisa;
$wp["350"] = $tckimlikno.$takimtarihi.$plaka;

/////////////////////////////////////////

$wp["351"] = $tckimlikno.$takimkisa;
$wp["352"] = $tckimlikno.$takimkisa."123";
$wp["353"] = $tckimlikno.$takimkisa."1905";
$wp["354"] = $tckimlikno.$takimkisa."1907";
$wp["355"] = $tckimlikno.$takimkisa."1903";
$wp["356"] = $tckimlikno.$takimkisa."1938";
$wp["357"] = $tckimlikno.$takimkisa."1919";
$wp["358"] = $tckimlikno.$takimkisa."1881";
$wp["359"] = $tckimlikno.$takimkisa."2018";
$wp["360"] = $tckimlikno.$takimkisa."2019";
$wp["361"] = $tckimlikno.$takimkisa.$lakap;
$wp["362"] = $tckimlikno.$takimkisa.$anne;
$wp["363"] = $tckimlikno.$takimkisa.$baba;
$wp["364"] = $tckimlikno.$takimkisa.$kardes;
$wp["365"] = $tckimlikno.$takimkisa.$sevgili;
$wp["366"] = $tckimlikno.$takimkisa.$sevgilisoyad;
$wp["367"] = $tckimlikno.$takimkisa.$dogumtarihi;
$wp["368"] = $tckimlikno.$takimkisa.$dogumyili;
$wp["369"] = $tckimlikno.$takimkisa.$cikmayili;
$wp["370"] = $tckimlikno.$takimkisa.$cikmatarihi;
$wp["371"] = $tckimlikno.$takimkisa.$sehir;
$wp["372"] = $tckimlikno.$takimkisa.$takim;
$wp["373"] = $tckimlikno.$takimkisa.$takimtarihi;
$wp["374"] = $tckimlikno.$takimkisa.$takimkisa;
$wp["375"] = $tckimlikno.$takimkisa.$plaka;

/////////////////////////////////////////

$wp["376"] = $tckimlikno.$plaka;
$wp["377"] = $tckimlikno.$plaka."123";
$wp["378"] = $tckimlikno.$plaka."1905";
$wp["379"] = $tckimlikno.$plaka."1907";
$wp["380"] = $tckimlikno.$plaka."1903";
$wp["381"] = $tckimlikno.$plaka."1938";
$wp["382"] = $tckimlikno.$plaka."1919";
$wp["383"] = $tckimlikno.$plaka."1881";
$wp["384"] = $tckimlikno.$plaka."2018";
$wp["385"] = $tckimlikno.$plaka."2019";
$wp["386"] = $tckimlikno.$plaka.$lakap;
$wp["387"] = $tckimlikno.$plaka.$anne;
$wp["388"] = $tckimlikno.$plaka.$baba;
$wp["389"] = $tckimlikno.$plaka.$kardes;
$wp["390"] = $tckimlikno.$plaka.$sevgili;
$wp["391"] = $tckimlikno.$plaka.$sevgilisoyad;
$wp["392"] = $tckimlikno.$plaka.$dogumtarihi;
$wp["393"] = $tckimlikno.$plaka.$dogumyili;
$wp["394"] = $tckimlikno.$plaka.$cikmayili;
$wp["395"] = $tckimlikno.$plaka.$cikmatarihi;
$wp["396"] = $tckimlikno.$plaka.$sehir;
$wp["397"] = $tckimlikno.$plaka.$takim;
$wp["398"] = $tckimlikno.$plaka.$takimtarihi;
$wp["399"] = $tckimlikno.$plaka.$takimkisa;
$wp["400"] = $tckimlikno.$plaka.$plaka;

/////////////////////////////////////////

$wp["401"] = $tckimlikno.$eskisifre;
$wp["402"] = $tckimlikno.$eskisifre."123";
$wp["403"] = $tckimlikno.$eskisifre."1905";
$wp["404"] = $tckimlikno.$eskisifre."1907";
$wp["405"] = $tckimlikno.$eskisifre."1903";
$wp["406"] = $tckimlikno.$eskisifre."1938";
$wp["407"] = $tckimlikno.$eskisifre."1919";
$wp["408"] = $tckimlikno.$eskisifre."1881";
$wp["409"] = $tckimlikno.$eskisifre."2018";
$wp["410"] = $tckimlikno.$eskisifre."2019";
$wp["411"] = $tckimlikno.$eskisifre.$lakap;
$wp["412"] = $tckimlikno.$eskisifre.$anne;
$wp["413"] = $tckimlikno.$eskisifre.$baba;
$wp["414"] = $tckimlikno.$eskisifre.$kardes;
$wp["415"] = $tckimlikno.$eskisifre.$sevgili;
$wp["416"] = $tckimlikno.$eskisifre.$sevgilisoyad;
$wp["417"] = $tckimlikno.$eskisifre.$dogumtarihi;
$wp["418"] = $tckimlikno.$eskisifre.$dogumyili;
$wp["419"] = $tckimlikno.$eskisifre.$cikmayili;
$wp["420"] = $tckimlikno.$eskisifre.$cikmatarihi;
$wp["421"] = $tckimlikno.$eskisifre.$sehir;
$wp["422"] = $tckimlikno.$eskisifre.$takim;
$wp["423"] = $tckimlikno.$eskisifre.$takimtarihi;
$wp["424"] = $tckimlikno.$eskisifre.$takimkisa;
$wp["425"] = $tckimlikno.$eskisifre.$plaka;

/////////////////////////////////////////


$wp["426"] = $tckimlikno.$tel;
$wp["427"] = $tckimlikno.$tel."123";
$wp["428"] = $tckimlikno.$tel."1905";
$wp["429"] = $tckimlikno.$tel."1907";
$wp["430"] = $tckimlikno.$tel."1903";
$wp["431"] = $tckimlikno.$tel."1938";
$wp["432"] = $tckimlikno.$tel."1919";
$wp["433"] = $tckimlikno.$tel."1881";
$wp["434"] = $tckimlikno.$tel."2018";
$wp["435"] = $tckimlikno.$tel."2019";
$wp["436"] = $tckimlikno.$tel.$lakap;
$wp["437"] = $tckimlikno.$tel.$anne;
$wp["438"] = $tckimlikno.$tel.$baba;
$wp["439"] = $tckimlikno.$tel.$kardes;
$wp["440"] = $tckimlikno.$tel.$sevgili;
$wp["441"] = $tckimlikno.$tel.$sevgilisoyad;
$wp["442"] = $tckimlikno.$tel.$dogumtarihi;
$wp["443"] = $tckimlikno.$tel.$dogumyili;
$wp["444"] = $tckimlikno.$tel.$cikmayili;
$wp["445"] = $tckimlikno.$tel.$cikmatarihi;
$wp["446"] = $tckimlikno.$tel.$sehir;
$wp["447"] = $tckimlikno.$tel.$takim;
$wp["448"] = $tckimlikno.$tel.$takimtarihi;
$wp["449"] = $tckimlikno.$tel.$takimkisa;
$wp["450"] = $tckimlikno.$tel.$plaka;

/////////////////////////////////////////

$wp["451"] = $tckimlikno.$annetel;
$wp["452"] = $tckimlikno.$annetel."123";
$wp["453"] = $tckimlikno.$annetel."1905";
$wp["454"] = $tckimlikno.$annetel."1907";
$wp["455"] = $tckimlikno.$annetel."1903";
$wp["456"] = $tckimlikno.$annetel."1938";
$wp["457"] = $tckimlikno.$annetel."1919";
$wp["458"] = $tckimlikno.$annetel."1881";
$wp["459"] = $tckimlikno.$annetel."2018";
$wp["460"] = $tckimlikno.$annetel."2019";
$wp["461"] = $tckimlikno.$annetel.$lakap;
$wp["462"] = $tckimlikno.$annetel.$anne;
$wp["463"] = $tckimlikno.$annetel.$baba;
$wp["464"] = $tckimlikno.$annetel.$kardes;
$wp["465"] = $tckimlikno.$annetel.$sevgili;
$wp["466"] = $tckimlikno.$annetel.$sevgilisoyad;
$wp["467"] = $tckimlikno.$annetel.$dogumtarihi;
$wp["468"] = $tckimlikno.$annetel.$dogumyili;
$wp["469"] = $tckimlikno.$annetel.$cikmayili;
$wp["470"] = $tckimlikno.$annetel.$cikmatarihi;
$wp["471"] = $tckimlikno.$annetel.$sehir;
$wp["472"] = $tckimlikno.$annetel.$takim;
$wp["473"] = $tckimlikno.$annetel.$takimtarihi;
$wp["474"] = $tckimlikno.$annetel.$takimkisa;
$wp["475"] = $tckimlikno.$annetel.$plaka;

/////////////////////////////////////////


$wp["476"] = $tckimlikno.$babatel;
$wp["477"] = $tckimlikno.$babatel."123";
$wp["478"] = $tckimlikno.$babatel."1905";
$wp["479"] = $tckimlikno.$babatel."1907";
$wp["480"] = $tckimlikno.$babatel."1903";
$wp["481"] = $tckimlikno.$babatel."1938";
$wp["482"] = $tckimlikno.$babatel."1919";
$wp["483"] = $tckimlikno.$babatel."1881";
$wp["484"] = $tckimlikno.$babatel."2018";
$wp["485"] = $tckimlikno.$babatel."2019";
$wp["486"] = $tckimlikno.$babatel.$lakap;
$wp["487"] = $tckimlikno.$babatel.$anne;
$wp["488"] = $tckimlikno.$babatel.$baba;
$wp["489"] = $tckimlikno.$babatel.$kardes;
$wp["490"] = $tckimlikno.$babatel.$sevgili;
$wp["491"] = $tckimlikno.$babatel.$sevgilisoyad;
$wp["492"] = $tckimlikno.$babatel.$dogumtarihi;
$wp["493"] = $tckimlikno.$babatel.$dogumyili;
$wp["494"] = $tckimlikno.$babatel.$cikmayili;
$wp["495"] = $tckimlikno.$babatel.$cikmatarihi;
$wp["496"] = $tckimlikno.$babatel.$sehir;
$wp["497"] = $tckimlikno.$babatel.$takim;
$wp["498"] = $tckimlikno.$babatel.$takimtarihi;
$wp["499"] = $tckimlikno.$babatel.$takimkisa;
$wp["500"] = $tckimlikno.$babatel.$plaka;

/////////////////////////////////////////


$wp["501"] = $tckimlikno.$kardestel;
$wp["502"] = $tckimlikno.$kardestel."123";
$wp["503"] = $tckimlikno.$kardestel."1905";
$wp["504"] = $tckimlikno.$kardestel."1907";
$wp["505"] = $tckimlikno.$kardestel."1903";
$wp["506"] = $tckimlikno.$kardestel."1938";
$wp["507"] = $tckimlikno.$kardestel."1919";
$wp["508"] = $tckimlikno.$kardestel."1881";
$wp["509"] = $tckimlikno.$kardestel."2018";
$wp["510"] = $tckimlikno.$kardestel."2019";
$wp["511"] = $tckimlikno.$kardestel.$lakap;
$wp["512"] = $tckimlikno.$kardestel.$anne;
$wp["513"] = $tckimlikno.$kardestel.$baba;
$wp["514"] = $tckimlikno.$kardestel.$kardes;
$wp["515"] = $tckimlikno.$kardestel.$sevgili;
$wp["516"] = $tckimlikno.$kardestel.$sevgilisoyad;
$wp["517"] = $tckimlikno.$kardestel.$dogumtarihi;
$wp["518"] = $tckimlikno.$kardestel.$dogumyili;
$wp["519"] = $tckimlikno.$kardestel.$cikmayili;
$wp["520"] = $tckimlikno.$kardestel.$cikmatarihi;
$wp["521"] = $tckimlikno.$kardestel.$sehir;
$wp["522"] = $tckimlikno.$kardestel.$takim;
$wp["523"] = $tckimlikno.$kardestel.$takimtarihi;
$wp["524"] = $tckimlikno.$kardestel.$takimkisa;
$wp["525"] = $tckimlikno.$kardestel.$plaka;

/////////////////////////////////////////


$wp["526"] = $tckimlikno.$sevgilitel;
$wp["527"] = $tckimlikno.$sevgilitel."123";
$wp["528"] = $tckimlikno.$sevgilitel."1905";
$wp["529"] = $tckimlikno.$sevgilitel."1907";
$wp["530"] = $tckimlikno.$sevgilitel."1903";
$wp["531"] = $tckimlikno.$sevgilitel."1938";
$wp["532"] = $tckimlikno.$sevgilitel."1919";
$wp["533"] = $tckimlikno.$sevgilitel."1881";
$wp["534"] = $tckimlikno.$sevgilitel."2018";
$wp["535"] = $tckimlikno.$sevgilitel."2019";
$wp["536"] = $tckimlikno.$sevgilitel.$lakap;
$wp["537"] = $tckimlikno.$sevgilitel.$anne;
$wp["538"] = $tckimlikno.$sevgilitel.$baba;
$wp["539"] = $tckimlikno.$sevgilitel.$kardes;
$wp["540"] = $tckimlikno.$sevgilitel.$sevgili;
$wp["541"] = $tckimlikno.$sevgilitel.$sevgilisoyad;
$wp["542"] = $tckimlikno.$sevgilitel.$dogumtarihi;
$wp["543"] = $tckimlikno.$sevgilitel.$dogumyili;
$wp["544"] = $tckimlikno.$sevgilitel.$cikmayili;
$wp["545"] = $tckimlikno.$sevgilitel.$cikmatarihi;
$wp["546"] = $tckimlikno.$sevgilitel.$sehir;
$wp["547"] = $tckimlikno.$sevgilitel.$takim;
$wp["548"] = $tckimlikno.$sevgilitel.$takimtarihi;
$wp["549"] = $tckimlikno.$sevgilitel.$takimkisa;
$wp["550"] = $tckimlikno.$sevgilitel.$plaka;

/////////////////////////////////////////




$wp["551"] = $tckimlikno.$tckimlikno;
$wp["552"] = $tckimlikno.$tckimlikno."13";
$wp["553"] = $tckimlikno.$tckimlikno."1905";
$wp["554"] = $tckimlikno.$tckimlikno."1907";
$wp["555"] = $tckimlikno.$tckimlikno."1903";
$wp["556"] = $tckimlikno.$tckimlikno."1938";
$wp["557"] = $tckimlikno.$tckimlikno."1919";
$wp["558"] = $tckimlikno.$tckimlikno."1881";
$wp["559"] = $tckimlikno.$tckimlikno."2018";
$wp["560"] = $tckimlikno.$tckimlikno."2019";
$wp["561"] = $tckimlikno.$tckimlikno.$lakap;
$wp["562"] = $tckimlikno.$tckimlikno.$anne;
$wp["563"] = $tckimlikno.$tckimlikno.$baba;
$wp["564"] = $tckimlikno.$tckimlikno.$kardes;
$wp["565"] = $tckimlikno.$tckimlikno.$sevgili;
$wp["566"] = $tckimlikno.$tckimlikno.$sevgilisoyad;
$wp["567"] = $tckimlikno.$tckimlikno.$dogumtarihi;
$wp["568"] = $tckimlikno.$tckimlikno.$dogumyili;
$wp["569"] = $tckimlikno.$tckimlikno.$cikmayili;
$wp["570"] = $tckimlikno.$tckimlikno.$cikmatarihi;
$wp["571"] = $tckimlikno.$tckimlikno.$sehir;
$wp["572"] = $tckimlikno.$tckimlikno.$takim;
$wp["573"] = $tckimlikno.$tckimlikno.$takimtarihi;
$wp["574"] = $tckimlikno.$tckimlikno.$takimkisa;
$wp["575"] = $tckimlikno.$tckimlikno.$plaka;





for ($i=0; $i <= 575 ; $i++) { 

$ac = fopen("../wordlist.txt","a+");


$userlar = ($wp[$i]."\n");



fwrite($ac,$userlar);
}
fclose($ac);


 ?>