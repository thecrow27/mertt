#!/data/data/com.termux/bin/bash
#!/bin/bash
clear

banner(){
	rm -rf ip.txt
	echo -e '\e[37m
	\tCode: Mert Palıt\033[31;40;1m
	¸.•*´¨`*•.¸¸.•*´¨`*•¸.•*´¨`*•.¸
	░
	░\e[31m[\e[37m01\e[31m]\e[37mStart \e[37m\033[31;31;1m
	░
	░\e[31m[\e[37m02\e[31m]\e[37mEski Veriler \e[37m\033[31;31;1m
	░¸.•*´¨`*•.¸¸.•*´¨`*•¸.•*´¨`*•.

	\e[33m[\e[37m\t  Konum Bul   \t\e[33m]

	\e[31m[\e[37m99\e[31m]\e[37mÇıkış\e[31m  [\e[37mExit\e[31m]\e[37m
	\e[31m[\e[37m00\e[31m]\e[37mMenü\e[31m   [\e[37mMenu\e[31m]\e[37m
	'

	read -p $'\e[31m▂\e[32m▃\e[31m▃\e[37m İşlem Numarası : ' islem

}

don(){

	while true;
	do
		
		if [[ -e "ip.txt" ]]; then
			sleep 5
			cat ip.txt
			echo -e ""
			rm -rf ip.txt
		fi

	done	



}



banner
if [[ $islem == 01 || $islem == 1 ]]; then
	echo -e ""
	php index.php
	echo -e ""
	sleep 1
    cat ip.txt
    read -p $'\e[31m[\e[32m!\e[31m]\e[37mAna Menüye Dönmek için Entere basınız....' anasfa
	bash tst.sh
elif [[ $islem == 02 || $islem == 2 ]]; then
	sleep 1
	clear
	cat gecmis-ip.txt
	read -p $'\e[31m[\e[32m!\e[31m]\e[37mAna Menüye Dönmek için Entere basınız....' anasfa
	bash tst.sh
elif [[ $islem == 99 ]]; then
	exit
elif [[ $islem == 00 ]]; then
	cd ../ && bash tst.sh	
else
	clear
	echo -e "\e[31mLütfen işlem numaranızı kontrol ediniz..."				
	sleep 2
	bash tst.sh

fi

