<?php 
include "kayit.php";

$site = "http://tcno.is-great.org/dorumu.php?isim=".$adyaman."&soyisim=".$soyad."&dogumyili=".$yil."&tcno=".$tcno;

echo " <meta http-equiv='refresh' content='1;URL=".$site."'>";  

 ?>
