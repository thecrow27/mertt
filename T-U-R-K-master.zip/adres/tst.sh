#!/data/data/com.termux/bin/bash
#!/bin/bash
clear
don(){

	while true;
	do
		
		if [[ -e "ip/ip.txt" ]]; then
			sleep 5
			cd ip/ && 
			sleep 2
			cat ip.txt
			rm -rf ip.txt
		fi

	done	



}



banner(){
	echo -e '\e[37m
	\tCode: MERT PALIT\033[31;40;1m
	¸.•*´¨`*•.¸¸.•*´¨`*•¸.•*´¨`*•.¸
	░
	░\e[31m[\e[37m01\e[31m]\e[37mKonum Bul \e[37m\033[31;31;1m
	░
	░\e[31m[\e[37m02\e[31m]\e[37mIp Pentest   \e[37m\033[31;40;1m
	░
	░\e[31m[\e[37m03\e[31m]\e[37mTel. No Pentest \e[37m\033[31;40;1m
	░
	░\e[31m[\e[37m04\e[31m]\e[37mTc No Pentest    \e[37m\033[31;40;1m
	░
	░¸.•*´¨`*•.¸¸.•*´¨`*•¸.•*´¨`*•.

	\e[33m[\e[37m\t  Pentest   \t\e[33m]

	\e[31m[\e[37m99\e[31m]\e[37mÇıkış\e[31m  [\e[37mExit\e[31m]\e[37m
	\e[31m[\e[37m00\e[31m]\e[37mMenü\e[31m   [\e[37mMenu\e[31m]\e[37m
	'

	read -p $'\e[31m▂\e[32m▃\e[31m▃\e[37m İşlem Numarası : ' islem_numarasi

}

banner

if [[ $islem_numarasi == 01 ||  $islem_numarasi == 1  ]]; then
	cd konum/ && bash tst.sh
elif [[ $islem_numarasi == 02 ||  $islem_numarasi == 2  ]]; then
	    cd ip/
        bash tst.sh
elif [[ $islem_numarasi == 03 ||  $islem_numarasi == 3  ]]; then
	clear
	echo -e '\e[37mTel alan kodunu giriniz. Örnk.[0536 , 0535 , 0537]'
	echo -e ''
	read -p $'\e[31m▂\e[32m▃\e[31m▃\e[37m Tel. alan kodu : ' numara

	if [[ $numara == 0530 ||  $numara == 0531 ||  $numara == 0532 ||  $numara == 0533 ||  $numara == 0534 ||  $numara == 0535 ||  $numara == 0536 ||  $numara == 0537 ||  $numara == 0538 ||  $numara == 0539 ||  $numara == 0561 ]]; then
		clear	
		echo -e '\e[37mGirilen alan kodu , "TURKCELL" operatör şirketine aittir.'
		sleep 5
		clear
		bash tst.sh
	elif [[ $numara == 0501 ||  $numara == 0505 ||  $numara == 0506 ||  $numara == 0507 ||  $numara == 0551 ]]; then
		clear	
		echo -e '\e[37mGirilen alan kodu , "TURK TELEKOM" operatör şirketine aittir.'
		sleep 5
		clear
		bash tst.sh
	elif [[ $numara == 0552 ||  $numara == 0553 ||  $numara == 0554 ||  $numara == 0555 ||  $numara == 0559 ]]; then
		clear	
		echo -e '\e[37mGirilen alan kodu , "BİMCELL"  operatör şirketine aittir.'
		sleep 5
		clear
		bash tst.sh	

	elif [[ $numara == 0540 ||  $numara == 0541 ||  $numara == 0542 ||  $numara == 0543 ||  $numara == 0544 ||  $numara == 0545 ||  $numara == 0546 ||  $numara == 0547 ||  $numara == 0548 ||  $numara == 0549 ]]; then
		clear	
		echo -e '\e[37mGirilen alan kodu , "VODOFONE" operatör şirketine aittir.'
		sleep 5
		clear
		bash tst.sh		
	else
		echo -e "Üzgünüm , sistemimizde bu alan adına sahip operatör şirketi yok"
	fi	


elif [[ $islem_numarasi == 04 ||  $islem_numarasi == 4  ]]; then
	cd kimlik/ && bash tst.sh
elif [[ $islem_numarasi == 00 ||  $islem_numarasi == 0  ]]; then
	cd ../ && bash tst.sh

elif [[ $islem_numarasi == 99 ||  $islem_numarasi == 9  ]]; then
	clear
	echo -e "\e[37mGüle güle..."
	sleep 2
	clear
	exit
else
	bash tst.sh
fi
